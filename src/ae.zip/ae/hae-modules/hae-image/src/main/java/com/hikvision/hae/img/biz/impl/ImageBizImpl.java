package com.hikvision.hae.img.biz.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.img.biz.ImageBiz;
import com.hikvision.hae.img.dto.DeleteImageDTO;
import com.hikvision.hae.img.dto.ImageRepositoryAccessInfo;
import com.hikvision.hae.common.constant.ImageResultCode;
import com.spotify.docker.client.exceptions.DockerException;
import com.spotify.docker.client.messages.Image;


@Component
public class ImageBizImpl extends AbstractImageBiz implements ImageBiz {

	@Override
	public List<Image> imageList(ImageRepositoryAccessInfo accessInfo) {
		try {
			return createDockerClient(accessInfo).listImages();
		} catch (DockerException | InterruptedException e) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_LIST_ERROR, e);
		}
	}

	@Override
	public void removeImage(DeleteImageDTO deleteDTO) {
		try {
			createDockerClient(deleteDTO.getAccessInfo()).removeImage(deleteDTO.getImage(), true, false);
		} catch (DockerException | InterruptedException e) {
			throw new HAERuntimeException(ImageResultCode.DELETE_IMAGE_ERROR, e);
		}
	}
}
