package com.hikvision.hae.img.repo;

import java.util.List;

import io.swagger.client.model.DetailedTag;
import io.swagger.client.model.Project;
import io.swagger.client.model.Repository;

public interface ImageRepo {

	/**
	 * 项目列表
	 * @param page
	 * @return
	 */
	List<Project> projectList();
	
	/**
	 * 创建项目
	 */
	void createProject(String projectName);
	/**
	 * 查询项目名称是否存在
	 * @param projectName
	 * @return
	 */
	boolean isProjectExist(String projectName);
	
	void deleteProject(long id);
	
	Project getProjectById(long projectId);
	/**
	 * 仓库列表
	 * @param projectId
	 * @param page
	 * @return
	 */
	List<Repository> repositoryList(Integer projectId);
	/**
	 * 仓库下的tag列表
	 * @param repoName
	 * @return
	 */
	List<DetailedTag> tagList(String repoName);
	
	/**
	 * 删除仓库
	 * @param repoName
	 */
	void deleteRepository(String repoName);
	
	/**
	 * 删除仓库下某个tag
	 * @param repoName
	 * @param tag
	 */
	void deleteRepositoryTag(String repoName, String tag);
}
