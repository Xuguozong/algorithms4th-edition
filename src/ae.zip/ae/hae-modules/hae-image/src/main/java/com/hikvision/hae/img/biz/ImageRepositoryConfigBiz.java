package com.hikvision.hae.img.biz;

import com.hikvision.hae.img.dto.ImageRepositoryAccessInfo;

public interface ImageRepositoryConfigBiz {

	ImageRepositoryAccessInfo accessInfo();
}
