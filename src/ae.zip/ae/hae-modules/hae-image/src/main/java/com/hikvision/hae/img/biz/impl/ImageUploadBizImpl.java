package com.hikvision.hae.img.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.img.biz.ImageUploadBiz;
import com.hikvision.hae.img.dto.UploadImageDTO;
import com.hikvision.hae.common.constant.ImageResultCode;
import com.hikvision.hae.img.repo.ImageRepo;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.exceptions.DockerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class ImageUploadBizImpl extends AbstractImageBiz implements ImageUploadBiz {

	private static final Logger logger = LoggerFactory.getLogger(ImageUploadBizImpl.class);

	private static final String DEFAULT_PROJECT = "library";

	@Autowired
	private ImageRepo imageRepo;

	@Override
	public void uploadImage(UploadImageDTO uploadDTO) throws DockerException, InterruptedException {
		DockerClient docker = createDockerClient(uploadDTO.getAccessInfo());
		Set<String> images;
		try {
			images = docker.load(uploadDTO.getImageStream());
		} catch (Exception e) {
			throw new HAERuntimeException(ImageResultCode.LOAD_IMAGE_FAILED, "docker加载镜像文件失败", e);
		}

		if (images == null || images.size() == 0) {
			logger.error("推送镜像文件id: {} 没有返回任何镜像名称，可能原因是在保存镜像时没有指定名称", uploadDTO.getFileId());
			throw new IllegalArgumentException("保存镜像时没有指定名称");
		}
		String[] dest = new String[3];
		dest[0] = uploadDTO.getAccessInfo().getHarborAccessInfo();
		for (String image : images) {
			logger.info("upload image {} success.", image);
			String[] parts = image.split("/");
			if (parts.length < 2) {
				// 推送到harbor仓库的镜像如果没有项目名称，则默认放到library项目中
				System.arraycopy(parts, 0, dest, 2, 1);
				dest[1] = DEFAULT_PROJECT;
			} else {
				// 拷贝原镜像后两项信息
				System.arraycopy(parts, parts.length - 2, dest, 1, 2);
			}
			String tag = String.join("/", dest);
			docker.tag(image, tag);
			logger.info("tag image from {} to {}", image, tag);
			//校验harbor 里是否有相应的工程名称 没有就创建
			invalidOrCreateProject(dest[1]);
			//向harbor 推送镜像
			docker.push(tag);
			logger.info("push image {} success.", image);
		}
	}

	private void invalidOrCreateProject(String projectName) {
		if (!imageRepo.isProjectExist(projectName)) {
			try {
				imageRepo.createProject(projectName);
				logger.info("create harbor project {} success.", projectName);
			} catch (HAERuntimeException e) {
				if (ImageResultCode.PROJECT_ALREADY_EXIST == e.getResultCode()) {
					logger.warn("harbor project {} exist.", projectName);
				} else {
					throw e;
				}
			}
		}
	}

}
