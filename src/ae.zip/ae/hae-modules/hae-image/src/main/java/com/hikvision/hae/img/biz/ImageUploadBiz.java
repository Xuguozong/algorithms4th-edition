package com.hikvision.hae.img.biz;

import com.hikvision.hae.img.dto.UploadImageDTO;
import com.spotify.docker.client.exceptions.DockerException;

public interface ImageUploadBiz {

	void uploadImage(UploadImageDTO uploadDTO) throws DockerException, InterruptedException;
}
