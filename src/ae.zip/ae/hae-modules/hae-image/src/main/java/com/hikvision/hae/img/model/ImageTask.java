package com.hikvision.hae.img.model;

import jef.database.DataObject;
import javax.persistence.*;
import java.util.Date;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:10 2018/3/15
 * @Description :  用于镜像制作  镜像任务模型
 */
@Entity
@Table(name = "image_task")
public class ImageTask extends DataObject {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer             id;

    @Column(name = "task_name")
    private String              taskName;

    @Lob
    @Column(name = "content")
    private String              content;

    @Column(name = "program_name")
    private String              programName;

    @Column(name = "repository")
    private String              repository;

    @Column(name = "tag")
    private String              tag;

    @Column(name = "program_path")
    private String              programPath;

    @Column(name = "status")
    private Integer             taskStatus;

    @Column(name = "create_time")
    private Date                createTime;

    @Column(name = "modify_time")
    private Date                modifyTime;

    @Column(name = "failed_reason")
    private String              failedReason;

    public enum Field implements jef.database.Field{
        id,taskName,content,programName,repository,tag,
        programPath,taskStatus,createTime,modifyTime,failedReason
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramPath() {
        return programPath;
    }

    public void setProgramPath(String programPath) {
        this.programPath = programPath;
    }

    public Integer getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(Integer taskStatus) {
        this.taskStatus = taskStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getFailedReason() {
        return failedReason;
    }

    public void setFailedReason(String failedReason) {
        this.failedReason = failedReason;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
