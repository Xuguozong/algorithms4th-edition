package com.hikvision.hae.file.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.dto.CreateUploadFileDTO;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.file.repo.UploadFileRepo;
import com.hikvision.hae.common.constant.ImageResultCode;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.File;
import java.util.Date;
import java.util.List;

@Component
public class UploadFileBizImpl implements UploadFileBiz {

	@Resource
	private UploadFileRepo uploadRepo;

	@Override
	public UploadFile getById(String fileId, boolean canBeNull) {
		UploadFile result = uploadRepo.getById(fileId);
		if (!canBeNull && result == null) {
			throw new HAERuntimeException(ImageResultCode.UPLOADFILE_RECORD_NOT_EXIST);
		}
		return result;
	}

	@Override
	public List<UploadFile> getByStatus(List<UploadStatus> status) {
		return uploadRepo.getByStatus(status);
	}

	@Override
	public List<UploadFile> getAll() {
		return uploadRepo.list();
	}

	@Override
	public UploadFile create(CreateUploadFileDTO createDTO) {
		UploadFile newFile = new UploadFile();
		newFile.setFileId(createDTO.getFileId());
		newFile.setNativePath(createDTO.getNativePath());
		newFile.setFileName(createDTO.getFileName());
		newFile.setCurrentTrunk(createDTO.getCurrentTrunk());
		newFile.setTotalChunks(createDTO.getTotalChunks());
		newFile.setFilePath(createDTO.getTmpSavePath());
		newFile.setTotalSize(createDTO.getTotalSize());
		newFile.setCreated(new Date());
		newFile.setModifed(new Date());
		newFile.setStatus(UploadStatus.UPLOADING);
		return uploadRepo.add(newFile);
	}

	@Override
	public void updateCurrentTrunk(String fileId, int currentTrunk) {
		UploadFile file = getById(fileId, false);
		file.setCurrentTrunk(currentTrunk);
		file.setModifed(new Date());
		uploadRepo.update(file);
	}

	@Override
	public void updateStatus(String fileId, UploadStatus status, String reason) {
		UploadFile file = getById(fileId, false);
		file.setStatus(status);
		file.setFailedReason(reason);
		file.setModifed(new Date());
		uploadRepo.update(file);
	}

	@Override
	public void delete(String fileId) {
		int deleted = uploadRepo.delete(fileId);
		if (deleted != 1) {
			throw new HAERuntimeException(ImageResultCode.UPDATE_UPLOADFILE_STATUS_ERROR);
		}
	}

	@Override
	public void clean(String fileId) {
		UploadFile file = getById(fileId, false);
		clean(file);
	}

	void clean(UploadFile file) {
		String uploadTmpDir = file.getFilePath();
		FileUtils.deleteQuietly(new File(uploadTmpDir));
	}
}
