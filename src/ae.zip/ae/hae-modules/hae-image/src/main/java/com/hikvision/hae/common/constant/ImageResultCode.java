package com.hikvision.hae.common.constant;

/**
 * @author qiuzhihao
 */
public class ImageResultCode {

	/**
	 * 上传文件记录不存在
	 */
	public static final int UPLOADFILE_RECORD_NOT_EXIST = 13000;

	/**
	 * 更新上传文件进度失败
	 */
	public static final int UPDATE_UPLOADFILE_TRUNK_ERROR = 13001;

	/**
	 * 保存上传文件块错误
	 */
	public static final int SAVE_UPLOADFILE_TRUNK_ERROR = 13002;

	/**
	 * 更新上传文件状态失败
	 */
	public static final int UPDATE_UPLOADFILE_STATUS_ERROR = 13003;

	/**
	 * 删除上传文件记录失败
	 */
	public static final int DELETE_UPLOADFILE_ERROR = 13004;

	/**
	 * 合并上传文件失败
	 */
	public static final int MERGE_UPLOADFILE_ERROR = 13005;

	/**
	 * 当前状态不允许上传文件
	 */
	public static final int ILLEGAL_UPLOAD_STATUS_ERROR = 13006;

	/**
	 * 恢复断点上传条件不正确
	 */
	public static final int ILLEGAL_UPLOADBREAK_ERROR = 13007;

	/**
	 * 上传文件块校验值不相等
	 */
	public static final int BAD_UPLOADFILE_CHECKSUM = 13008;

	/**
	 * 上传文件不存在
	 */
	public static final int UPLOADFILE_DONOT_EXIST = 13009;

	/**
	 * 调用rest接口异常
	 */
	public static final int INVOKE_REST_API_ERROR = 13010;

	/**
	 * 下载镜像异常
	 */
	public static final int DOWNLOAD_IMAGE_ERROR = 13011;

	/**
	 * 查看镜像列表异常
	 */
	public static final int IMAGE_LIST_ERROR = 13012;

	/**
	 * 删除镜像异常
	 */
	public static final int DELETE_IMAGE_ERROR = 13013;

	/**
	 * 项目不存在
	 */
	public static final int PROJECT_NOT_EXIST = 13014;

	/**
	 * 项目已存在
	 */
	public static final int PROJECT_ALREADY_EXIST = 13015;

	/**
	 * docker加载镜像失败
	 */
	public static final int LOAD_IMAGE_FAILED = 13016;

	/**
	 * 只能中断上传中的文件
	 */
	public static final int INTERRUPT_UPLOADING_FILE_ONLY = 13017;

	/**
	 * 镜像状态更新失败
	 */
	public static final int IMAGE_TASK_UPDATE_FAILED = 13018;

	/**
	 * 上传程序文件失败
	 */
	public static final int PROGRAM_UPLOAD_FAILED = 13019;

	/**
	 * 上传程序文件为空
	 */
	public static final int PROGRAM_UPLOAD_EMPTY = 13020;

	/**
	 * 镜像任务名称为空
	 */
	public static final int IMAGE_TASK_NAME_EMPTY = 13021;

	/**
	 * 镜像任务基础镜像未选择
	 */
	public static final int IMAGE_TASK_BASEIMAGE_EMPTY = 13022;

	/**
	 * 镜像任务镜像脚本为空
	 */
	public static final int IMAGE_TASK_IMAGESH_EMPTY = 13023;

	/**
	 * 镜像任务程序执行脚本为空
	 */
	public static final int IMAGE_TASK_PROGRAMSH_EMPTY = 13024;

	/**
	 * 镜像任务镜像仓库为空
	 */
	public static final int IMAGE_TASK_REPOSITORY_EMPTY = 13025;

	/**
	 * 镜像任务镜像标签为空
	 */
	public static final int IMAGE_TASK_TAG_EMPTY = 13026;

	/**
	 * 镜像任务工作目录为空
	 */
	public static final int IMAGE_TASK_WORKDIR_EMPTY = 13027;

	/**
	 * 镜像任务不存在
	 */
	public static final int IMAGE_TASK_NOT_EXSIT = 13028;
}
