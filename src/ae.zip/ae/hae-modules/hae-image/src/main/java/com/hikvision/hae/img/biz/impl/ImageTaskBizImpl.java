package com.hikvision.hae.img.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.img.biz.ImageTaskBiz;
import com.hikvision.hae.img.dto.ImageRepositoryAccessInfo;
import com.hikvision.hae.img.dto.ImageTaskDTO;
import com.hikvision.hae.img.dto.TaskStatus;
import com.hikvision.hae.common.constant.ImageResultCode;
import com.hikvision.hae.img.model.ImageTask;
import com.hikvision.hae.img.repo.ImageTaskRepo;
import com.spotify.docker.client.DockerClient;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 9:44 2018/3/16
 * @Description :  镜像任务 业务实现
 */
@Component
public class ImageTaskBizImpl extends AbstractImageBiz implements ImageTaskBiz {

	private static final Logger LOGGER = LoggerFactory.getLogger(ImageTaskBizImpl.class);

	@Autowired
	private ImageTaskRepo imageTaskRepo;

	@Override
	public Integer create(String programName, String programPath) {
		ImageTask task = new ImageTask();
		task.setProgramName(programName);
		task.setProgramPath(programPath);
		task.setCreateTime(new Date());
		task.setModifyTime(new Date());
		task.setTaskStatus(TaskStatus.PACKAGE.getValue());
		ImageTask imageTask = imageTaskRepo.save(task);
		return imageTask.getId();
	}

	@Override
	public void updateStatus(Integer id, TaskStatus status, String reason) {
		if (null == status) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_UPDATE_FAILED);
		}
		imageTaskRepo.updateStatus(id, status.getValue(), reason);
	}

	@Override
	public void updateTask(Integer id, String content, String taskName, String repository, String tag) {
		ImageTask task = new ImageTask();
		task.setId(id);
		task.setContent(content);
		task.setTaskStatus(TaskStatus.WAITING.getValue());
		task.setTaskName(taskName);
		task.setRepository(repository);
		task.setTag(tag);
		task.setModifyTime(new Date());
		imageTaskRepo.update(task);
	}

	@Override
	public ImageTaskDTO getImageTaskByID(Integer id) {
		return ImageTaskDTO.fromImageTask(imageTaskRepo.getOne(id));
	}

	@Override
	public List<ImageTaskDTO> getAllTask() {
		List<ImageTask> tasks = imageTaskRepo.findAllTask();
		return ImageTaskDTO.convertToList(tasks);
	}

	@Override
	public void updateProgramName(Integer id, String programName) {
		imageTaskRepo.updateProgramName(id, programName);
	}

	@Override
	public void buildDocker(String dockerTag, File dockefile, ImageRepositoryAccessInfo info) {
		DockerClient dockerClient = createDockerClient(info);
		DockerClient.BuildParam tag = DockerClient.BuildParam.name(dockerTag);
		DockerClient.BuildParam[] params = {tag};
		try {
			dockerClient.build(dockefile.toPath(), params);
			dockerClient.push(dockerTag);
		} catch (Exception e) {
			LOGGER.info("通过dockerfile生成docker镜像异常");
			throw new HAERuntimeException();
		}
	}

	@Override
	public void pushDocker(String dockerTag, ImageRepositoryAccessInfo info) {
		DockerClient dockerClient = createDockerClient(info);
		try {
			dockerClient.push(dockerTag);
		} catch (Exception e) {
			LOGGER.info("推送镜像{}失败", dockerTag);
			throw new HAERuntimeException();
		}
	}

	@Override
	public void removeImageDIR(String dockerDir) {
		try {
			FileUtils.deleteDirectory(new File(dockerDir));
		} catch (IOException e) {
			LOGGER.info("删除文件夹{}异常", dockerDir);
		}
	}

	@Override
	public List<ImageTaskDTO> findImageTaskByStatus(TaskStatus taskStatus) {
		List<ImageTask> imageTasks = imageTaskRepo.findTaskByStatus(taskStatus.getValue());
		return ImageTaskDTO.convertToList(imageTasks);
	}

	@Override
	public void deleteTaskById(int id) {
		imageTaskRepo.delete(id);
	}
}
