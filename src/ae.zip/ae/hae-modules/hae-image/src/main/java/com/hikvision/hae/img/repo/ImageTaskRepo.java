package com.hikvision.hae.img.repo;

import com.github.geequery.springdata.annotation.Modifying;
import com.github.geequery.springdata.annotation.Query;
import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.img.model.ImageTask;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 17:04 2018/3/15
 * @Description :  操作MySQL数据仓库接口（含实现）
 */
@Repository
public interface ImageTaskRepo extends GqRepository<ImageTask,Integer> {

    @Modifying
    @Query("update image_task set status =?2, failed_reason =?3 where id =?1")
    void updateStatus(Integer id, Integer status, String reason);

    @Modifying
    @Query("update image_task set program_name =?2 where id =?1")
    void updateProgramName(Integer id, String programName);

    @Query("select * from image_task where status in (1,2,3,4) order by create_time desc")
    List<ImageTask> findAllTask();

    @Query("select * from image_task where status = ?1")
    List<ImageTask> findTaskByStatus(int status);
}
