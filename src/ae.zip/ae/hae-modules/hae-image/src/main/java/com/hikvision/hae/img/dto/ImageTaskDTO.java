package com.hikvision.hae.img.dto;

import com.google.common.collect.Lists;
import com.hikvision.hae.img.model.ImageTask;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 17:16 2018/3/15
 * @Description :  镜像任务  业务层数据传输对象
 */
public class ImageTaskDTO implements Serializable{

    private static final long serialVersionUID = 2381333201179194540L;

    private Integer             id;
    private String              taskName;
    private String              content;
    private String              programName;
    private String              repository;
    private String              tag;
    private String              programPath;
    private TaskStatus          taskStatus;
    private Date                createTime;
    private Date                modifyTime;
    private String              failedReason;

    public static ImageTaskDTO fromImageTask(ImageTask task){
        if (null == task){
            return null;
        }
        ImageTaskDTO imageTaskDTO = new ImageTaskDTO();
        imageTaskDTO.setContent(task.getContent());
        imageTaskDTO.setCreateTime(task.getCreateTime());
        imageTaskDTO.setFailedReason(task.getFailedReason());
        imageTaskDTO.setId(task.getId());
        imageTaskDTO.setModifyTime(task.getModifyTime());
        imageTaskDTO.setProgramName(task.getProgramName());
        imageTaskDTO.setRepository(task.getRepository());
        imageTaskDTO.setTag(task.getTag());
        imageTaskDTO.setProgramPath(task.getProgramPath());
        imageTaskDTO.setTaskName(task.getTaskName());
        imageTaskDTO.setTaskStatus(TaskStatus.of(task.getTaskStatus()));
        return imageTaskDTO;
    }

    public static List<ImageTaskDTO> convertToList(List<ImageTask> tasks){
        if (CollectionUtils.isEmpty(tasks)){
            return null;
        }
        List<ImageTaskDTO> imageTaskDTOS = Lists.newArrayList();
        tasks.forEach(task->{
            imageTaskDTOS.add(fromImageTask(task));
        });
        return imageTaskDTOS;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramPath() {
        return programPath;
    }

    public void setProgramPath(String programPath) {
        this.programPath = programPath;
    }

    public TaskStatus getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(TaskStatus taskStatus) {
        this.taskStatus = taskStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getFailedReason() {
        return failedReason;
    }

    public void setFailedReason(String failedReason) {
        this.failedReason = failedReason;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
