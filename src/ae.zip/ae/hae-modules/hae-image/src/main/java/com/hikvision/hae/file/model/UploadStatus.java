package com.hikvision.hae.file.model;


/**
 * @author qiuzhihao
 */
public enum UploadStatus {
	/**
	 * 上传中
	 */
	UPLOADING(6, "上传中"),
	/**
	 * 上传完成，等待合并
	 */
	WAITING_MERGE(5, "等待合并"),
	/**
	 * 合并中
	 */
	MERGING(4, "合并中"),
	/**
	 * 合并完成，等待推送
	 */
	WAITING_PUSH(3, "等待推送"),
	/**
	 * 推送中
	 */
	PUSHING(2, "推送中"),

	/**
	 * ========================================
	 * 上面都是上传文件的中间状态，下面都是文件上传的终态
	 * ========================================
	 */

	/**
	 * 推送完成
	 */
	PUSHED(1, "推送完成"),
	/**
	 * 合并失败，最终状态
	 */
	MERGE_ERROR(7, "合并失败"),
	/**
	 * 推送错误
	 */
	PUSH_ERROR(8, "推送错误"),
	/**
	 * 上传中断
	 */
	UPLOAD_BREAK(9, "上传中断");

	/**
	 * 排序值
	 * 值越大越靠前
	 */
	private Integer order;
	/**
	 * 内容值
	 */
	private String content;

	UploadStatus(Integer order, String content) {
		this.order = order;
		this.content = content;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}