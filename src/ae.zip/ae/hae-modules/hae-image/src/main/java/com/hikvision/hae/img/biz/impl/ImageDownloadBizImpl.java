package com.hikvision.hae.img.biz.impl;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hikvision.hae.img.biz.ImageDownloadBiz;
import com.hikvision.hae.img.dto.DownloadImageDTO;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.exceptions.DockerException;

@Component
public class ImageDownloadBizImpl extends AbstractImageBiz implements ImageDownloadBiz {

	private static final Logger logger = LoggerFactory.getLogger(ImageDownloadBizImpl.class);
	
	@Override
	public InputStream downloadImage(DownloadImageDTO downloadDTO) throws DockerException, InterruptedException, IOException {
			DockerClient docker = createDockerClient(downloadDTO.getAccessInfo());
			logger.info("开始下载{}镜像数据", downloadDTO.getImageName());
			docker.pull(downloadDTO.getImageName());
			InputStream stream = docker.save(downloadDTO.getImageName());
			logger.info("开始传输{}镜像数据", downloadDTO.getImageName());
			return stream;
	}

}
