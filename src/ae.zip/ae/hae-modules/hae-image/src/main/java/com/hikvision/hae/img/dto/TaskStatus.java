package com.hikvision.hae.img.dto;

import java.util.stream.Stream;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 16:40 2018/3/15
 * @Description :  用于描述镜像任务状态
 */
public enum TaskStatus {

	PACKAGE(0, "程序包"),
	WAITING(1, "等待构建"),
	BUILDING(2, "正在构建中"),
	SUCCESS(3, "任务成功"),
	FAIlURE(4, "任务失败");

	private Integer value;
	private String content;

	TaskStatus(Integer value, String content) {
		this.content = content;
		this.value = value;
	}

	public static TaskStatus of(Integer value) {
		TaskStatus taskStatus = Stream.of(TaskStatus.values()).filter(status -> status.getValue().equals(value)).
				findFirst().orElse(null);
		return taskStatus;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
