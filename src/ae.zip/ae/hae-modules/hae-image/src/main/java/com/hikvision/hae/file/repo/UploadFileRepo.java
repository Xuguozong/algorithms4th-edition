package com.hikvision.hae.file.repo;

import java.util.List;

import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;

public interface UploadFileRepo {
	
	UploadFile getById(String fileId);

	UploadFile add(UploadFile file);
	
	int update(UploadFile file);
	
	int delete(String fileId);
	
	List<UploadFile> list();
	
	List<UploadFile> getByStatus(List<UploadStatus> status);
	
}
