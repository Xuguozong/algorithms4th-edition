package com.hikvision.hae.file.repo.impl;

import java.util.List;

import javax.annotation.Resource;

import org.easyframe.enterprise.spring.CommonDao;
import org.springframework.stereotype.Repository;

import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.file.repo.UploadFileRepo;

import jef.database.query.Query;
import jef.database.query.QueryBuilder;

@Repository
public class UploadFileRepoImpl implements UploadFileRepo {

	@Resource
	private CommonDao dao;
	
	@Override
	public UploadFile getById(String fileId) {
		List<UploadFile> file = getByFiled(UploadFile.Field.fileId, fileId);
		if(file != null && file.size() > 0) {
			return file.get(0);
		}
		return null;
	}

	@Override
	public UploadFile add(UploadFile file) {
		return dao.insert(file);
	}

	@Override
	public int update(UploadFile file) {
		return dao.update(file);
	}

	@Override
	public int delete(String fileId) {
		return dao.removeByField(UploadFile.class, UploadFile.Field.fileId.name(), fileId);
	}

	@Override
	public List<UploadFile> list() {
		Query<UploadFile> query = QueryBuilder.create(UploadFile.class);
		return dao.find(query);
	}
	
	@Override
	public List<UploadFile> getByStatus(List<UploadStatus> status) {
		Query<UploadFile> query = QueryBuilder.create(UploadFile.class);
		query.addCondition(QueryBuilder.in(UploadFile.Field.status, status));
		return dao.find(query);
	}

	private List<UploadFile> getByFiled(UploadFile.Field field, Object value) {
		Query<UploadFile> query = QueryBuilder.create(UploadFile.class);
		query.addCondition(QueryBuilder.eq(field, value));
		return dao.find(query);
	}

}
