package com.hikvision.hae.file.model;

import java.util.Date;

import javax.persistence.*;

import jef.database.DataObject;

@Entity
@Table(name = "upload_file")
public class UploadFile extends DataObject {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private int id;
	
	@Column(name = "file_id")
	private String fileId;

	@Column(name = "native_path")
	private String nativePath;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "total_trunks")
	private int totalChunks;

	@Column(name = "current_trunk")
	private int currentTrunk;
	
	@Column(name = "total_size")
	private long totalSize;

	@Column
	@Enumerated(EnumType.STRING)
	private UploadStatus status;

	@Column(name = "failed_reason")
	@Lob
	private String failedReason;
	
	@Column(name = "file_path")
	private String filePath;

	@Column
	private Date created;

	@Column
	private Date modifed;
	
	public enum Field implements jef.database.Field {
        id, fileId, nativePath, fileName, totalChunks, currentTrunk,
		totalSize, status, failedReason, filePath, created, modifed;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getNativePath() {
		return nativePath;
	}

	public void setNativePath(String nativePath) {
		this.nativePath = nativePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getTotalChunks() {
		return totalChunks;
	}

	public void setTotalChunks(int totalChunks) {
		this.totalChunks = totalChunks;
	}

	public int getCurrentTrunk() {
		return currentTrunk;
	}

	public void setCurrentTrunk(int currentTrunk) {
		this.currentTrunk = currentTrunk;
	}

	public long getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}

	public UploadStatus getStatus() {
		return status;
	}

	public void setStatus(UploadStatus status) {
		this.status = status;
	}

	public String getFailedReason() {
		return failedReason;
	}

	public void setFailedReason(String failedReason) {
		this.failedReason = failedReason;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getModifed() {
		return modifed;
	}

	public void setModifed(Date modifed) {
		this.modifed = modifed;
	}

	@Override
	public String toString() {
		return "UploadFile [id=" + id + ", fileId=" + fileId + ", fileName=" + fileName + ", totalChunks=" + totalChunks
				+ ", currentTrunk=" + currentTrunk + ", totalSize=" + totalSize + ", status=" + status
				+ ", failedReason=" + failedReason +", filePath="
				+ filePath + ", created=" + created + ", modifed=" + modifed + "]";
	}

}
