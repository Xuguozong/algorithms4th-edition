package com.hikvision.hae.img.repo;

import io.swagger.client.api.ProductsApi;

public interface ServiceProvider {

	ProductsApi createProductsApi(); 
}
