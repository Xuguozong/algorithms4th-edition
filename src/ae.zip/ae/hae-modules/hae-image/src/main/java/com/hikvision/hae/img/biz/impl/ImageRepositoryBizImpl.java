package com.hikvision.hae.img.biz.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.hikvision.hae.img.biz.ImageRepositoryBiz;
import com.hikvision.hae.img.entity.ImageProjectEntity;
import com.hikvision.hae.img.entity.ImageRepositoryEntity;
import com.hikvision.hae.img.entity.ImageRepositoryTagEntity;
import com.hikvision.hae.img.repo.ImageRepo;

import io.swagger.client.model.DetailedTag;
import io.swagger.client.model.Project;
import io.swagger.client.model.Repository;

@Component
public class ImageRepositoryBizImpl implements ImageRepositoryBiz {

	@Resource
	private ImageRepo imgRepo;

	@Override
	public void createProject(String projectName) {
		imgRepo.createProject(projectName);
	}

	@Override
	public boolean isProjectExist(String projectName) {
		return imgRepo.isProjectExist(projectName);
	}

	@Override
	public void deleteProject(long projectId) {
		imgRepo.deleteProject(projectId);
	}

	@Override
	public ImageProjectEntity getProject(long projectId) {
		Project project = imgRepo.getProjectById(projectId);
		return (project != null) ? new ImageProjectEntity(project) :null;
	}

	@Override
	public List<ImageProjectEntity> projectList() {
		List<Project> list = imgRepo.projectList();
		return list.stream().map(ImageProjectEntity::new).collect(Collectors.toList());
	}

	@Override
	public List<ImageRepositoryEntity> repositoryList(Integer projectId) {
		List<Repository> list = imgRepo.repositoryList(projectId);
		return list.stream().map(ImageRepositoryEntity::new).collect(Collectors.toList());
	}

	@Override
	public List<ImageRepositoryTagEntity> repositoryTagList(String repoName) {
		List<DetailedTag> list = imgRepo.tagList(repoName);
		return list.stream().map(tag -> {
			ImageRepositoryTagEntity entity = new ImageRepositoryTagEntity(tag);
			entity.setRepoName(repoName);
			return entity;
		}).collect(Collectors.toList());
	}

	@Override
	public void deleteRepository(String repoName) {
		imgRepo.deleteRepository(repoName);
	}

	@Override
	public void deleteRepositoryTag(String repoName, String tag) {
		imgRepo.deleteRepositoryTag(repoName, tag);
	}
	
}
