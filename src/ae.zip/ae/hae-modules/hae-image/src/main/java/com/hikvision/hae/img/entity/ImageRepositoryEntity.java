package com.hikvision.hae.img.entity;

import io.swagger.client.model.Repository;

public class ImageRepositoryEntity {

	private int id;

	private String name;

	private int projectId;

	private int tagsCount;

	public ImageRepositoryEntity(Repository repo) {
		this.id = repo.getId();
		this.name = repo.getName();
		this.projectId = repo.getProjectId();
		this.tagsCount = repo.getTagsCount();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public int getTagsCount() {
		return tagsCount;
	}

	public void setTagsCount(int tagsCount) {
		this.tagsCount = tagsCount;
	}

}
