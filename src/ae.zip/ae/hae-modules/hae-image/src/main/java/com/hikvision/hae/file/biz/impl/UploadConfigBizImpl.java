package com.hikvision.hae.file.biz.impl;

import java.io.File;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.boot.autoconfigure.web.MultipartProperties;
import org.springframework.stereotype.Component;

import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.file.biz.UploadConfigBiz;

@Component
public class UploadConfigBizImpl implements UploadConfigBiz {

	@Resource
	private MultipartProperties multipartProperties;
	
	@PostConstruct
	public void init() {
		String tmpDir = this.uploadLocation();
		if (!StringUtils.isEmpty(tmpDir)) {
			File tmpDirectory = new File(tmpDir);
			if (!tmpDirectory.exists()) {
				tmpDirectory.mkdir();
			} else if (tmpDirectory.isFile()) {
				tmpDirectory.delete();
				tmpDirectory.mkdir();
			}
		}
	}
	
	@Override
	public String uploadLocation() {
		return multipartProperties.getLocation();
	}

}
