package com.hikvision.hae.img.biz;

import com.hikvision.hae.img.dto.ImageRepositoryAccessInfo;
import com.hikvision.hae.img.dto.ImageTaskDTO;
import com.hikvision.hae.img.dto.TaskStatus;

import java.io.File;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 17:33 2018/3/15
 * @Description :  定义镜像任务 业务层接口
 */
public interface ImageTaskBiz {

    /**
     * 创建镜像任务
     * @param programName 程序包名称
     * @param programPath 程序包存储路径
     * @return  返回任务ID
     */
    Integer create(String programName, String programPath);

    /**
     * @param id  任务ID
     * @param status 任务状态
     * @param reason 失败原因 可为空
     */
    void updateStatus(Integer id, TaskStatus status, String reason);

    /**
     * 更新任务
     * @param id  镜像任务ID
     * @param content  镜像文件内容
     * @param taskName 任务名称
     * @param repository  镜像仓库
     * @param tag 标签
     */
    void updateTask(Integer id, String content, String taskName, String repository, String tag);

    /**
     *  获取镜像任务
     * @param id 任务ID
     * @return 返回镜像任务
     */
    ImageTaskDTO getImageTaskByID(Integer id);

    /**
     * 获取所有的镜像任务
     * @return 任务列表
     */
    List<ImageTaskDTO> getAllTask();

    /**
     * @param id    镜像任务ID
     * @param programName  程序包名称
     */
    void updateProgramName(Integer id, String programName);

    /**
     * 构建docker
     * @param dockerTag docker标签 全称
     * @param dockefile dockerfile文件对象
     * @param info  镜像仓库信息
     */
    void buildDocker(String dockerTag, File dockefile, ImageRepositoryAccessInfo info);

    /**
     * 向镜像仓库推送镜像
     * @param dockerTag 镜像标签  带路径名的全称
     * @param info      镜像仓库基本信息
     */
    void pushDocker(String dockerTag, ImageRepositoryAccessInfo info);

    /**
     * 删除构建docker时  生成的文件夹
     * @param dockerDir  文件夹名称
     */
    void removeImageDIR(String dockerDir);

    /**
     * @param taskStatus  任务状态
     * @return  返回镜像任务列表
     */
    List<ImageTaskDTO> findImageTaskByStatus(TaskStatus taskStatus);

    /**
     * 根据ID删除任务
     * @param id
     */
    void deleteTaskById(int id);
}
