package com.hikvision.hae.file.biz;

import java.util.List;

import com.hikvision.hae.file.dto.CreateUploadFileDTO;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;

public interface UploadFileBiz {

	/**
	 * 查询上传文件记录
	 * @param fileId
	 * @return
	 */
	UploadFile getById(String fileId, boolean canBeNull);
	/**
	 * 查询某种状态的文件记录
	 * @param status
	 * @return
	 */
	List<UploadFile> getByStatus(List<UploadStatus> status);
	/**
	 * 获取所有上传记录
	 * @return
	 */
	List<UploadFile> getAll();
	/**
	 * 创建上传文件记录
	 * @param createDTO
	 * @return
	 */
	UploadFile create(CreateUploadFileDTO createDTO);
	/**
	 * 更新上传文件当前块数
	 * @param fileId
	 * @param currentTrunk
	 */
	void updateCurrentTrunk(String fileId, int currentTrunk);
	
	/**
	 * 更新状态
	 * @param fileId
	 * @param status
	 */
	void updateStatus(String fileId, UploadStatus status, String reason);
	
	/**
	 * 删除上传记录
	 * @param fileId
	 */
	void delete(String fileId);
	
	/**
	 * 清除上传文件
	 * @param fileId
	 */
	void clean(String fileId);
}
