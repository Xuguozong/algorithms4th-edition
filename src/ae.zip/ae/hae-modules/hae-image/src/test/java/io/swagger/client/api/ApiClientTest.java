package io.swagger.client.api;

import java.util.List;

import org.junit.Test;

import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.auth.HttpBasicAuth;
import io.swagger.client.model.DetailedTag;
import io.swagger.client.model.Project;
import io.swagger.client.model.Repository;

public class ApiClientTest {

	@Test
	public void test() throws ApiException {
		ApiClient client = new ApiClient();
		client.setBasePath("http://docker.hikvision.com.cn/api");
		client.setVerifyingSsl(false);
		HttpBasicAuth basic = new HttpBasicAuth();
		basic.setUsername("hae");
		basic.setPassword("Hik12345+");
		client.getAuthentications().put("basic", basic);
		ProductsApi api = new ProductsApi(client);
		List<Project> projects = api.projectsGet(null, null, null, 1, 10);
		for(Project project : projects) {
			List<Repository> repos = api.repositoriesGet(project.getProjectId(), null, 1, 100);
			for(Repository repo : repos) {
				System.out.println(repo);
				List<DetailedTag> tags = api.repositoriesRepoNameTagsGet(repo.getName());
				for(DetailedTag tag : tags) {
					System.out.println(tag);
				}
			}
		}
	}
}
