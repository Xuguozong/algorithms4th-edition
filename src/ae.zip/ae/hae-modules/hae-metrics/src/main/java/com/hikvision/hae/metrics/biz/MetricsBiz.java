package com.hikvision.hae.metrics.biz;

import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import com.hikvision.hae.metrics.dto.MetricsQueryDTO;

import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public interface MetricsBiz {

	/**
	 * 获取节点监控信息
	 *
	 * @param nodeName    节点K8S名称
	 * @param metricsQuery 查询条件
	 * @return
	 */
	MetricsDTO metricsNode(String nodeName, MetricsQueryDTO metricsQuery);

	/**
	 * 获取节点GPU监控信息
	 *
	 * @param nodeName    节点K8S名称
	 * @param gpuIndex    GPU卡序号
	 * @param metricsQuery 查询条件
	 * @return
	 */
	MetricsDTO metricsNodeGpu(String nodeName, String gpuIndex, MetricsQueryDTO metricsQuery);

	/**
	 * 获取节点GPU基本信息
	 *
	 * @param nodeName 节点K8S名称
	 * @param gpuIndex GPU卡序号
	 * @return
	 */
	GpuBaseInfo getNodeGpuBaseInfo(String nodeName, String gpuIndex);

	/**
	 * 获取集群监控信息
	 *
	 * @param metricsType
	 * @return
	 */
	List<MetricsDTO> metricsCluster(MetricsType metricsType);

	MetricsDTO metricsNamespace(String namespace, MetricsQueryDTO metricsQuery);

	MetricsDTO metricsPod(String namespace, String podName, MetricsQueryDTO metricsQuery);

}
