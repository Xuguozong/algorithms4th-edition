package com.hikvision.hae.metrics.biz.impl;

import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.metrics.biz.MetricsBiz;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import com.hikvision.hae.metrics.dto.MetricsQueryDTO;
import com.hikvision.hae.metrics.repo.MetricsRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
@Service
public class MetricsBizImpl implements MetricsBiz {

	private static final Logger logger = LoggerFactory.getLogger(MetricsBizImpl.class);

	@Autowired
	private MetricsRepo metricsRepo;

	@Override
	public MetricsDTO metricsNode(String nodeName, MetricsQueryDTO metricsQuery) {
		return metricsRepo.metricNode(nodeName, metricsQuery);
	}

	@Override
	public MetricsDTO metricsNodeGpu(String nodeName, String gpuIndex, MetricsQueryDTO metricsQuery) {
		return metricsRepo.metricNodeGPU(nodeName, gpuIndex, metricsQuery);
	}

	@Override
	public GpuBaseInfo getNodeGpuBaseInfo(String nodeName, String gpuIndex) {
		return metricsRepo.getNodeGpuBaseInfo(nodeName, gpuIndex);
	}

	@Override
	public List<MetricsDTO> metricsCluster(MetricsType metricsType) {
		List<MetricsDTO> metricsDTOs = new ArrayList<>();
		List<String> nodeList = metricsRepo.getNodeItems();
		if (!CollectionUtils.isEmpty(nodeList)) {
			MetricsQueryDTO metricsQuery = new MetricsQueryDTO(metricsType);
			nodeList.parallelStream().forEach(node -> {
				MetricsDTO metricsDTO = metricsNode(node, metricsQuery);
				if (metricsDTO != null) {
					metricsDTOs.add(metricsDTO);
				}
			});
		}
		return metricsDTOs;
	}

	@Override
	public MetricsDTO metricsNamespace(String namespace, MetricsQueryDTO metricsQuery) {
		return metricsRepo.metricNamespace(namespace, metricsQuery);
	}

	@Override
	public MetricsDTO metricsPod(String namespace, String podName, MetricsQueryDTO metricsQuery) {
		return metricsRepo.metricPod(namespace, podName, metricsQuery);
	}

}
