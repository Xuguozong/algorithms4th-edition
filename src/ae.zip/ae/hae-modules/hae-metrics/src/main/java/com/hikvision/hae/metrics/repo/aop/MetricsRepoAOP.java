package com.hikvision.hae.metrics.repo.aop;

import com.hikvision.hae.common.util.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by zhanjiejun on 2018/4/9.
 */
@Component
@Aspect
public class MetricsRepoAOP {

	private static final Logger logger = LoggerFactory.getLogger(MetricsRepoAOP.class);

	@Pointcut("execution(* com.hikvision.hae.metrics.repo.MetricsRepo.* (..))")
	public void pointCut() {
	}

	@Around("pointCut()")
	public Object handleException(ProceedingJoinPoint joinPoint) {
		Object result = null;
		try {
			result = joinPoint.proceed();
		} catch (Throwable ex) {
			StringBuilder message = new StringBuilder("Exception happened while calling method ");
			String methodName = joinPoint.getSignature().getName();
			message.append(methodName).append("(").append(StringUtils.join(joinPoint.getArgs(), ", ")).append(")")
					.append(", exception message: ").append(ex.getMessage());
			// 这里就不打印异常堆栈了，没有参考的价值
			logger.error(message.toString());
		}
		return result;
	}

}
