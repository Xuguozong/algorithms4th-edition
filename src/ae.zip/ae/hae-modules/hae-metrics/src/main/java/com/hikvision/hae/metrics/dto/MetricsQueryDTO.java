package com.hikvision.hae.metrics.dto;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.util.UTCDateUtil;
import jef.tools.D;

import java.util.Date;

/**
 * Created by zhanjiejun on 2018/4/9.
 */
public class MetricsQueryDTO {

	private MetricsType metricsType;

	private String startUTC;

	private String endUTC;

	public MetricsQueryDTO(MetricsType metricsType) {
		this.metricsType = metricsType;
	}

	public MetricsQueryDTO(MetricsType metricsType, String startUTC, String endUTC) {
		this.metricsType = metricsType;
		this.startUTC = startUTC;
		this.endUTC = endUTC;
	}

	public MetricsQueryDTO(MetricsType metricsType, Date start, Date end) {
		this.metricsType = metricsType;
		this.startUTC = UTCDateUtil.formatDateToUTCTime(start);
		this.endUTC = UTCDateUtil.formatDateToUTCTime(end);
	}

	public MetricsType getMetricsType() {
		return metricsType;
	}

	public void setMetricsType(MetricsType metricsType) {
		this.metricsType = metricsType;
	}

	public String getStartUTC() {
		return startUTC;
	}

	public void setStartUTC(String startUTC) {
		this.startUTC = startUTC;
	}

	public String getEndUTC() {
		return endUTC;
	}

	public void setEndUTC(String endUTC) {
		this.endUTC = endUTC;
	}

	@Override
	public String toString() {
		return "MetricsQueryDTO{" +
				"metricsType=" + metricsType +
				", startUTC='" + startUTC + '\'' +
				", endUTC='" + endUTC + '\'' +
				'}';
	}
}
