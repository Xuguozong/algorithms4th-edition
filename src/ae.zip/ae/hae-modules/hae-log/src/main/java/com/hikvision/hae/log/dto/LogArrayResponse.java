package com.hikvision.hae.log.dto;

import java.util.List;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
public class LogArrayResponse<T> {

	private String message;

	private List<T> data;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}
}
