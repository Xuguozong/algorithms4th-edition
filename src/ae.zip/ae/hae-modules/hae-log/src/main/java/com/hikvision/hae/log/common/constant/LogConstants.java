package com.hikvision.hae.log.common.constant;

public class LogConstants {

	public static final String LOG_SEARCH_API = "/api/v1/logs/search";

	public static final String LOG_DOWNLOAD_API = "/api/v1/logs/download";

}
