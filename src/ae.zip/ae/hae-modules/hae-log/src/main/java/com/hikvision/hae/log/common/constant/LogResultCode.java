package com.hikvision.hae.log.common.constant;

/**
 * 应用日志错误码 14000~14999
 * Created by zhouziwei on 2017/11/23.
 */
public class LogResultCode {
}
