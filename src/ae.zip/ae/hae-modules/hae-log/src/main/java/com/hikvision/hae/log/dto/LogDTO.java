package com.hikvision.hae.log.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hikvision.hae.common.domain.KubernetesData;

import java.io.Serializable;
import java.util.Map;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
public class LogDTO implements Serializable {

	@JsonProperty(value = "@timestamp")
	private String timestamp;

	private String message;

	private String source;

	private Map<String, String> fields;

	private KubernetesData kubernetes;

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Map<String, String> getFields() {
		return fields;
	}

	public void setFields(Map<String, String> fields) {
		this.fields = fields;
	}

	public KubernetesData getKubernetes() {
		return kubernetes;
	}

	public void setKubernetes(KubernetesData kubernetes) {
		this.kubernetes = kubernetes;
	}
}
