package com.hikvision.hae.log.dto;

import java.io.Serializable;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
public class LogQueryDTO implements Serializable {

	private static final long serialVersionUID = -6092536070198799054L;

	/** 日志查询起始时间（UTC） */
	private String dateRangeStart;

	/** 日志查询截止时间（UTC） */
	private String dateRangeEnd;

	/** 日志过滤条件 */
	private String filters;

	/** 从第from个日志开始查 */
	private int from;

	/** 每页的日志数量 */
	private int size;

	private Boolean asc = true;

	/**
	 * 设置分页参数
	 * @param pageSize
	 * @param pageNo
	 */
	public void setPageParam(int pageSize, int pageNo) {
		this.size = pageSize;
		this.from = (pageNo - 1) * pageSize;
	}

	public String getDateRangeStart() {
		return dateRangeStart;
	}

	public void setDateRangeStart(String dateRangeStart) {
		this.dateRangeStart = dateRangeStart;
	}

	public String getDateRangeEnd() {
		return dateRangeEnd;
	}

	public void setDateRangeEnd(String dateRangeEnd) {
		this.dateRangeEnd = dateRangeEnd;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public int getFrom() {
		return from;
	}

	public int getSize() {
		return size;
	}

	public void setFrom(int from) {
		this.from = from;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Boolean getAsc() {
		return asc;
	}

	public void setAsc(Boolean asc) {
		this.asc = asc;
	}

	@Override
	public String toString() {
		return "LogQueryDTO{" +
				"dateRangeStart='" + dateRangeStart + '\'' +
				", dateRangeEnd='" + dateRangeEnd + '\'' +
				", filters='" + filters + '\'' +
				", from=" + from +
				", size=" + size +
				", asc=" + asc +
				'}';
	}
}
