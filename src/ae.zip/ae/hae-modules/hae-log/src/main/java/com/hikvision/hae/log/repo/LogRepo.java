package com.hikvision.hae.log.repo;

import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.log.common.constant.LogConstants;
import com.hikvision.hae.log.dto.LogArrayResponse;
import com.hikvision.hae.log.dto.LogDTO;
import com.hikvision.hae.log.dto.LogQueryDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
@Component
public class LogRepo {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${log.server.endpoint:https://log-apiserver:5443}")
	private String logServerEndpoint;

	private static final Logger logger = LoggerFactory.getLogger(LogRepo.class);

	public List<LogDTO> search(LogQueryDTO query) {
		// 构建认证头
		HttpHeaders httpHeaders = buildHeaders();
		HttpEntity<LogQueryDTO> requestEntity = new HttpEntity<>(query, httpHeaders);
		// 构建请求URL
		String url = StringUtils.joinURL(logServerEndpoint, LogConstants.LOG_SEARCH_API);
		// 调用接口
		ParameterizedTypeReference<LogArrayResponse<LogDTO>> typeRef = new ParameterizedTypeReference<LogArrayResponse<LogDTO>>() {
		};
		LogArrayResponse<LogDTO> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, typeRef).getBody();
		logger.debug("Search log for {}, response message: {}", query, response.getMessage());
		return response.getData();
	}

	public List<String> download(LogQueryDTO query) {
		// 构建认证头
		HttpHeaders httpHeaders = buildHeaders();
		HttpEntity<LogQueryDTO> requestEntity = new HttpEntity<>(query, httpHeaders);
		// 构建请求URL
		String url = StringUtils.joinURL(logServerEndpoint, LogConstants.LOG_DOWNLOAD_API);
		// 调用接口
		ParameterizedTypeReference<LogArrayResponse<String>> typeRef = new ParameterizedTypeReference<LogArrayResponse<String>>() {
		};
		LogArrayResponse<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, typeRef).getBody();
		logger.debug("Download log for {}, response message: {}", query, response.getMessage());
		return response.getData();
	}

	private HttpHeaders buildHeaders() {
		HttpHeaders headers = new HttpHeaders();
		List<MediaType> accepts = new ArrayList<>();
		accepts.add(MediaType.APPLICATION_JSON);
		headers.setAccept(accepts);
		return headers;
	}

}
