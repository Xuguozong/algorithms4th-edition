package com.hikvision.hae.log.biz;

import com.hikvision.hae.log.dto.LogDTO;
import com.hikvision.hae.log.dto.LogQueryDTO;

import java.util.List;

/**
 * 应用日志BIZ层
 */
public interface LogBiz {

	List<LogDTO> searchLogs(LogQueryDTO query);

	List<String> downloadLogs(LogQueryDTO query);

}
