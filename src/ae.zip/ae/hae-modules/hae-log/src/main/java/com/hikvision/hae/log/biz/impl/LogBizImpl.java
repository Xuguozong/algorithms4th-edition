package com.hikvision.hae.log.biz.impl;

import com.hikvision.hae.log.biz.LogBiz;
import com.hikvision.hae.log.dto.LogDTO;
import com.hikvision.hae.log.dto.LogQueryDTO;
import com.hikvision.hae.log.repo.LogRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Service
public class LogBizImpl implements LogBiz {

    private static final Logger logger = LoggerFactory.getLogger(LogBizImpl.class);

    @Autowired
    private LogRepo logRepo;

    @Override
    public List<LogDTO> searchLogs(LogQueryDTO query) {
        try {
            return logRepo.search(query);
        } catch (Exception e) {
            logger.error("Search logs for " + query.toString() + " failed", e);
        }
        return Collections.emptyList();
    }

    @Override
    public List<String> downloadLogs(LogQueryDTO query) {
        try {
            return logRepo.download(query);
        } catch (Exception e) {
            logger.error("Download logs for " + query.toString() + " failed", e);
        }
        return Collections.emptyList();
    }

}
