package com.hikvision.hae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by zhouziwei on 2017/11/3.
 */
@SpringBootApplication
public class FoundationApplication {
    public static void main(String[] args) throws Exception {
        SpringApplication.run(FoundationApplication.class, args);
    }
}
