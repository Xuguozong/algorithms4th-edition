package com.hikvision.hae.foundation.actionlog.biz;

import com.hikvision.hae.FoundationBaseTest;
import com.hikvision.hae.common.util.eventcenter.EventDispatcher;
import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.ImageActionType;
import com.hikvision.hae.common.util.eventcenter.enums.NodeActionType;
import com.hikvision.hae.common.util.eventcenter.enums.UserActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.util.eventcenter.event.UserLoginEvent;
import com.hikvision.hae.common.util.eventcenter.event.UserOperationEvent;
import com.hikvision.hae.foundation.actionlog.repo.ActionLogRepo;
import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Created by zhouziwei on 2017/11/9.
 */
public class ActionLogListenerTest extends FoundationBaseTest {
	private static ThreadLocal<DateFormat> threadLocal = ThreadLocal.withInitial(() -> new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));

	@MockBean
	private EventPublisher publisher;

	@MockBean
	private EventDispatcher eventDispatcher;

	@MockBean
	private ActionLogRepo actionLogRepo;

	@MockBean
	private ActionLogListener actionLogListener;

	@Test
	public void testAddActionLog() {
		UserLoginEvent ole = new UserLoginEvent();
		ole.setSource("UserAuth");
		ole.setPrincipalCategory(PrincipalCategory.USER);
		ole.setActionType(UserActionType.LOGIN);
		ole.setUserId("100");
		ole.setUserName("Zhangsan");
		ole.setUserIp("10.33.45.88");
		ole.setRemark("用户【张三】登录");

		publisher.publish(ole);

		try {
			Thread.sleep(13000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcess() {
		actionLogListener.process(setUserOperationEvent("4"));
		actionLogListener.process(setUserOperationEvent("3"));
	}

	@Test
	public void testProcess1() {
		actionLogListener.process(setUserLoginEvent("3"));
	}

	@Test
	public void testSupport() {
		actionLogListener.support(setUserLoginEvent("4"));
	}

	@Test
	public void testSupport1() {
		actionLogListener.support(setUserOperationEvent("4"));
	}

	@Test
	public void testInterest() {
		PrincipalCategory category = PrincipalCategory.NODE;
		PrincipalActionType actionType = NodeActionType.DELETE;
		actionLogListener.interest(category, actionType);
	}


	public UserOperationEvent setUserOperationEvent(String actorId) {
		UserOperationEvent event = new UserOperationEvent();
		event.setSource("source");
		event.setPrincipalCategory(PrincipalCategory.IMAGE);
		event.setActionType(ImageActionType.ADD);
		String occurTime = "2017-10-10 10:00:00";
		try {
			event.setOccurTime(threadLocal.get().parse(occurTime).toInstant());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		event.setPrincipalName("name");
		event.setPrincipalIndexCode("indexCode");
		event.setActorId(actorId);
		event.setActorIp("ip");
		event.setRemark("remark");
		return event;
	}

	public UserLoginEvent setUserLoginEvent(String actorId) {
		UserLoginEvent event = new UserLoginEvent();
		event.setSource("source");
		event.setPrincipalCategory(PrincipalCategory.NODE);
		event.setActionType(NodeActionType.ADD);
		String occurTime = "2017-10-10 10:00:00";
		try {
			event.setOccurTime(threadLocal.get().parse(occurTime).toInstant());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		event.setUserName("name");
		event.setUserId(actorId);
		event.setUserIp("ip");
		event.setRemark("remark");
		return event;
	}
}
