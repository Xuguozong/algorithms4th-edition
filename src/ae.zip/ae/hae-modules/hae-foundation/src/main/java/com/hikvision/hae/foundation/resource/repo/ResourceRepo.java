package com.hikvision.hae.foundation.resource.repo;

import com.hikvision.hae.foundation.resource.model.SysResource;

import java.util.List;

/**
 * 资源、资源操作及资源依赖的配置访问接口
 * <p>
 * Created by zhouziwei on 2017/11/3.
 */
public interface ResourceRepo {
     /* ************************* SysResource 开始************** */

    /**
     * 根据sysResourceId集合批量查询
     *
     * @param sysResourceIds sysResourceId集合
     * @return 系统资源集合
     */
    List<SysResource> listResourceByIds(List<Integer> sysResourceIds);

    /**
     * 查询出指定语言的所有系统资源
     *
     * @return 指定语言的所有系统资源
     */
    List<SysResource> listResource();

    /**
     * 根据父系统资源编码查询所有的第一层子系统资源
     *
     * @param parentSysResourceCode 父系统资源编码
     * @return 父系统资源的所有儿子系统资源
     */
    List<SysResource> listResourceByParentCode(String parentSysResourceCode);

    /**
     * 根据系统资源编码查询指定系统资源
     *
     * @param sysResourceCode 系统资源编码
     * @return 指定Code的系统资源
     */
    SysResource getResource(String sysResourceCode);

    /**
     * 根据系统资源编码查询指定系统资源
     *
     * @param sysResourceCode 系统资源编码
     * @param ignoreDeleted 忽略刪除标记
     * @return 指定Code的系统资源
     */
    SysResource getResource(String sysResourceCode, boolean ignoreDeleted);

    /**
     * 更新系统资源
     *
     * @param sysResource 系统资源对象
     * @return 大于0表示更新成功，反之失败
     */
    int updateSysResource(SysResource sysResource);

}
