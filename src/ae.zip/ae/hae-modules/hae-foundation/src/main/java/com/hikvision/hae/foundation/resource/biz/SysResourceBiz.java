package com.hikvision.hae.foundation.resource.biz;

import com.hikvision.hae.common.enums.Mode;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;

import java.util.List;

/**
 * 系统资源领域业务
 *
 * Created by zhouziwei on 2017/11/3.
 */
public interface SysResourceBiz {

    /**
     * 根据系统资源Id集合批量查询
     *
     * @param sysResourceIds 系统资源Id集合
     * @return 系统资源集合
     */
    List<SysResourceDTO> listResourceByIds(List<Integer> sysResourceIds);

    /**
     * 查询完整的树形结构的主系统资源
     *
     * @param layout 系统资源布局位置
     * @param mode 模式
     * @return 系统资源
     */
    SysResourceDTO getResourceTree(SysResourceLayout layout, Mode mode);

    /**
     * 根据父系统资源编码查询子系统资源， 不递归
     *
     * @param parentSysResourceCode 父系统资源编码
     * @return 系统资源集合
     */
    List<SysResourceDTO> listResourceByParentCode(String parentSysResourceCode);

    /**
     * 根据编码查询系统资源
     *
     * @param sysResourceCode 当前系统资源编码
     * @return 系统资源
     */
    SysResourceDTO getResourceByCode(String sysResourceCode);

    /**
     * 修改系统资源删除标记
     * @param deleted
     */
    void updateResourceDeletedFlag(String sysResourceCode, boolean deleted);

}
