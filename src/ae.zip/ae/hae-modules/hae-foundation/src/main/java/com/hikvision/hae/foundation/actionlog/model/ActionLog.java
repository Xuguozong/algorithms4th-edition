package com.hikvision.hae.foundation.actionlog.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;
import jef.database.annotation.Indexed;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by zhouziwei on 2017/11/1.
 */
@Entity
@Table(name = "action_log")
@Comment("操作日志")
public class ActionLog extends DataObject {

    private static final long serialVersionUID = -3189571432447051847L;

    @Id
    @GeneratedValue
    private int id;

    /**
     * 日志源，产生操作日志的业务模块
     */
    @Column(name = "log_source", length = 128, nullable = false)
    private String logSource;

    /**
     * 主体类别，操作对象类别
     */
    @Column(name = "principal_category", length = 64, nullable = false)
    private String principalCategory;

    /**
     * 主体对象名称
     */
    @Column(name = "principal_name")
    private String principalName;

    /**
     * 主体标识，能唯一标识一个主体
     */
    @Column(name = "principal_index_code", length = 64, nullable = false)
    private String principalIndexCode;

    /**
     * 操作类别，新增/修改/删除/登录等
     */
    @Column(name = "action_type", length = 64, nullable = false)
    private String actionType;

    /**
     * 日志内容,操作描述
     */
    @Column(name = "content", length = 2048)
    private String content;

    /**
     * 操作人（行为者）ID
     */
    @Column(name = "actor_id")
    @Indexed(name="idx_actionLog_actorId")
    private String actorId;

    /**
     * 操作人（行为者）IP
     */
    @Column(name = "actor_ip")
    private String actorIp;

    /**
     * 操作（动作行为）发生的时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "occur_time")
    @Indexed(name = "idx_actionLog_occurTime", desc = true)
    private Date occurTime;

    /**
     * 创建时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    public enum Field implements jef.database.Field {
        id, logSource, principalCategory, principalName, principalIndexCode, actionType, content, actorId ,actorIp, occurTime, created;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogSource() {
        return logSource;
    }

    public void setLogSource(String logSource) {
        this.logSource = logSource;
    }

    public String getPrincipalCategory() {
        return principalCategory;
    }

    public void setPrincipalCategory(String principalCategory) {
        this.principalCategory = principalCategory;
    }

    public String getPrincipalName() {
        return principalName;
    }

    public void setPrincipalName(String principalName) {
        this.principalName = principalName;
    }

    public String getPrincipalIndexCode() {
        return principalIndexCode;
    }

    public void setPrincipalIndexCode(String principalIndexCode) {
        this.principalIndexCode = principalIndexCode;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getActorId() {
        return actorId;
    }

    public void setActorId(String actorId) {
        this.actorId = actorId;
    }

    public String getActorIp() {
        return actorIp;
    }

    public void setActorIp(String actorIp) {
        this.actorIp = actorIp;
    }

    public Date getOccurTime() {
        return occurTime;
    }

    public void setOccurTime(Date occurTime) {
        this.occurTime = occurTime;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
