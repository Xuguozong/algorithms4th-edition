package com.hikvision.hae.foundation.user.biz;

import com.hikvision.hae.foundation.user.dto.UserDTO;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public interface UserBiz {

	UserDTO findByUsername(String username);

	boolean isUserExist(String username);

	void modifyPwd(String username, String newPwd);

}
