package com.hikvision.hae.foundation.resource.model;

/**
 * 菜单布局位置
 *
 * Created by zhouziwei on 2017/11/3.
 */
public enum SysResourceLayout {

    /**
     * 页面左侧一级菜单
     */
    LEFT_LV1(1),

    /**
     * 页面左侧二级菜单
     */
    LEFT_LV2(100),

    /**
     * 页面顶部
     */
    TOP(0),

    /**
     * 页面右侧
     */
    RIGHT(0),

    /**
     *  （虚拟布局位置）叶子菜单子功能（称为内嵌式资源），不在菜单树展示
     */
    NONE(0);

    /**
     * 数据库中保存的ID
     */
    private int id;

    private SysResourceLayout(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
