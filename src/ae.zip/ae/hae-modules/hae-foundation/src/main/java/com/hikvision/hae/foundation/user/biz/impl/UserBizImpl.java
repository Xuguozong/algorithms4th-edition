package com.hikvision.hae.foundation.user.biz.impl;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.foundation.common.constant.FoundationResultCode;
import com.hikvision.hae.foundation.common.util.PasswordUtils;
import com.hikvision.hae.foundation.user.biz.UserBiz;
import com.hikvision.hae.foundation.user.dto.UserDTO;
import com.hikvision.hae.foundation.user.repo.UserRepo;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
@Service
@Transactional
public class UserBizImpl implements UserBiz {

	@Autowired
	private UserRepo userRepo;

	@Override
	public UserDTO findByUsername(String username) {
		return UserDTO.fromUser(userRepo.findByUsernameAndStatusNot(username, 0));
	}

	@Override
	public boolean isUserExist(String username) {
		return userRepo.findByUsernameAndStatusNot(username, 0) != null;
	}

	@Override
	public void modifyPwd(String username, String newPwd) {
		modifyPwd(username, newPwd, false);
	}

	private void modifyPwd(String username, String newPwd, boolean forceModifyPwd) {
		int pwdStrength = PasswordUtils.getPwdRank(newPwd, username);
		if (pwdStrength < CommonConstants.WEAK_PASSWORD_LEVEL) {
			throw new HAERuntimeException(FoundationResultCode.RISK_PASSWORD_LEVEL);
		}
		String encryptPwd = BCrypt.hashpw(newPwd, BCrypt.gensalt());
		userRepo.updateUserPwd(username, encryptPwd, pwdStrength, forceModifyPwd);
	}

}
