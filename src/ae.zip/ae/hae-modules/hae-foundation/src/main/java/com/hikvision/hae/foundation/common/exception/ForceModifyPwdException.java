package com.hikvision.hae.foundation.common.exception;

import javax.security.auth.login.LoginException;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public class ForceModifyPwdException extends LoginException {

	private String userId;

	public ForceModifyPwdException(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
