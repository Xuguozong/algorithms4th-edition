package com.hikvision.hae.foundation.actionlog.repo.impl;

import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import com.hikvision.hae.foundation.actionlog.model.ActionLog;
import com.hikvision.hae.foundation.actionlog.repo.ActionLogRepo;
import jef.common.wrapper.Page;
import jef.database.Condition;
import jef.database.QB;
import org.easyframe.enterprise.spring.CommonDao;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 操作（行为、动作）日志数据访问接口实现
 *
 * Created by zhouziwei on 2017/11/20.
 */
@Component
public class ActionLogRepoImpl implements ActionLogRepo {
    @Resource
    private CommonDao dao;

    @Override
    public void insert(ActionLog actionLog) {
        actionLog.setCreated(new Date());
        dao.insert(actionLog);
    }

    @Override
    public Page<ActionLog> findAndPage(ActionLogQuery queryParam, PageParam pageParam) {
        ActionLog actionLog = new ActionLog();
        buildQueryCondition(actionLog, queryParam);
        actionLog.getQuery().addOrderBy(false, ActionLog.Field.occurTime);
        return dao.findAndPage(actionLog, pageParam.getStart(), pageParam.getPageSize());
    }

    private void buildQueryCondition(ActionLog actionLog, ActionLogQuery queryParam) {
        if (queryParam.getStartTime() != null) {
            actionLog.getQuery().addCondition(ActionLog.Field.occurTime, Condition.Operator.GREAT_EQUALS, queryParam.getStartTime());
        }

        if (queryParam.getEndTime() != null) {
            actionLog.getQuery().addCondition(ActionLog.Field.occurTime, Condition.Operator.LESS_EQUALS, queryParam.getEndTime());
        }

        if (StringUtils.isNotBlank(queryParam.getFq())) {
            //对“对象”和“内容”两项做模糊查询
            actionLog.getQuery().addCondition(QB.or(QB.matchAny(ActionLog.Field.principalName, queryParam.getFq()),
                    QB.matchAny(ActionLog.Field.content, queryParam.getFq())));
        }
    }
}
