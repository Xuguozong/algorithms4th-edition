package com.hikvision.hae.foundation.user.dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.github.geequery.orm.annotation.Comment;
import com.hikvision.hae.foundation.user.model.User;

import java.util.Date;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public class UserDTO {

	private String id;

	private String username;

	private String realName;

	/**
	 * 0：删除
	 * 1：启用
	 * 2：禁用
	 */
	private Integer status;

	private String email;

	private String phoneNumber;

	private String password;

	private Integer pwdStrength;

	private Date createTime;

	/**
	 * 是否强制修改密码
	 */
	private boolean forceModifyPwd;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getPwdStrength() {
		return pwdStrength;
	}

	public void setPwdStrength(Integer pwdStrength) {
		this.pwdStrength = pwdStrength;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public boolean isForceModifyPwd() {
		return forceModifyPwd;
	}

	public void setForceModifyPwd(boolean forceModifyPwd) {
		this.forceModifyPwd = forceModifyPwd;
	}

	public static UserDTO fromUser(User user) {
		if (user == null) {
			return null;
		}
		UserDTO userDTO = new UserDTO();
		userDTO.setId(user.getId());
		userDTO.setUsername(user.getUsername());
		userDTO.setPassword(user.getPassword());
		userDTO.setRealName(user.getRealName());
		userDTO.setEmail(user.getEmail());
		userDTO.setPhoneNumber(user.getPhoneNumber());
		userDTO.setPwdStrength(user.getPwdStrength());
		userDTO.setForceModifyPwd(user.isForceModifyPwd());
		userDTO.setStatus(user.getStatus());
		userDTO.setCreateTime(user.getCreateTime());
		return userDTO;
	}

}
