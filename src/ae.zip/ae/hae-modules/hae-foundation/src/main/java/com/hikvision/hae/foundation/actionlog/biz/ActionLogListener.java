package com.hikvision.hae.foundation.actionlog.biz;

import com.hikvision.hae.common.util.eventcenter.EventDispatcher;
import com.hikvision.hae.common.util.eventcenter.EventListener;
import com.hikvision.hae.common.util.eventcenter.event.*;
import com.hikvision.hae.foundation.actionlog.model.ActionLog;
import com.hikvision.hae.foundation.actionlog.repo.ActionLogRepo;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Date;

/**
 * 监听用户在HAE系统上的行为动作，记录操作日志
 *
 * Created by zhouziwei on 2017/11/1.
 */
@Component
public class ActionLogListener implements EventListener {

    @Resource
    private EventDispatcher eventDispatcher;

    @Resource
    private ActionLogRepo actionLogRepo;

    @PostConstruct
    public void init() {
        eventDispatcher.register(this); //向事件分发器注册自己
    }

    @Override
    public void process(Event event) {
        // 构建操作日志对象
        ActionLog actionLog = new ActionLog();
        actionLog.setLogSource(event.getSource());
        actionLog.setPrincipalCategory(event.getPrincipalCategory().name());
        actionLog.setActionType(event.getActionType().name());
        actionLog.setOccurTime(Date.from(event.getOccurTime()));
        if (event instanceof UserOperationEvent) {
            UserOperationEvent uoe = (UserOperationEvent) event;
            actionLog.setPrincipalName(uoe.getPrincipalName());
            actionLog.setPrincipalIndexCode(uoe.getPrincipalIndexCode());
            actionLog.setActorId(uoe.getActorId());
            actionLog.setActorIp(uoe.getActorIp());
            actionLog.setContent(uoe.getRemark());
        } else if (event instanceof UserLoginEvent) {
            UserLoginEvent loginEvent = (UserLoginEvent) event;
            actionLog.setPrincipalName(loginEvent.getUserName());
            actionLog.setPrincipalIndexCode(String.valueOf(loginEvent.getUserId()));
            actionLog.setActorId(loginEvent.getUserId());
            actionLog.setActorIp(loginEvent.getUserIp());
            actionLog.setContent(loginEvent.getRemark());
        }
        actionLogRepo.insert(actionLog);
    }

    @Override
    public boolean support(Event event) {
        return event instanceof UserOperationEvent || event instanceof UserLoginEvent;
    }

    @Override
    public boolean interest(PrincipalCategory category, PrincipalActionType actionType) {
        return true; // 对满足ActionLogListener.support方法支持的事件类别均记录日志
    }
}
