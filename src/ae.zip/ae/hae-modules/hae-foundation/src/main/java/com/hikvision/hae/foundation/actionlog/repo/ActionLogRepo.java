package com.hikvision.hae.foundation.actionlog.repo;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import com.hikvision.hae.foundation.actionlog.model.ActionLog;
import jef.common.wrapper.Page;

/**
 * 操作（行为、动作）日志数据访问接口
 * <p>
 * Created by zhouziwei on 2017/11/1.
 */
public interface ActionLogRepo {

    /**
     * 保存一条新的操作日志
     *
     * @param actionLog 待保存的操作日志
     */
    void insert(ActionLog actionLog);

    /**
     * 分页查询操作日志
     *
     * @param queryParam  查询条件
     * @param pageParam 分页参数
     * @return
     */
    Page<ActionLog> findAndPage(ActionLogQuery queryParam, PageParam pageParam);
}
