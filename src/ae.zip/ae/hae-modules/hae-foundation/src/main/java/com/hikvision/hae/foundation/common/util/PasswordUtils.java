package com.hikvision.hae.foundation.common.util;

import java.util.regex.Pattern;

/**
 * 密码工具类
 * 
 * @author zhanjiejun
 *
 */
public class PasswordUtils {

	private static final Pattern lowerCasePattern = Pattern.compile("[a-z]+");
	private static final Pattern upperCasePattern = Pattern.compile("[A-Z]+");
	private static final Pattern numberPattern = Pattern.compile("[0-9]+");
	private static final Pattern otherCasePattern = Pattern.compile("[^a-zA-Z0-9]+");

	/**
	 * 密码强度检测方法
	 * 
	 * @param szPwd
	 *            密码明文
	 * @param szUser
	 *            用户名
	 * @returns 0：风险 1：弱 2：中 3：高
	 */
	public static int getPwdRank(String szPwd, String szUser) {
		int iRank = 0;
		// 小写字母
		boolean lowerCaseMatch = lowerCasePattern.matcher(szPwd).find();
		// 大写字母
		boolean upperCaseMatch = upperCasePattern.matcher(szPwd).find();
		// 数字
		boolean numberMatch = numberPattern.matcher(szPwd).find();
		// 其它字符
		boolean otherCaseMatch = otherCasePattern.matcher(szPwd).find();

		if (lowerCaseMatch) {
			iRank++;
		}
		if (upperCaseMatch) {
			iRank++;
		}
		if (numberMatch) {
			iRank++;
		}
		if (otherCaseMatch) {
			iRank++;
		}
		iRank = (iRank > 3 ? 3 : iRank);
		if (szPwd.length() < 8 || iRank == 1 || szPwd.equals(szUser) || new StringBuffer(szUser).reverse().toString().equals(szPwd)) {
			iRank = 0;
		}
		if (iRank == 2) {
			if ((numberMatch && lowerCaseMatch) || (numberMatch && upperCaseMatch)) {
				iRank = 1;
			}
		}
		return iRank;
	}

}
