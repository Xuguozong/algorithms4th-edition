package com.hikvision.hae.foundation.common.exception;

import javax.security.auth.login.LoginException;

/**
 * 用户被冻结
 *
 * @author zhanjiejun
 */
public class UserFrozenException extends LoginException {

	private static final long serialVersionUID = 1L;

	public UserFrozenException() {
	}

}
