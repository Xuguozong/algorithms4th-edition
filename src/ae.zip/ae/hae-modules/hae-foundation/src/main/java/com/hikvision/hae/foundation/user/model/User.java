package com.hikvision.hae.foundation.user.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "user")
@Comment("用户")
public class User extends DataObject {

	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name = "username", unique = true, nullable = false)
	private String username;

	@Column(name = "real_name")
	private String realName;

	/**
	 * 0：删除
	 * 1：启用
	 * 2：禁用
	 */
	@Column(name = "status", nullable = false)
	private Integer status;

	private String email;

	@Column(name = "phone_number")
	private String phoneNumber;

	private String password;

	@Column(name = "pwd_strength", nullable = false)
	private Integer pwdStrength;

	@Column(name = "create_time")
	private Date createTime;

	/**
	 * 是否强制修改密码
	 */
	@Column(name = "is_force_modify_pwd")
	@Comment("是否强制修改密码")
	private boolean forceModifyPwd;

	public enum Field implements jef.database.Field {
		id, username, realName, status, email, phoneNumber, password, pwdStrength, createTime, forceModifyPwd
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getStatus() {
		return status;
	}

	public Integer getPwdStrength() {
		return pwdStrength;
	}

	public void setPwdStrength(Integer pwdStrength) {
		this.pwdStrength = pwdStrength;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public boolean isForceModifyPwd() {
		return forceModifyPwd;
	}

	public void setForceModifyPwd(boolean forceModifyPwd) {
		this.forceModifyPwd = forceModifyPwd;
	}

}
