package com.hikvision.hae.foundation.common.constant;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public class FoundationResultCode {

	/**
	 * 用户名或密码错误
	 */
	public static final int USERNAME_OR_PASSWORD_ERROR = 11000;

	/**
	 * 用户名或密码为空
	 */
	public static final int USERNAME_OR_PASSWORD_BLANK = 11001;

	/**
	 * 已存在登录的用户，请刷新页面
	 */
	public static final int SOME_ACCOUNT_ALREADY_LOGIN = 11002;

	/**
	 * 验证码错误
	 */
	public static final int WRONG_CAPTCHA = 11003;

	/**
	 * 该用户已被冻结
	 */
	public static final int USER_FROZEN = 11004;

	/**
	 * 用户不存在
	 */
	public static final int USER_NOT_EXIST = 11005;

	/**
	 * 不允许风险密码
	 */
	public static final int RISK_PASSWORD_LEVEL = 11006;

	/**
	 * 旧密码错误
	 */
	public static final int WRONG_OLD_PASSWORD = 11007;

	/**
	 * 访问系统资源数据异常
	 */
	public static final int ACCESS_SYS_RESOURCE_DATA_ERROR = 11050;

}
