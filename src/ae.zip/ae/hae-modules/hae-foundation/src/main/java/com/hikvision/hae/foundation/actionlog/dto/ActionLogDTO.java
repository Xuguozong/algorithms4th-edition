package com.hikvision.hae.foundation.actionlog.dto;

import com.hikvision.hae.common.util.eventcenter.enums.PrincipalActionTypeParser;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.foundation.actionlog.model.ActionLog;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhouziwei on 2017/11/1.
 */
public class ActionLogDTO implements Serializable {

    private static final long serialVersionUID = 7165517840169123650L;

    private int id;
    /**
     * 日志源，产生操作日志的业务模块
     */
    private String logSource;

    /**
     * 主体类别，操作对象类别
     */
    private PrincipalCategory principalCategory;

    /**
     * 主体对象名称
     */
    private String principalName;

    /**
     * 主体标识，能唯一标识一个主体
     */
    private String principalIndexCode;

    /**
     * 操作类别，新增/修改/删除/登录等
     */
    private PrincipalActionType actionType;

    /**
     * 日志内容,操作描述
     */
    private String content;

    /**
     * 操作人Id
     */
    private String actorId;

    /**
     * 操作人（行为者）IP
     */
    private String actorIp;

    /**
     * 操作（动作行为）发生的时间
     */
    private Date occurTime;

    /**
     * 创建时间
     */
    private Date created;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogSource() {
        return logSource;
    }

    public void setLogSource(String logSource) {
        this.logSource = logSource;
    }

    public PrincipalCategory getPrincipalCategory() {
        return principalCategory;
    }

    public void setPrincipalCategory(PrincipalCategory principalCategory) {
        this.principalCategory = principalCategory;
    }

    public String getPrincipalName() {
        return principalName;
    }

    public void setPrincipalName(String principalName) {
        this.principalName = principalName;
    }

    public String getPrincipalIndexCode() {
        return principalIndexCode;
    }

    public void setPrincipalIndexCode(String principalIndexCode) {
        this.principalIndexCode = principalIndexCode;
    }

    public PrincipalActionType getActionType() {
        return actionType;
    }

    public void setActionType(PrincipalActionType actionType) {
        this.actionType = actionType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getActorId() {
        return actorId;
    }

    public void setActorId(String actorId) {
        this.actorId = actorId;
    }

    public String getActorIp() {
        return actorIp;
    }

    public void setActorIp(String actorIp) {
        this.actorIp = actorIp;
    }

    public Date getOccurTime() {
        return occurTime;
    }

    public void setOccurTime(Date occurTime) {
        this.occurTime = occurTime;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public static ActionLogDTO readFromModel(ActionLog model) {
        ActionLogDTO dto = new ActionLogDTO();
        dto.setId(model.getId());
        dto.setLogSource(model.getLogSource());
        dto.setPrincipalCategory(PrincipalCategory.valueOf(model.getPrincipalCategory()));
        dto.setPrincipalIndexCode(model.getPrincipalIndexCode());
        dto.setPrincipalName(model.getPrincipalName());
        dto.setActionType(PrincipalActionTypeParser.parse(dto.getPrincipalCategory(), model.getActionType()));
        dto.setContent(model.getContent());
        dto.setActorId(model.getActorId());
        dto.setActorIp(model.getActorIp());
        dto.setOccurTime(model.getOccurTime());
        return dto;
    }
}
