package com.hikvision.hae.config;

import com.github.geequery.springdata.repository.config.EnableGqRepositories;
import org.easyframe.enterprise.spring.CommonDao;
import org.easyframe.enterprise.spring.CommonDaoImpl;
import org.easyframe.enterprise.spring.JefJpaDialect;
import org.easyframe.enterprise.spring.SessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement(proxyTargetClass = true)
@EnableConfigurationProperties(GeeQueryConfigProperties.class)
@EnableGqRepositories(basePackages = { "com.hikvision.hae" })
public class GeeQueryConfig {

	@Autowired
	private GeeQueryConfigProperties geeQueryConfigProperties;

	@Bean
	EntityManagerFactory entityManagerFactory(DataSource dataSource, Environment env) {
		SessionFactoryBean bean = new SessionFactoryBean();
		bean.setAllowDropColumn(geeQueryConfigProperties.isAllowDropColumn());
		bean.setCreateTable(geeQueryConfigProperties.isCreateTable());
		bean.setGlobalCacheLiveTime(geeQueryConfigProperties.getGlobalCacheLiveTime());
		bean.setDebug(geeQueryConfigProperties.isShowSql());
		bean.setDataSource(dataSource);
		bean.setPackagesToScan(geeQueryConfigProperties.getPackageToScan().split(","));
		bean.setAlterTable(geeQueryConfigProperties.isAlterTable());
		bean.afterPropertiesSet();
		return bean.getObject();
	}

	@Bean
	JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory);
		transactionManager.setJpaDialect(new JefJpaDialect());
		return transactionManager;
	}

	@Bean
	CommonDao commonDao(EntityManagerFactory entityManagerFactory) {
		return new CommonDaoImpl(entityManagerFactory);
	}
}
