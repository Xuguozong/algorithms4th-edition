package com.hikvision.hae.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 11:33 2018/3/20
 * @Description :  镜像相关异步线程池
 */
@Configuration
public class ImageAsynPoolConfig {

    @Value("${image.docker.build.coreSize:1}")
    private Integer dockerBuildCoreSize;

    @Bean
    public Executor getDockerBuildPool(){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(dockerBuildCoreSize);
        return executor;
    }
}
