package com.hikvision.hae.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * Created by zhanjiejun on 2017/12/13.
 */
@Configuration
@EnableCaching
public class CacheConfig {
}
