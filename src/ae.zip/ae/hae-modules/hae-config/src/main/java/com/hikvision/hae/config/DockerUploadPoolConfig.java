package com.hikvision.hae.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class DockerUploadPoolConfig {

    @Value("${docker.push.poolCoreSize:1}")
    private int pushCoreSize;

    @Value("${docker.merge.mergeCoreSize:3}")
    private int mergeCoreSize;

    @Value("${docker.merge.mergeCoreSize:5}")
    private int mergeMaxSize;

    @Value("${docker.merge.mergeQueueCapacity:100}")
    private int mergeQueueCapacity;

    @Bean
    public Executor getDockerPushPool(){
        ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        threadPoolTaskExecutor.setCorePoolSize(pushCoreSize);
        return threadPoolTaskExecutor;
    }

    @Bean
    Executor getDockerFileMergePool(){
        ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        threadPoolTaskExecutor.setQueueCapacity(mergeQueueCapacity);
        threadPoolTaskExecutor.setCorePoolSize(Math.min(mergeCoreSize,mergeMaxSize));
        threadPoolTaskExecutor.setMaxPoolSize(mergeMaxSize);
        return threadPoolTaskExecutor;
    }

}
