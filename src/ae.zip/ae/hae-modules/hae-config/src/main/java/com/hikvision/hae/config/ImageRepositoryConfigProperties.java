package com.hikvision.hae.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "image.config")
public class ImageRepositoryConfigProperties {

	private String harborUrl;

	private String harborUser;

	private String harborPassword;
	
	private String dockerServerUrl;

	public String getHarborUrl() {
		return harborUrl;
	}

	public void setHarborUrl(String harborUrl) {
		this.harborUrl = harborUrl;
	}

	public String getHarborUser() {
		return harborUser;
	}

	public void setHarborUser(String harborUser) {
		this.harborUser = harborUser;
	}

	public String getHarborPassword() {
		return harborPassword;
	}

	public void setHarborPassword(String harborPassword) {
		this.harborPassword = harborPassword;
	}

	public String getDockerServerUrl() {
		return dockerServerUrl;
	}

	public void setDockerServerUrl(String dockerServerUrl) {
		this.dockerServerUrl = dockerServerUrl;
	}
}
