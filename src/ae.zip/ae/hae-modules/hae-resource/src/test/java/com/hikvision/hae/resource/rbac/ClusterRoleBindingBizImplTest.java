package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.ClusterRoleBinding;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 9:40 2018/1/5
 * @Description :  集群角色绑定测试类
 */
public class ClusterRoleBindingBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private ClusterRoleBindingBiz clusterRoleBindingBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<ClusterRoleBinding> clusterRoleBindings = clusterRoleBindingBiz.find(filterQuery);
        printClusterRoleBindingMessage(clusterRoleBindings);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery =  FilterQuery.build();
        PageParam pageParam = new PageParam(1,10);
        Pagination<ClusterRoleBinding> pagination = clusterRoleBindingBiz.findAndPage(filterQuery, pageParam);
        printClusterRoleBindingMessage(pagination.getRows());
    }

    @Test
    public void getByName() {
        ClusterRoleBinding clusterRoleBinding = clusterRoleBindingBiz.getByName("root");
        System.out.println(null == clusterRoleBinding? "no clusterRoleBinding" : clusterRoleBinding.toString());
    }

    @Test
    public void delete() {
        clusterRoleBindingBiz.delete("role1234");
    }

    /**
     * 控制台打印信息
     * @param clusterRoleBindings
     */
    private void printClusterRoleBindingMessage(Collection<ClusterRoleBinding> clusterRoleBindings){
        clusterRoleBindings.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
