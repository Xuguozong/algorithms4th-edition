package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.RoleBinding;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 10:09 2018/1/5
 * @Description :  角色绑定测试类
 */
public class RoleBindingBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private RoleBindingBiz roleBindingBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<RoleBinding> roleBindings = roleBindingBiz.find(filterQuery);
        printRoleBindingMsg(roleBindings);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        PageParam pageParam = new PageParam(1,10);
        Pagination<RoleBinding> pagination = roleBindingBiz.findAndPage(filterQuery, pageParam);
        printRoleBindingMsg(pagination.getRows());
    }

    @Test
    public void getByName() {
        RoleBinding roleBinding = roleBindingBiz.getByName("default", "role123");
        System.out.println(null == roleBinding? "no roleBinding" : roleBinding.toString());
    }

    @Test
    public void delete() {
        roleBindingBiz.delete("default", "role123");
    }

    private void printRoleBindingMsg(Collection<RoleBinding> roleBindings){
        roleBindings.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
