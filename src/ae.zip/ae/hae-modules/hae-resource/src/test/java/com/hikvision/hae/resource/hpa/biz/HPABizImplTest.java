package com.hikvision.hae.resource.hpa.biz;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.HorizontalPodAutoscaler;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:16 2018/1/4
 * @Description :  pod水平自动扩展测试类
 */
public class HPABizImplTest extends HaeResourceBaseTest {

    @Autowired
    private HPABiz hpaBiz;

    @Test
    public void find() {
        List<HorizontalPodAutoscaler> horizontalPodAutoscalers = hpaBiz.find("default",
                ResourceKind.Pod, null);
        horizontalPodAutoscalers.forEach((e)->{
            System.out.println(e.toString());
        });
    }

    @Test
    public void delete() {
        hpaBiz.delete("default", "pod");
    }
}
