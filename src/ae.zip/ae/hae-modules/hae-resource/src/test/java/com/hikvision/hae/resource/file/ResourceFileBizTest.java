package com.hikvision.hae.resource.file;

import com.google.common.collect.Lists;
import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.resource.file.biz.ResourceFileBiz;
import com.hikvision.hae.resource.file.dto.ResourceFileDTO;
import com.hikvision.hae.resource.file.dto.ResourceFileGroupDTO;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/17.
 */
public class ResourceFileBizTest extends HaeResourceBaseTest {

    @Resource
    private ResourceFileBiz resourceFileBiz;

    @Test
    public void createGroup() {
        ResourceFileGroupDTO g = new ResourceFileGroupDTO();
        g.setGroupName("aa");
        g = resourceFileBiz.createGroup(g);
        System.out.println(g.getId() + ":" + g.getGroupName());
    }

    @Test
    public void createFiles() {
        ResourceFileDTO f1 = new ResourceFileDTO();
        f1.setGroupId(2);
        f1.setFileName("a.json");
        f1.setContent("aaaxxx");

        ResourceFileDTO f2 = new ResourceFileDTO();
        f2.setGroupId(2);
        f2.setFileName("b.json");
        f2.setContent("yyyyy");

        List<ResourceFileDTO> files = Lists.newArrayList(f1, f2);
        resourceFileBiz.createFiles(files);
    }

    @Test
    public void findAndPageGroup() {
//        PageParam pageParam
//        Pagination<ResourceFileGroupDTO>
    }

    @Test
    public void findFilesByGroup() {
//        int groupId
//        List<ResourceFileDTO>
    }

    @Test
    public void loadFile() {
//        int fileId
//        ResourceFileDTO
    }

    @Test
    public void findGroupByName(){
        ResourceFileGroupDTO resourceFileGroupDTO = resourceFileBiz.findGroupByName("wyqtest");
        System.out.println("groupName : wyqtest , id : "+resourceFileGroupDTO.getId());
    }

    @Test
    public void updateGroup(){
        resourceFileBiz.updateGroup(14,"haerrrrr");
    }
}
