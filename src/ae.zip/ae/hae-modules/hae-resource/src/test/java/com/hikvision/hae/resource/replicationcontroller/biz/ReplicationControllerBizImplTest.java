package com.hikvision.hae.resource.replicationcontroller.biz;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.ReplicationController;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 11:09 2018/1/5
 * @Description :  副本控制器测试类
 */
public class ReplicationControllerBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private ReplicationControllerBiz replicationControllerBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<ReplicationController> replicationControllers = replicationControllerBiz.find(filterQuery);
        printReplicationControllerMsg(replicationControllers);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        PageParam pageParam = new PageParam(1,10);
        Pagination<ReplicationController> pagination = replicationControllerBiz.findAndPage(filterQuery, pageParam);
        printReplicationControllerMsg(pagination.getRows());
    }

    @Test
    public void getByName() {
        ReplicationController replicationController = replicationControllerBiz.getByName("ddefault","12345");
        System.out.println(null == replicationController? "no replicationController" : replicationController.toString());
    }

    /**
     * 控制台打印副本控制器
     * @param replicationControllers
     */
    private void printReplicationControllerMsg(Collection<ReplicationController> replicationControllers){
        replicationControllers.forEach(e->{
            System.out.println(e.toString());
        });
    }
}
