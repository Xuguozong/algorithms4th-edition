package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.Role;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 10:11 2018/1/5
 * @Description :  k8s角色测试类
 */
public class RoleBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private RoleBiz roleBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<Role> roles = roleBiz.find(filterQuery);
        printRoleMsg(roles);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        PageParam pageParam = new PageParam(1,10);
        Pagination<Role> pagination = roleBiz.findAndPage(filterQuery, pageParam);
        printRoleMsg(pagination.getRows());
    }

    @Test
    public void getByName() {
        Role role = roleBiz.getByName("default", "role123");
        System.out.println(null == role? "no role" : role.toString());
    }

    @Test
    public void delete() {
        roleBiz.delete("default", "role123");
    }

    /**
     * 控制台打印角色信息
     * @param roles
     */
    private void printRoleMsg(Collection<Role> roles){
        roles.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
