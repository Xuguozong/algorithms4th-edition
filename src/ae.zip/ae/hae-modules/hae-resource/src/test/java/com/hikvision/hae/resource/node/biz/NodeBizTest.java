package com.hikvision.hae.resource.node.biz;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

/**
 * Created by zhanjiejun on 2017/11/8.
 */
public class NodeBizTest extends HaeResourceBaseTest {

	@Autowired
	private NodeBiz nodeBiz;

	@Test
	public void testFindAndPageNodes() {
		Page<NodeBaseDTO> pages = nodeBiz.findAndPageNodes(1, 10, null);
		System.out.println("【BreakPoint】");
	}

	@Test
	public void testMergeNodeLabel() {
		KeyValue label = new KeyValue("kube-test", "unit");
		nodeBiz.mergeNodeLabel(3, label);
	}

	@Test
	public void testDeleteNodeLabel() {
		nodeBiz.deleteNodeLabel(3, "kube-test");
	}

	@Test
	public void testMaintainNode() {
		nodeBiz.maintainNode(3);
	}

	@Test
	public void testExitMaintainNode() {
		nodeBiz.exitMaintainNode(3);
	}

	@Test
	public void testAddNode() throws Exception {
		NodeBaseDTO nodeBaseDTO = new NodeBaseDTO();
		nodeBaseDTO.setIp("10.33.65.133");
		nodeBaseDTO.setSshPwd("12345678");
		nodeBaseDTO.setName("node1");
		nodeBiz.addNode(nodeBaseDTO);
		Thread.sleep(180000l);
	}

	@Test
	public void testHardDeleteNode() throws Exception {
		nodeBiz.hardDeleteNode(4);
		Thread.sleep(180000l);
	}

}
