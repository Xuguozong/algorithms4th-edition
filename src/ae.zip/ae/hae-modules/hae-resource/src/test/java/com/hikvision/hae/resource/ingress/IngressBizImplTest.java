package com.hikvision.hae.resource.ingress;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.extensions.Ingress;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:24 2018/1/4
 * @Description :  ingress资源对象测试类
 */
public class IngressBizImplTest extends HaeResourceBaseTest {
    
    @Autowired
    private IngressBiz ingressBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<Ingress> ingresses = ingressBiz.find(filterQuery);
        printIngressMessage(ingresses);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        Pagination<Ingress> ingressPagination = ingressBiz.findAndPage(filterQuery, new PageParam(1, 10));
        printIngressMessage(ingressPagination.getRows());
    }

    @Test
    public void getByName() {
        Ingress ingress = ingressBiz.getByName("default", "mysql");
        System.out.println(ingress.toString());
    }

    @Test
    public void delete() {
        ingressBiz.delete("default", "mysql");
    }

    /**
     * 控制台打印信息
     * @param ingresses
     */
    private void printIngressMessage(Collection<Ingress> ingresses){
        ingresses.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
