package com.hikvision.hae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author jianghaiyang5 on 2017/11/3.
 */
@SpringBootApplication
public class HaeResourceApplication {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(HaeResourceApplication.class, args);
    }
}
