package com.hikvision.hae.resource.rbac.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.common.operation.KubeRawHttpOperation;
import com.hikvision.hae.resource.rbac.ClusterRoleBindingBiz;
import io.fabric8.openshift.api.model.ClusterRoleBinding;
import io.fabric8.openshift.api.model.ClusterRoleBindingList;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/12/21.
 */
@Service
public class ClusterRoleBindingBizImpl extends KubeRawHttpOperation<ClusterRoleBinding, ClusterRoleBindingList>
        implements ClusterRoleBindingBiz {

    @PostConstruct
    @Override
    public void init() {
        KubeOperationFactory.register(ResourceKind.ClusterRoleBinding, this);
    }

    @Override
    protected ResourceKind getResourceKindType() {
        return ResourceKind.ClusterRoleBinding;
    }

    @Override
    protected Class<ClusterRoleBinding> getResourceType() {
        return ClusterRoleBinding.class;
    }

    @Override
    protected Class<ClusterRoleBindingList> getResourceListType() {
        return ClusterRoleBindingList.class;
    }

    @Override
    public ClusterRoleBinding getByName(String name) {
        return super.getByName(null, name);
    }

    @Override
    public void delete(String name) {
        super.delete(null, name);
    }
}
