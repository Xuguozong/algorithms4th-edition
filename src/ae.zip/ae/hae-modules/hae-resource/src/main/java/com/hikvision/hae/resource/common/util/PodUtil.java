package com.hikvision.hae.resource.common.util;

import com.hikvision.hae.common.domain.PodResourceCount;
import com.hikvision.hae.common.util.K8SResourceUnitConverter;
import com.hikvision.hae.resource.common.enums.PodPhase;
import com.hikvision.hae.resource.common.enums.ResourceQuotaKind;
import io.fabric8.kubernetes.api.model.*;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * Created by zhanjiejun on 2018/4/9.
 */
public class PodUtil {

	public static PodResourceCount calculateResource(Pod pod) {
		PodResourceCount podResourceCount = new PodResourceCount();
		double cpuRequest = 0;
		double cpuLimit = 0;
		double memoryRequest = 0;
		double memoryLimit = 0;
		int gpuRequest = 0;
		int gpuLimit = 0;
		List<Container> containers = pod.getSpec().getContainers();
		List<Container> initContainers = pod.getSpec().getInitContainers();
		if (!CollectionUtils.isEmpty(initContainers)) {
			containers.addAll(initContainers);
		}
		for (Container container : containers) {
			ResourceRequirements resourceRequirements = container.getResources();
			if (resourceRequirements != null) {
				Map<String, Quantity> requests = resourceRequirements.getRequests();
				if (requests != null) {
					Quantity cpuReq = requests.get(ResourceQuotaKind.CPU.getKey());
					cpuRequest += cpuReq != null ? K8SResourceUnitConverter.convertCPU2Cores(cpuReq.getAmount()) : 0;
					Quantity memoryReq = requests.get(ResourceQuotaKind.MEMORY.getKey());
					memoryRequest += memoryReq != null ? K8SResourceUnitConverter.convertMemory2Gi(memoryReq.getAmount()) : 0;
					Quantity gpuReq = requests.get(ResourceQuotaKind.GPU.getKey());
					gpuRequest += gpuReq != null ? Integer.valueOf(gpuReq.getAmount()) : 0;
				}
				Map<String, Quantity> limits = resourceRequirements.getLimits();
				if (limits != null) {
					Quantity cpuLim = limits.get(ResourceQuotaKind.CPU.getKey());
					cpuLimit += cpuLim != null ? K8SResourceUnitConverter.convertCPU2Cores(cpuLim.getAmount()) : 0;
					Quantity memoryLim = limits.get(ResourceQuotaKind.MEMORY.getKey());
					memoryLimit += memoryLim != null ? K8SResourceUnitConverter.convertMemory2Gi(memoryLim.getAmount()) : 0;
					Quantity gpuLim = limits.get(ResourceQuotaKind.GPU.getKey());
					gpuLimit += gpuLim != null ? Integer.valueOf(gpuLim.getAmount()) : 0;
				}
			}
		}
		podResourceCount.setCpuLimit(cpuLimit);
		podResourceCount.setCpuRequest(cpuRequest);
		podResourceCount.setGpuLimit(gpuLimit);
		podResourceCount.setGpuRequest(gpuRequest);
		podResourceCount.setMemoryLimit(memoryLimit);
		podResourceCount.setMemoryRequest(memoryRequest);
		return podResourceCount;
	}

	public static boolean isPodRunning(Pod pod) {
		if (PodPhase.Running.name().equalsIgnoreCase(pod.getStatus().getPhase())) {
			// 参见ResourceVOBuilder 296行注释
			ContainerStatus firstStatus = pod.getStatus().getContainerStatuses().get(0);
			if (firstStatus.getState().getRunning() != null) {
				return true;
			}
		}
		return false;
	}

}
