package com.hikvision.hae.resource.namespace.dto;

import io.fabric8.kubernetes.api.model.Quantity;

import java.util.Date;
import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/9.
 */
public class NamespaceReadDTO {

	private String name;

	private NamespaceStatus status;

	private Date createTime;

	/**
	 * 配额总量
	 */
	private Map<String, Quantity> hard;

	/**
	 * 配额使用量
	 */
	private Map<String, Quantity> used;

	private boolean isK8SDefault;

	private boolean hasResourceQuota;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public NamespaceStatus getStatus() {
		return status;
	}

	public void setStatus(NamespaceStatus status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Map<String, Quantity> getHard() {
		return hard;
	}

	public void setHard(Map<String, Quantity> hard) {
		this.hard = hard;
	}

	public Map<String, Quantity> getUsed() {
		return used;
	}

	public void setUsed(Map<String, Quantity> used) {
		this.used = used;
	}

	public boolean isK8SDefault() {
		return isK8SDefault;
	}

	public void setK8SDefault(boolean k8SDefault) {
		isK8SDefault = k8SDefault;
	}

	public boolean isHasResourceQuota() {
		return hasResourceQuota;
	}

	public void setHasResourceQuota(boolean hasResourceQuota) {
		this.hasResourceQuota = hasResourceQuota;
	}
}
