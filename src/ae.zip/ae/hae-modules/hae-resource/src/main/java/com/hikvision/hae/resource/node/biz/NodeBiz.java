package com.hikvision.hae.resource.node.biz;

import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import com.hikvision.hae.resource.node.dto.NodeDTO;
import io.fabric8.kubernetes.api.model.Pod;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Map;

/**
 * 节点管理Biz层
 * Created by zhanjiejun on 2017/11/2.
 */
public interface NodeBiz {

	/**
	 * 分页查询节点
	 *
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	Page<NodeBaseDTO> findAndPageNodes(int pageNo, int pageSize, String fuzzyQuery);

	/**
	 * 查询所有节点
	 *
	 * @return
	 */
	List<NodeBaseDTO> listNodes();

	/**
	 * 添加节点
	 *
	 * @param nodeBaseDTO
	 */
	int addNode(NodeBaseDTO nodeBaseDTO);

	/**
	 * 硬删除节点
	 *
	 * @param id
	 */
	NodeBaseDTO hardDeleteNode(int id);

	/**
	 * 软删除节点
	 *
	 * @param id
	 */
	NodeBaseDTO softDeleteNode(int id);

	/**
	 * 获取节点详情
	 *
	 * @param id
	 * @return
	 */
	NodeBaseDTO getNodeBaseDetail(int id);

	/**
	 * 保存节点标签
	 *
	 * @param label
	 */
	NodeBaseDTO mergeNodeLabel(int id, KeyValue label);

	/**
	 * 删除节点标签
	 *
	 * @param labelKey
	 */
	NodeBaseDTO deleteNodeLabel(int id, String labelKey);

	/**
	 * 维护节点
	 *
	 * @param id
	 */
	NodeBaseDTO maintainNode(int id);

	/**
	 * 退出维护
	 *
	 * @param id
	 */
	NodeBaseDTO exitMaintainNode(int id);

	/**
	 * 校验名称是否存在
	 *
	 * @param name
	 * @param id
	 * @return true 已存在 false 不存在
	 */
	boolean isNameExist(String name, int id);

	/**
	 * 校验IP是否存在
	 *
	 * @param ip
	 * @return true 已存在 false 不存在
	 */
	boolean isIpExist(String ip);

	/**
	 * 校验节点上标签是否存在
	 *
	 * @param labelKey
	 * @param id
	 * @return true 已存在 false 不存在
	 */
	boolean isLabelKeyExist(String labelKey, int id);

	/**
	 * 获取节点资源详情
	 *
	 * @param id
	 * @return
	 */
	NodeDTO getNodeDetail(int id);

	/**
	 * 修改节点
	 *
	 * @param nodeBaseDTO
	 */
	NodeBaseDTO updateNode(NodeBaseDTO nodeBaseDTO);

	/**
	 * 根据K8S中节点名获取数据库中节点名
	 *
	 * @param k8sName
	 * @return
	 */
	String getNodeNameByK8SName(String k8sName);

	/**
	 * 获取所有节点名称映射
	 *
	 * @return key -> k8sName value -> name
	 */
	Map<String, String> getK8SNameNodeNameMap();

	/**
	 * 根据ID获取节点数据库中信息
	 *
	 * @param id
	 * @return
	 */
	NodeBaseDTO getNodeDBInfoById(int id);

	/**
	 * 同步节点列表
	 */
	void syncNodeList();

	NodeBaseDTO getNodeDBInfoByK8SName(String k8sName);

}
