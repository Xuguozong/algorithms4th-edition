package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.RoleBinding;

import java.util.List;

/**
 * RBAC RoleBinding操作
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
public interface RoleBindingBiz {

    /**
     * 查询满足条件的所有 RbacRoleBinding
     *
     * @param filterQuery 查询条件
     * @return RbacRoleBinding 对象列表
     */
    List<RoleBinding> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有 RbacRoleBinding
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return RbacRoleBinding 对象列表
     */
    Pagination<RoleBinding> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定name的 RbacRoleBinding
     *
     * @param namespace RbacRoleBinding 所在的namespace
     * @param name      RbacRoleBinding 的名称
     * @return null或者 RbacRoleBinding 对象
     */
    RoleBinding getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的 RbacRoleBinding
     *
     * @param namespace RbacRoleBinding 所在的namespace
     * @param name      RbacRoleBinding 的名称
     */
    void delete(String namespace, String name);
}
