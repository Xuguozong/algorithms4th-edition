package com.hikvision.hae.resource.hpa.biz;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.HorizontalPodAutoscaler;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
public interface HPABiz {
    /**
     * 查询指定资源的所有HPA实例
     *
     * @param namespace  资源的命名空间
     * @param targetKind 伸缩的目标资源类型
     * @param targetName 伸缩的目标资源名称
     * @return HPA实例集合
     */
    List<HorizontalPodAutoscaler> find(String namespace, ResourceKind targetKind, String targetName);

    /**
     * 删除指定namespace和name的HPA
     *
     * @param namespace HPA所在的namespace
     * @param name      HPA的名称
     */
    void delete(String namespace, String name);
}
