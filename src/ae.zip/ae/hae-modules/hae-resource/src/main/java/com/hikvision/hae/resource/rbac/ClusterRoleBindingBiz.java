package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.ClusterRoleBinding;

import java.util.List;

/**
 * RBAC ClusterRoleBinding 操作
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
public interface ClusterRoleBindingBiz {

    /**
     * 查询满足条件的所有 RbacClusterRoleBinding
     *
     * @param filterQuery 查询条件
     * @return RbacClusterRoleBinding 对象列表
     */
    List<ClusterRoleBinding> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有 RbacClusterRoleBinding
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return RbacClusterRoleBinding 对象列表
     */
    Pagination<ClusterRoleBinding> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定name的 RbacClusterRoleBinding
     *
     * @param name RbacClusterRoleBinding 的名称
     * @return null或者 RbacClusterRoleBinding 对象
     */
    ClusterRoleBinding getByName(String name);

    /**
     * 删除指定namespace和name的 RbacClusterRoleBinding
     *
     * @param name RbacClusterRoleBinding 的名称
     */
    void delete(String name);
}
