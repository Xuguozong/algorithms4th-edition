package com.hikvision.hae.resource.common.operation;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.HasMetadata;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * K8S资源的操作对象（Biz实例）的注册中心（所有的操作对象在初始化后均需注册），并提供按 {@code ResourceKind}获取已注册对象的静态方法
 *
 * @author jianghaiyang5 on 2017/11/10.
 */
public class KubeOperationFactory {

    private static Map<ResourceKind, KubeOperation<? extends HasMetadata>> resourceBizRegistry = new ConcurrentHashMap<>();

    /**
     * 注册操作对象
     *
     * @param kind 资源类型
     * @param operation 资源的操作对象
     */
    public static void register(ResourceKind kind, KubeOperation<? extends HasMetadata> operation) {
        resourceBizRegistry.put(kind, operation);
    }

    /**
     * 查询已注册的指定类型资源的操作对象
     *
     * @param kind 资源类型
     * @return 资源的操作对象
     */
    public static KubeOperation<? extends HasMetadata> getOperation(ResourceKind kind) {
        return resourceBizRegistry.get(kind);
    }

}
