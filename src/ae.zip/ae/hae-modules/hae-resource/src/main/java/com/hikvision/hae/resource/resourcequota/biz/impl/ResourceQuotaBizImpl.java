package com.hikvision.hae.resource.resourcequota.biz.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.resourcequota.biz.ResourceQuotaBiz;
import io.fabric8.kubernetes.api.model.DoneableResourceQuota;
import io.fabric8.kubernetes.api.model.ResourceQuota;
import io.fabric8.kubernetes.api.model.ResourceQuotaList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author by zhouzhigang6 on 2018/1/16.
 */
@Service
public class ResourceQuotaBizImpl extends KubeMixedOperation<ResourceQuota, ResourceQuotaList, DoneableResourceQuota, Resource<ResourceQuota, DoneableResourceQuota>>
		implements ResourceQuotaBiz {

	@Override
	@PostConstruct
	public void init() {
		// 暂时不支持ResourceQuota的创建
		// KubeOperationFactory.register(ResourceKind.ResourceQuota, this);
	}

	@Override
	public MixedOperation<ResourceQuota, ResourceQuotaList, DoneableResourceQuota, Resource<ResourceQuota, DoneableResourceQuota>> getKubeOperation() {
		return kubeClient.resourceQuotas();
	}
}
