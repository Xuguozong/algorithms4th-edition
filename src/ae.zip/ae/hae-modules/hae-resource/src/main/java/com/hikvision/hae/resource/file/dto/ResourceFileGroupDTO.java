package com.hikvision.hae.resource.file.dto;

import com.hikvision.hae.resource.file.model.KubeResourceFileGroup;

import java.io.Serializable;
import java.util.Date;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
public class ResourceFileGroupDTO implements Serializable {
    private static final long serialVersionUID = -1254570207788981522L;

    private int id;

    private String groupName;

    private Date createTime;

    public ResourceFileGroupDTO() {
    }

    public ResourceFileGroupDTO(String groupName) {
        this.groupName = groupName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public static ResourceFileGroupDTO readFromModel(KubeResourceFileGroup model) {
        ResourceFileGroupDTO dto = new ResourceFileGroupDTO();
        dto.setId(model.getId());
        dto.setGroupName(model.getGroupName());
        dto.setCreateTime(model.getCreateTime());
        return dto;
    }

    public KubeResourceFileGroup convertToModel() {
        KubeResourceFileGroup model = new KubeResourceFileGroup();
        model.setId(this.getId());
        model.setGroupName(this.getGroupName());
        model.setCreateTime(this.getCreateTime());
        return model;
    }
}
