package com.hikvision.hae.resource.replicationcontroller.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.ReplicationController;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/13.
 */
public interface ReplicationControllerBiz {

    /**
     * 查询满足条件的所有ReplicationController
     *
     * @param filterQuery 查询条件
     * @return ReplicationController对象列表
     */
    List<ReplicationController> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有ReplicationController
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return ReplicationController对象列表
     */
    Pagination<ReplicationController> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的ReplicationController
     *
     * @param namespace ReplicationController所在的namespace
     * @param name      ReplicationController的名称
     * @return null或者ReplicationController对象
     */
    ReplicationController getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的ReplicationController
     *
     * @param namespace ReplicationController所在的namespace
     * @param name      ReplicationController的名称
     */
    void delete(String namespace, String name);

    /**
     * 伸缩Pod数量
     *
     * @param namespace ReplicationController所在的namespace
     * @param name      ReplicationController的名称
     * @param newNum    新数量
     * @return 新ReplicationController对象
     */
    ReplicationController scale(String namespace, String name, int newNum);
}
