package com.hikvision.hae.resource.event.biz.impl;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.event.biz.EventBiz;

import io.fabric8.kubernetes.api.model.DoneableEvent;
import io.fabric8.kubernetes.api.model.Event;
import io.fabric8.kubernetes.api.model.EventList;
import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
@Service
public class EventBizImpl
        extends KubeMixedOperation<Event, EventList, DoneableEvent, Resource<Event, DoneableEvent>>
        implements EventBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.Event, this);
    }

    @Override
    public MixedOperation<Event, EventList, DoneableEvent, Resource<Event, DoneableEvent>> getKubeOperation() {
        return kubeClient.events();
    }

    @Override
    public Pagination<Event> findAndPage(String namespace, ResourceKind kind, String resourceName, PageParam pageParam) {
        FilterQuery filterQuery = FilterQuery.build().namespace(namespace);
        
        // 找到owner的uid
        KubeOperation<?> kubeOperation = getKubeOperation(kind);
		HasMetadata kubeRes = kubeOperation.getByName(namespace, resourceName);
		String ownerUid = kubeRes.getMetadata().getUid();
        
        if (ownerUid != null) {
            filterQuery.field(ResourceConstants.EVENT_INVOLVED_UID_FIELD, ownerUid);
        }
        return super.findAndPage(filterQuery, pageParam);
    }

    @Override
    public List<Event> find(String namespace, ResourceKind kind, String resourceName, String uid, String type) {
        FilterQuery filterQuery = FilterQuery.build().namespace(namespace);
        
        String ownerUid = uid;
     
        // 资源id为空的时候，取得资源ID
        if(ownerUid == null){
        	
        	if(resourceName == null){
        		filterQuery.field(ResourceConstants.EVENT_INVOLVED_KIND_FIELD, kind.name());
        	}else{
        		KubeOperation<?> kubeOperation = getKubeOperation(kind);
        		HasMetadata kubeRes = kubeOperation.getByName(namespace, resourceName);
        		ownerUid = kubeRes.getMetadata().getUid();
        	}
        }

        if (ownerUid != null) {
        	filterQuery.field(ResourceConstants.EVENT_INVOLVED_UID_FIELD, ownerUid);
        }
        
        if (type != null) {
            filterQuery.field(ResourceConstants.EVENT_TYPE_FIELD, type);
        }
        return super.find(filterQuery);
    }

	@Override
	public List<Event> findAll() {
		return getKubeOperation().inAnyNamespace().list().getItems();
	}

	/**
     * 获取资源
     * @param kind 资源种类
     * @return 资源
     */
    private KubeOperation<? extends HasMetadata> getKubeOperation(ResourceKind kind) {
        KubeOperation<? extends HasMetadata> kubeOperation = KubeOperationFactory.getOperation(kind);
        Assert.notNull(kubeOperation, "未注册资源【" + kind + "】的操作对象");
        return kubeOperation;
    }
}
