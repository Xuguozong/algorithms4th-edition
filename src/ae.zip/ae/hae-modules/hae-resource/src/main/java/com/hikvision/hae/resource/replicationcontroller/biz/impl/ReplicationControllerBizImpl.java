package com.hikvision.hae.resource.replicationcontroller.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.replicationcontroller.biz.ReplicationControllerBiz;
import io.fabric8.kubernetes.api.model.DoneableReplicationController;
import io.fabric8.kubernetes.api.model.ReplicationController;
import io.fabric8.kubernetes.api.model.ReplicationControllerList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.RollableScalableResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/11/13.
 */
@Service
public class ReplicationControllerBizImpl
        extends KubeMixedOperation<ReplicationController, ReplicationControllerList, DoneableReplicationController,
        RollableScalableResource<ReplicationController, DoneableReplicationController>>
        implements ReplicationControllerBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.ReplicationController, this);
    }

    @Override
    public ReplicationController scale(String namespace, String name, int newNum) {
        ReplicationController rc = super.getByName(namespace, name);
        if (rc == null) {
            throw new HAERuntimeException(ResourceResultCode.REPLICATION_CONTROLLER_NOT_EXIST);
        }
        if (rc.getSpec().getReplicas() == newNum) {
            return rc;
        }
        return getKubeOperation().inNamespace(namespace).withName(name).scale(newNum);
    }

    @Override
    public MixedOperation<ReplicationController, ReplicationControllerList, DoneableReplicationController,
            RollableScalableResource<ReplicationController, DoneableReplicationController>> getKubeOperation() {
        return kubeClient.replicationControllers();
    }
}
