package com.hikvision.hae.resource.common.rawresource;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import io.fabric8.kubernetes.client.utils.Serialization;
import io.fabric8.kubernetes.client.utils.URLUtils;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * 调用K8S原生的HTTP API。主要用于一些fabric8不支持或支持的不太好的资源操作
 *
 * @author jianghaiyang5 on 2017/11/9.
 */
public class ResourceHttpClient<T> {
    private Logger logger = LoggerFactory.getLogger(ResourceHttpClient.class);
    private static final MediaType MEDIA_TYPE_JSON = MediaType.parse("application/json");

    private String k8sMasterUrl;

    private OkHttpClient client;
    private String apiGroup;
    private String apiVersion;
    private String resourceType;
    private Class<T> outputType;

    public ResourceHttpClient() {
    }

    public ResourceHttpClient(String k8sMasterUrl, OkHttpClient client, String apiGroup, String apiVersion, String resourceType, Class<T>
            outputType) {
        this.k8sMasterUrl = k8sMasterUrl;
        this.client = client;
        this.apiGroup = apiGroup;
        this.apiVersion = apiVersion;
        this.resourceType = resourceType;
        this.outputType = outputType;
    }


    private URL getRootUrl() {
        try {
            if (apiGroup != null) {
                return new URL(URLUtils.join(k8sMasterUrl, "apis", apiGroup, apiVersion));
            }
            return new URL(URLUtils.join(k8sMasterUrl, "api", apiVersion));
        } catch (MalformedURLException e) {
            throw new HAERuntimeException(CommonResultCode.MALFORMED_URL_ERROR, e);
        }
    }

    public URL getNamespacedResourceUrl(String namespace, String name) {
        URL requestUrl = getRootUrl();
        try {
            if (namespace != null) {
                requestUrl = new URL(URLUtils.join(requestUrl.toString(), "namespaces", namespace));
            }
            requestUrl = new URL(URLUtils.join(requestUrl.toString(), resourceType));
            if (name != null) {
                requestUrl = new URL(URLUtils.join(requestUrl.toString(), name));
            }
        } catch (MalformedURLException e) {
            throw new HAERuntimeException(CommonResultCode.MALFORMED_URL_ERROR, e);
        }
        return requestUrl;
    }

    /**
     * 处理Get请求，并以字符串形式返回原始响应的body内容
     *
     * @param namespace 命名空间，非命名空间的资源可以为null
     * @param name      k8s资源名称
     * @return 响应body内容
     */
    public String handleGetRequest(String namespace, String name) {
        URL resourceUrl = getNamespacedResourceUrl(namespace, name);
        Request.Builder requestBuilder = new Request.Builder().get().url(resourceUrl);
        return invoke(requestBuilder);
    }

    /**
     * 处理Post请求
     *
     * @param namespace    命名空间，非命名空间的资源可以为null
     * @param resourceJson 资源的完整的JSON格式的定义
     * @return 处理后的资源对象
     */
    public T handleCreateRequest(String namespace, String resourceJson) {
        URL resourceUrl = getNamespacedResourceUrl(namespace, null);
        Request.Builder requestBuilder = new Request.Builder()
                .post(RequestBody.create(MEDIA_TYPE_JSON, resourceJson)).url(resourceUrl);
        String resp = invoke(requestBuilder);
        return Serialization.unmarshal(resp, outputType);
    }

    /**
     * 处理Put请求，并以字符串形式返回原始响应的body内容
     *
     * @param namespace    命名空间，非命名空间的资源可以为null
     * @param name         k8s资源名称
     * @param resourceJson json格式的待提交的数据
     * @return 响应body内容
     */
    public String handlePutRequest(String namespace, String name, String resourceJson) {
        URL resourceUrl = getNamespacedResourceUrl(namespace, name);
        Request.Builder requestBuilder = new Request.Builder()
                .put(RequestBody.create(MEDIA_TYPE_JSON, resourceJson)).url(resourceUrl);
        return invoke(requestBuilder);
    }

    /**
     * 处理Delete请求
     *
     * @param namespace 命名空间，非命名空间的资源可以为null
     * @param name      k8s资源名称
     * @return 响应body内容
     */
    public String handleDeleteRequest(String namespace, String name) {
        URL resourceUrl = getNamespacedResourceUrl(namespace, name);
        Request.Builder requestBuilder = new Request.Builder().delete().url(resourceUrl);
        return invoke(requestBuilder);
    }

    private String invoke(Request.Builder requestBuilder) {
        Request request = requestBuilder.build();
        try (Response response = client.newCall(request).execute(); ResponseBody body = response.body()) {
            assertResponseCode(response);
            byte[] content = body != null ? body.bytes() : new byte[0];
            return new String(content, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new HAERuntimeException(CommonResultCode.K8S_SERVER_RESPONSE_ERROR);
        }
    }

    protected void assertResponseCode(Response response) {
        if (!response.isSuccessful()) {
            ResponseBody body = response.body();
            String responseContent;
            try {
                responseContent = new String(body == null ? new byte[0] : body.bytes());
            } catch (IOException e) {
                throw new HAERuntimeException(CommonResultCode.K8S_SERVER_RESPONSE_ERROR, e);
            }
            DelayedLogger.error(logger, () -> "调用K8S接口异常，状态码: " + response.code() + "，异常内容：" + responseContent);

            String errorMsg = responseContent;
            try {
                JSONObject messageJson = JSONObject.parseObject(responseContent);
                errorMsg = (String) messageJson.get("message");
            } catch (Exception ex) {
                // ignore
            }

            if (response.code() == 404) {
                //资源不存在，如提供了错误的namespace和resource name
                throw new HAERuntimeException(ResourceResultCode.REQUEST_RESOURCE_NOT_EXIST, errorMsg);
            }

            throw new HAERuntimeException(CommonResultCode.K8S_SERVER_RESPONSE_ERROR, errorMsg);
        }
    }
}
