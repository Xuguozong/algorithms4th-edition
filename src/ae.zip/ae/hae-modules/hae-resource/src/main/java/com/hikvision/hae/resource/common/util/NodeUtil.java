package com.hikvision.hae.resource.common.util;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.util.CollectionUtils;

import java.util.Map;

public class NodeUtil {

    public static boolean isMaster(Map<String, String> labels) {
        if (CollectionUtils.isEmpty(labels)) {
            return false;
        }
        // master节点同时作为工作节点使用时（一般都会这样做），HAE一般会安装在master1上
        // 当master节点只作为控制节点使用时，HAE所在的节点也作为控制节点看待
        return CommonConstants.K8S_MASTER_NODE_LABEL_VALUE.equals(labels.get(CommonConstants.K8S_MASTER_NODE_LABEL_KEY))
                || CommonConstants.K8S_MASTER_NODE_LABEL_VALUE.equals(labels.get(CommonConstants.HAE_NODE_LABEL_VALUE));
    }

    public static boolean isAnsible(Map<String, String> labels) {
        if (CollectionUtils.isEmpty(labels)) {
            return false;
        }
        return CommonConstants.ANSIBLE_NODE_LABEL_VALUE.equals(labels.get(CommonConstants.ANSIBLE_NODE_LABEL_KEY));
    }

}
