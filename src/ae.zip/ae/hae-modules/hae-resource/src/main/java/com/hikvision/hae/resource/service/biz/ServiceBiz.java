package com.hikvision.hae.resource.service.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.service.dto.EndpointDTO;
import io.fabric8.kubernetes.api.model.Service;

import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
public interface ServiceBiz {

    /**
     * 查询满足条件的所有Service
     *
     * @param filterQuery 查询条件
     * @return Service对象列表
     */
    List<Service> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有Service
     *
     * @param filterQuery          (前）查询条件
     * @param pageParam            分页条件
     * @param postResourceSelector （后）过滤条件：根据selector匹配
     * @return Service对象列表
     */
    Pagination<Service> findAndPage(FilterQuery filterQuery, Map<String, String> postResourceSelector, PageParam pageParam);

    /**
     * 查询指定namespace和name的Service
     *
     * @param namespace Service所在的namespace
     * @param name      Service的名称
     * @return null或者Service对象
     */
    Service getByName(String namespace, String name);

    /**
     * 查询Service的内部Endpoint
     *
     * @param service Service实例
     * @return Endpoint实例
     */
    EndpointDTO getInternalEndpoint(Service service);

    /**
     * 查询Service的外部Endpoint
     *
     * @param service Service实例
     * @return Endpoint实例
     */
    List<EndpointDTO> getExternalEndpoint(Service service);

    /**
     * 删除指定namespace和name的Service
     *
     * @param namespace Service所在的namespace
     * @param name      Service的名称
     */
    void delete(String namespace, String name);

    /**
     * 根据Service对象创建Service
     *
     * @param service Service对象
     * @return 生成的Service对象
     */
    Service create(Service service);
}
