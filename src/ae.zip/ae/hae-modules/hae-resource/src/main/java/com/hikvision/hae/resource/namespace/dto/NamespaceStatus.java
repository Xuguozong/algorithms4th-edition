package com.hikvision.hae.resource.namespace.dto;

import com.hikvision.hae.common.i18n.Localeable;

/**
 * Created by zhanjiejun on 2017/11/9.
 */
public enum NamespaceStatus implements Localeable {

	ACTIVE("Active"),

	TERMINATING("Terminating"),

	EXCEPTION("");


	private String k8sStatus;

	NamespaceStatus(String k8sStatus) {
		this.k8sStatus = k8sStatus;
	}

	public String getK8sStatus() {
		return k8sStatus;
	}

	public static NamespaceStatus parse(String k8sStatus) {
		for (NamespaceStatus namespaceStatus : NamespaceStatus.values()) {
			if (namespaceStatus.getK8sStatus().equalsIgnoreCase(k8sStatus)) {
				return namespaceStatus;
			}
		}
		return NamespaceStatus.EXCEPTION;
	}

	private final String i18nPrefix = "NAMESPACE.STATUS.";

	@Override
	public String i18nKey() {
		return i18nPrefix + this.name();
	}

}
