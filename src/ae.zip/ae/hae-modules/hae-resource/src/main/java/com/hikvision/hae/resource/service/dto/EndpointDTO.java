package com.hikvision.hae.resource.service.dto;

import io.fabric8.kubernetes.api.model.ServicePort;

import java.io.Serializable;
import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/13.
 */
public class EndpointDTO implements Serializable {
    private static final long serialVersionUID = 1125759272085759628L;

    // Hostname, either as a domain name or IP address.
    private String host;

    // List of ports opened for this endpoint on the hostname.
    private List<ServicePort> ports;

    public EndpointDTO() {
    }

    public EndpointDTO(String host, List<ServicePort> ports) {
        this.host = host;
        this.ports = ports;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public List<ServicePort> getPorts() {
        return ports;
    }

    public void setPorts(List<ServicePort> ports) {
        this.ports = ports;
    }
}
