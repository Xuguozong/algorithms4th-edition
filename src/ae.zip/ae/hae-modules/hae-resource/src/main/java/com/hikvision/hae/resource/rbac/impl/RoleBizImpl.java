package com.hikvision.hae.resource.rbac.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.common.operation.KubeRawHttpOperation;
import com.hikvision.hae.resource.rbac.RoleBiz;
import io.fabric8.openshift.api.model.Role;
import io.fabric8.openshift.api.model.RoleList;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/12/21.
 */
@Service
public class RoleBizImpl extends KubeRawHttpOperation<Role, RoleList> implements RoleBiz {

    @PostConstruct
    @Override
    public void init() {
        KubeOperationFactory.register(ResourceKind.Role, this);
    }

    @Override
    protected ResourceKind getResourceKindType() {
        return ResourceKind.Role;
    }

    @Override
    protected Class<Role> getResourceType() {
        return Role.class;
    }

    @Override
    protected Class<RoleList> getResourceListType() {
        return RoleList.class;
    }

}
