package com.hikvision.hae.resource.file.repo;

import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.resource.file.model.KubeResourceFile;

/**
 * @author jianghaiyang5 on 2017/11/17.
 */
public interface ResourceFileRepo extends GqRepository<KubeResourceFile, Integer> {


}
