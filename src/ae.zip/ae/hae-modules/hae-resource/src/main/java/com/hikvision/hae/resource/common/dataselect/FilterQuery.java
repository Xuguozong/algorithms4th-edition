package com.hikvision.hae.resource.common.dataselect;

import io.fabric8.kubernetes.api.model.LabelSelector;

import java.io.Serializable;
import java.util.*;

/**
 * K8S资源查询的过滤条件
 *
 * @author jianghaiyang5 on 2017/11/3.
 */
public class FilterQuery implements Serializable {
    private static final long serialVersionUID = -1835051468240024207L;

    /**
     * 命名空间
     */
    private String namespace;
    /**
     * 名称：fuzzy query
     */
    private String name;

    /**
     * 按label的key匹配
     */
    private List<String> labelKeys;

    /**
     * 按label的key-value匹配
     */
    private Map<String, String> labels;
    /**
     * 标签选择器
     */
    private LabelSelector labelSelector;
    /**
     * 按field的name-value匹配
     */
    private Map<String, String> fields;

    private String ownerUid;

    public FilterQuery() {
        labelKeys = new ArrayList<>();
        labels = new HashMap<>();
        fields = new HashMap<>();
    }

    // -- fluent method
    public static FilterQuery build() {
        return new FilterQuery();
    }

    public FilterQuery namespace(String namespace) {
        this.namespace = namespace;
        return this;
    }

    public FilterQuery name(String name) {
        this.name = name;
        return this;
    }

    public FilterQuery lableKey(String... keys) {
        labelKeys.addAll(Arrays.asList(keys));
        return this;
    }

    public FilterQuery label(String key, String value) {
        labels.put(key, value);
        return this;
    }

    public FilterQuery labelSelector(LabelSelector labelSelector) {
        this.labelSelector = labelSelector;
        return this;
    }

    public FilterQuery field(String key, String value) {
        fields.put(key, value);
        return this;
    }

    // --- getter and setter
    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getLabelKeys() {
        return labelKeys;
    }

    public void setLabelKeys(List<String> labelKeys) {
        this.labelKeys = labelKeys;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public LabelSelector getLabelSelector() {
        return labelSelector;
    }

    public void setLabelSelector(LabelSelector labelSelector) {
        this.labelSelector = labelSelector;
    }

    public Map<String, String> getFields() {
        return fields;
    }

    public void setFields(Map<String, String> fields) {
        this.fields = fields;
    }

    public String getOwnerUid() {
        return ownerUid;
    }

    public void setOwnerUid(String ownerUid) {
        this.ownerUid = ownerUid;
    }
}
