package com.hikvision.hae.resource.persistentvolume.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.persistentvolume.biz.PersistentVolumeBiz;
import io.fabric8.kubernetes.api.model.PersistentVolume;
import io.fabric8.kubernetes.api.model.PersistentVolumeList;
import io.fabric8.kubernetes.client.KubernetesClient;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.Comparator;
import java.util.List;

/**
 * 持久化存储卷Biz层
 * Created by zhanjiejun on 2017/11/22.
 */
@Service
public class PersistentVolumeBizImpl implements PersistentVolumeBiz {

    @javax.annotation.Resource
    protected KubernetesClient kubeClient;

    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.PersistentVolume, this);
    }

    @Override
    public List<PersistentVolume> find(FilterQuery filterQuery) {
        PersistentVolumeList volumeList = kubeClient.persistentVolumes().list();
        //按名称过滤
        if (StringUtils.hasText(filterQuery.getName())) {
            List<PersistentVolume> items = volumeList.getItems();
            for (int i = items.size() - 1; i >= 0; i--) {
                if (!items.get(i).getMetadata().getName().contains(filterQuery.getName())) {
                    items.remove(i);
                }
            }
        }
        return volumeList.getItems();
    }

    @Override
    public Pagination<PersistentVolume> findAndPage(FilterQuery filterQuery, PageParam pageParam) {
        List<PersistentVolume> items = this.find(filterQuery);
        if (items.isEmpty()) {
            return Pagination.build(pageParam);
        }
        Comparator<PersistentVolume> comparator = Comparator.comparing((PersistentVolume t) -> t.getMetadata().getName());
        return DataSelector.paginate(items, comparator, pageParam);
    }

    @Override
    public PersistentVolume getByName(String namespace, String name) {
        return kubeClient.persistentVolumes().withName(name).get();
    }

    @Override
    public void delete(String namespace, String name) {
        kubeClient.persistentVolumes().withName(name).cascading(true).delete();
    }

    @Override
    public PersistentVolume create(PersistentVolume pv){
        return kubeClient.persistentVolumes().create();
    }
}
