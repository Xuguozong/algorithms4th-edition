package com.hikvision.hae.resource.storageclass.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.common.operation.KubeRawHttpOperation;
import com.hikvision.hae.resource.storageclass.StorageClassBiz;
import io.fabric8.kubernetes.api.model.StorageClass;
import io.fabric8.kubernetes.api.model.StorageClassList;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
@Service
public class StorageClassBizImpl extends KubeRawHttpOperation<StorageClass, StorageClassList>
        implements StorageClassBiz {


    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.StorageClass, this);
    }

    @Override
    protected ResourceKind getResourceKindType() {
        return ResourceKind.StorageClass;
    }

    @Override
    protected Class<StorageClass> getResourceType() {
        return StorageClass.class;
    }

    @Override
    protected Class<StorageClassList> getResourceListType() {
        return StorageClassList.class;
    }

    @Override
    public StorageClass getByName(String name) {
        return super.getByName(null, name);
    }

    @Override
    public void delete(String name) {
        super.delete(null, name);
    }
}
