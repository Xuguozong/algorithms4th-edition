package com.hikvision.hae.resource.statefulset.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.extensions.StatefulSet;

import java.util.List;

/**
 * StatefulSet领域层操作接口
 *
 * @author jianghaiyang5 on 2017/11/21.
 */
public interface StatefulSetBiz {
    /**
     * 查询满足条件的所有StatefulSet
     *
     * @param filterQuery 查询条件
     * @return StatefulSet对象列表
     */
    List<StatefulSet> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有StatefulSet
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return StatefulSet对象列表
     */
    Pagination<StatefulSet> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的StatefulSet
     *
     * @param namespace StatefulSet所在的namespace
     * @param name      StatefulSet的名称
     * @return null或者StatefulSet对象
     */
    StatefulSet getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的StatefulSet
     *
     * @param namespace StatefulSet所在的namespace
     * @param name      StatefulSet的名称
     */
    void delete(String namespace, String name);

    /**
     * 伸缩Pod数量
     *
     * @param namespace StatefulSet所在的namespace
     * @param name      StatefulSet的名称
     * @param newNum    新数量
     * @return 新StatefulSet对象
     */
    StatefulSet scale(String namespace, String name, int newNum);
}
