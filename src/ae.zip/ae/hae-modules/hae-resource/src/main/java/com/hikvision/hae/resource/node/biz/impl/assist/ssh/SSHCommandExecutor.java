package com.hikvision.hae.resource.node.biz.impl.assist.ssh;

import com.hikvision.hae.common.util.StringUtils;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import jef.common.annotation.Out;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.Charset;

/**
 * This class provide interface to execute command on remote Linux.
 */
public class SSHCommandExecutor {

	private static Logger logger = LoggerFactory.getLogger(SSHCommandExecutor.class);

	private String ipAddress;

	private String username;

	private String password;

	private int timeout = 0;

	public static final int DEFAULT_SSH_PORT = 22;

	JSch jsch = new JSch();

	private Session session;

	public SSHCommandExecutor(final String ipAddress, final String username, final String password) {
		this.ipAddress = ipAddress;
		this.username = username;
		this.password = password;
	}

	public SSHCommandExecutor(final String ipAddress, final String username, final String password, final int timeout) {
		this.ipAddress = ipAddress;
		this.username = username;
		this.password = password;
		this.timeout = timeout;
	}

	public void open() throws JSchException, IOException {
		session = jsch.getSession(username, ipAddress, DEFAULT_SSH_PORT);
		session.setPassword(password);
		session.setUserInfo(new MyUserInfo());
		if (timeout > 0) {
			session.setTimeout(timeout);
		}
		session.connect();
	}

	public void close() {
		if (session != null) {
			session.disconnect();
		}
	}

	public String executeReturnErr(String cmd) {
		BufferedReader reader = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		ChannelExec channelExec = null;
		try {
			channelExec = (ChannelExec) session.openChannel("exec");
			// 增加退出标记，避免死循环
			String randomString = StringUtils.getRandomStrWithLowerCaseAndNumber(4);
			channelExec.setCommand(cmd + " ; echo '__exit" + randomString + "'");
			channelExec.setInputStream(null);
			outputStream = new ByteArrayOutputStream();
			channelExec.setErrStream(outputStream);
			channelExec.connect();
			inputStream = channelExec.getInputStream();
			reader = new BufferedReader(new InputStreamReader(inputStream, Charset.forName("UTF-8")));
			String tmp = null;
			String exitFlag = "__exit" + randomString;
			logger.debug("Begin to execute cmd, stdout is below...");
			while ((tmp = reader.readLine()) != null) {
				logger.debug(tmp);
				if (tmp.equals(exitFlag)) {
					break;
				}
			}
			return outputStream.toString();
		} catch (Exception e) {
			logger.error("SSH execute cmd failed.", e);
			return "SSH execute cmd failed.";
		} finally {
			if (reader != null) {
				IOUtils.closeQuietly(reader);
			}
			if (inputStream != null) {
				IOUtils.closeQuietly(inputStream);
			}
			if (channelExec != null) {
				channelExec.disconnect();
			}
			if (outputStream != null) {
				IOUtils.closeQuietly(outputStream);
			}
		}
	}

	public String getUsername() {
		return username;
	}
}