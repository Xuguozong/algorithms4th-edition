package com.hikvision.hae.resource.persistentvolumeclaim;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.PersistentVolumeClaim;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
public interface PersistentVolumeClaimBiz {

    /**
     * 查询满足条件的所有PersistentVolumeClaim
     *
     * @param filterQuery 查询条件
     * @return PersistentVolumeClaim对象列表
     */
    List<PersistentVolumeClaim> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有PersistentVolumeClaim
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return PersistentVolumeClaim对象列表
     */
    Pagination<PersistentVolumeClaim> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的PersistentVolumeClaim
     *
     * @param namespace PersistentVolumeClaim所在的namespace
     * @param name      PersistentVolumeClaim的名称
     * @return null或者PersistentVolumeClaim对象
     */
    PersistentVolumeClaim getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的ReplicationController
     *
     * @param namespace ReplicationController所在的namespace
     * @param name      ReplicationController的名称
     */
    void delete(String namespace, String name);

}
