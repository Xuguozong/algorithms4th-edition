package com.hikvision.hae.resource.common.enums;

import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;

/**
 * @author qihongfei on 2017/12/12.
 */
public enum EventType {

	NORMAL("Normal"),

    WARNING("Warning");
    
    private String code;

    private EventType(String code) {
        this.code = code;
    }

    private static final Logger logger = LoggerFactory.getLogger(EventType.class);

    public static EventType parse(String name) {
    	EventType eventType = Stream.of(EventType.values()).filter(c -> c.getCode().equalsIgnoreCase(name)).findFirst().orElse(null);
        if (eventType == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型EventType失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return eventType;
    }

    public String getCode() {
        return code;
    }
}
