package com.hikvision.hae.resource.replicaset.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.replicaset.biz.ReplicaSetBiz;
import com.hikvision.hae.resource.replicaset.biz.assist.ReplicaSetHelper;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import io.fabric8.kubernetes.api.model.extensions.DoneableReplicaSet;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSetList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.RollableScalableResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
@Service
public class ReplicaSetBizImpl
        extends KubeMixedOperation<ReplicaSet, ReplicaSetList, DoneableReplicaSet, RollableScalableResource<ReplicaSet, DoneableReplicaSet>>
        implements ReplicaSetBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.ReplicaSet, this);
    }

    @Override
    public MixedOperation<ReplicaSet, ReplicaSetList, DoneableReplicaSet,
            RollableScalableResource<ReplicaSet, DoneableReplicaSet>> getKubeOperation() {
        return kubeClient.extensions().replicaSets();
    }

    @Override
    public Pagination<ReplicaSet> findAndPageOldReplicaSet(Deployment deployment, PageParam pageParam) {
        FilterQuery filterQuery = FilterQuery.build().namespace(deployment.getMetadata().getNamespace())
                .labelSelector(deployment.getSpec().getSelector());
        List<ReplicaSet> items = super.find(filterQuery);
        items = ReplicaSetHelper.findOldReplicaSets(evictByName(items, deployment.getMetadata().getName()));
        Comparator<ReplicaSet> comparator = Comparator.comparing((ReplicaSet rs) ->
                Integer.parseInt(rs.getMetadata().getAnnotations().get(ResourceConstants.DEPLOYMENT_REVISION))
        ).reversed();
        return DataSelector.paginate(items, comparator, pageParam);
    }

    @Override
    public ReplicaSet getNewReplicaSet(Deployment deployment) {
        FilterQuery filterQuery = FilterQuery.build().namespace(deployment.getMetadata().getNamespace())
                .labelSelector(deployment.getSpec().getSelector());
        List<ReplicaSet> items = super.find(filterQuery);
        return ReplicaSetHelper.findNewReplicaSet(evictByName(items, deployment.getMetadata().getName()));
    }

    /**
     * RS的name是在Deployment的name后面追加“-”和一串随机字符，为了避免两个Deployment的Selector相同导致的RS混合在一起增加名称过滤
     *
     * @param items 按Deployment selector查询得到的所有RS
     * @return 仅属于当前Deployment的RS
     */
    private List<ReplicaSet> evictByName(List<ReplicaSet> items, String deploymentName) {
        return items.stream().filter(rs -> {
            String rsName = rs.getMetadata().getName();
            String rsNamePrefix = rsName.substring(0, rsName.lastIndexOf("-"));
            return Objects.equals(deploymentName, rsNamePrefix);
        }).collect(Collectors.toList());
    }
}
