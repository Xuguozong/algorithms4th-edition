package com.hikvision.hae.resource.limitrange.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.LimitRange;
import java.util.List;

/**
 * @author by zhouzhigang6 on 2018/1/22.
 */
public interface LimitRangeBiz {

    /**
     * 查询满足条件的所有LimitRange
     *
     * @param filterQuery 查询条件
     * @return LimitRange对象列表
     */
    List<LimitRange> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有LimitRange
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return LimitRange对象列表
     */
    Pagination<LimitRange> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的LimitRange
     *
     * @param namespace LimitRange所在的namespace
     * @param name      LimitRange的名称
     * @return null或者LimitRange对象
     */
    LimitRange getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的LimitRange
     *
     * @param namespace LimitRange所在的namespace
     * @param name      LimitRange的名称
     */
    void delete(String namespace, String name);
}
