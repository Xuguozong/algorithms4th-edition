package com.hikvision.hae.resource.storageclass;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.StorageClass;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/24.
 */
public interface StorageClassBiz {

    /**
     * 查询满足条件的所有StorageClass
     *
     * @param filterQuery 查询条件
     * @return StorageClass对象列表
     */
    List<StorageClass> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有StorageClass
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return StorageClass对象列表
     */
    Pagination<StorageClass> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定name的StorageClass
     *
     * @param name      StorageClass的名称
     * @return null或者StorageClass对象
     */
    StorageClass getByName(String name);

    /**
     * 删除指定name的StorageClass
     *
     * @param name      StorageClass的名称
     */
    void delete(String name);
}
