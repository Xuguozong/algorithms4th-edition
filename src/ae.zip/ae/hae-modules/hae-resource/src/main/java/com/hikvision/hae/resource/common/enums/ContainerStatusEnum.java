package com.hikvision.hae.resource.common.enums;

import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;

/**
 * @author qihongfei on 2017/12/8.
 */
public enum ContainerStatusEnum {

	Running, Terminated, Waiting;

    private static final Logger logger = LoggerFactory.getLogger(PodPhase.class);

    public static ContainerStatusEnum parse(String name) {
    	ContainerStatusEnum containerStatus = Stream.of(ContainerStatusEnum.values()).filter(c -> c.name().equals(name)).findFirst().orElse(null);
        if (containerStatus == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型ContainerStatus失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return containerStatus;
    }
}
