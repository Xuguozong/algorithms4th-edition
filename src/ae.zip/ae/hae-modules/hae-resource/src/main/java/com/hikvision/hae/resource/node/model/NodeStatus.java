package com.hikvision.hae.resource.node.model;

import com.hikvision.hae.common.i18n.Localeable;

/**
 * Created by zhanjiejun on 2017/11/2.
 */
public enum NodeStatus implements Localeable {

	READY,

	HARD_DELETING,

	BUILDING,

	UNDER_MAINTENANCE,

	BUILD_FAILED,

	NOT_READY,

	UNKNOW;

	private final String i18nPrefix = "NODE.STATUS.";

	@Override
	public String i18nKey() {
		return i18nPrefix + this.name();
	}

}
