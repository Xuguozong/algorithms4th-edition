package com.hikvision.hae.resource.namespace.repo;

import io.fabric8.kubernetes.api.model.Namespace;
import io.fabric8.kubernetes.api.model.ResourceQuota;
import io.fabric8.kubernetes.client.KubernetesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/9.
 */
@Component
public class NamespaceK8SRepo {

	@Autowired
	private KubernetesClient k8sClient;

	public List<Namespace> getNamespaces() {
		return k8sClient.namespaces().list().getItems();
	}

	public Namespace getNamespaceByName(String name) {
		return k8sClient.namespaces().withName(name).get();
	}

	public Namespace createNamespace(Namespace namespace) {
		return k8sClient.namespaces().create(namespace);
	}

	public void deleteNamespaceByName(String name) {
		k8sClient.namespaces().withName(name).delete();
	}

	public ResourceQuota getRQByNamespaceAndName(String namespace, String name) {
		return k8sClient.resourceQuotas().inNamespace(namespace).withName(name).get();
	}

	public ResourceQuota createRQ(String namespace, ResourceQuota resourceQuota) {
		return k8sClient.resourceQuotas().inNamespace(namespace).create(resourceQuota);
	}

	public ResourceQuota updateRQ(String namespace, ResourceQuota resourceQuota) {
		return k8sClient.resourceQuotas().inNamespace(namespace).withName(resourceQuota.getMetadata().getName()).patch(resourceQuota);
	}

}
