package com.hikvision.hae.resource.node.biz.impl;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.domain.PodResourceCount;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DigitUtils;
import com.hikvision.hae.common.util.K8SResourceUnitConverter;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.encrypt.AESUtils;
import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.PodPhase;
import com.hikvision.hae.resource.common.enums.ResourceQuotaKind;
import com.hikvision.hae.resource.common.util.NodeUtil;
import com.hikvision.hae.resource.common.util.PodUtil;
import com.hikvision.hae.resource.node.biz.NodeBiz;
import com.hikvision.hae.resource.node.biz.impl.assist.ssh.SSHCommandExecutor;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import com.hikvision.hae.resource.node.dto.NodeDTO;
import com.hikvision.hae.resource.node.dto.NodeResourceDTO;
import com.hikvision.hae.resource.node.model.Node;
import com.hikvision.hae.resource.node.model.NodeStatus;
import com.hikvision.hae.resource.node.repo.NodeK8SRepo;
import com.hikvision.hae.resource.node.repo.NodeRepo;
import com.jcraft.jsch.JSchException;
import io.fabric8.kubernetes.api.model.*;
import org.easyframe.enterprise.spring.CommonDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.Semaphore;

/**
 * Created by zhanjiejun on 2017/11/3.
 */
@Transactional
@Service
public class NodeBizImpl implements NodeBiz {

	private final Semaphore sshSemaphore = new Semaphore(1);

	private static final Logger logger = LoggerFactory.getLogger(NodeBizImpl.class);

	/**
	 * ROOT用户执行脚本
	 * 1 -> shell脚本的目录
	 * 2 -> shell脚本的名字
	 * 3 -> node host ip
	 * 4 -> ssh root password
	 * 5 -> host name
	 */
	private static final String ROOT_OPERATE_NODE_CMD_PATTERN = "cd %s && ./%s --ssh_host %s --ssh_pass %s %s";

	private static final String SUDO_ROOT_OPERATE_NODE_CMD_PATTERN = "cd %s && sudo ./%s --ssh_host %s --ssh_pass %s %s";

	/**
	 * 非ROOT用户执行脚本
	 */
	private static final String NOT_ROOT_OPERATE_NODE_CMD_PATTERN = "cd %s && ./%s --ssh_host %s --ssh_user %s --ssh_pass %s --become_user %s --become_pass %s %s";

	private static final String SUDO_NOT_ROOT_OPERATE_NODE_CMD_PATTERN = "cd %s && sudo ./%s --ssh_host %s --ssh_user %s --ssh_pass %s --become_user %s --become_pass %s %s";

	private static final String ANSIBLE_ERROR_MSG = "[ERROR]";

	@Autowired
	private NodeRepo nodeDBRepo;

	@Autowired
	private NodeK8SRepo nodeK8SRepo;

	@Autowired
	private CommonDao commonDao;

	@Value("${ansible.shell.dir:/opt/deploy_hikcloud/scripts}")
	private String shellDir;

	@PostConstruct
	public void init() {
		syncNodeData();
	}

	private void syncNodeData() {
		// 同步节点信息，仅将K8S中未被记录到数据库中的节点信息录入
		List<io.fabric8.kubernetes.api.model.Node> k8sNodes = nodeK8SRepo.listNodes();
		Iterable<Node> dbNodes = nodeDBRepo.findAll();
		List<Node> insertNodes = new ArrayList<>();
		List<Node> updateNodes = new ArrayList<>();
		if (!CollectionUtils.isEmpty(k8sNodes)) {
			k8sNodes.forEach(k8sNode -> {
				boolean existInK8SAndDB = false;
				String k8sName = k8sNode.getMetadata().getName();
				String k8sIP = getIPFromK8SNode(k8sNode);
				for (Iterator<Node> iterator = dbNodes.iterator(); iterator.hasNext(); ) {
					Node dbNode = iterator.next();
					if (dbNode.getK8sName().equals(k8sName) && dbNode.getIp().equals(k8sIP)) {
						if (dbNode.getStatus() != null) {
							dbNode.setStatus(null);
							updateNodes.add(dbNode);
						}
						iterator.remove();
						existInK8SAndDB = true;
						break;
					}
				}
				if (!existInK8SAndDB) {
					Node node = new Node();
					node.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(k8sNode.getMetadata().getCreationTimestamp().getTime(), new Date()));
					node.setIp(k8sIP);
					node.setName(k8sName);
					node.setK8sName(k8sName);
					insertNodes.add(node);
				}
			});
		}

		List<Node> deleteNodes = new ArrayList<>();
		dbNodes.forEach(dbNode -> deleteNodes.add(dbNode));
		if (!deleteNodes.isEmpty()) {
			commonDao.batchDelete(deleteNodes);
		}
		if (!updateNodes.isEmpty()) {
			commonDao.batchUpdate(updateNodes);
		}

		if (!insertNodes.isEmpty()) {
			nodeDBRepo.save(insertNodes);
		}
	}

	/**
	 * 获取节点IP
	 *
	 * @param k8sNode
	 * @return
	 */
	private String getIPFromK8SNode(io.fabric8.kubernetes.api.model.Node k8sNode) {
		return k8sNode.getStatus().getAddresses().stream()
				.filter(na -> "InternalIP".equalsIgnoreCase(na.getType()))
				.map(NodeAddress::getAddress)
				.findAny()
				.orElse(null);
	}

	@Override
	public Page<NodeBaseDTO> findAndPageNodes(int pageNo, int pageSize, String fuzzyQuery) {
		// 按照创建时间降序排列
		Pageable pageable = new PageRequest(pageNo - 1, pageSize, new Sort(Sort.Direction.DESC, "createTime"));
		Page<Node> dbNodePage;
		if (StringUtils.isEmpty(fuzzyQuery)) {
			dbNodePage = nodeDBRepo.findAll(pageable);
		} else {
			dbNodePage = nodeDBRepo.findByNameContainsOrIpContains(fuzzyQuery, fuzzyQuery, pageable);
		}
		List<NodeBaseDTO> resultList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dbNodePage.getContent())) {
			List<Node> dbNodes = dbNodePage.getContent();
			List<io.fabric8.kubernetes.api.model.Node> k8sNodes = nodeK8SRepo.listNodes();
			resultList = buildNodeBaseDTOs(dbNodes, k8sNodes);
		}
		Page<NodeBaseDTO> resultPage = new PageImpl<>(resultList, pageable, dbNodePage.getTotalElements());
		return resultPage;
	}

	@Override
	public List<NodeBaseDTO> listNodes() {
		Iterable<Node> dbNodes = nodeDBRepo.findAll();
		List<io.fabric8.kubernetes.api.model.Node> k8sNodes = nodeK8SRepo.listNodes();
		return buildNodeBaseDTOs(dbNodes, k8sNodes);
	}

	private List<NodeBaseDTO> buildNodeBaseDTOs(Iterable<Node> dbNodes, List<io.fabric8.kubernetes.api.model.Node> k8sNodes) {
		List<NodeBaseDTO> resultList = new ArrayList<>();
		dbNodes.forEach(dbNode -> {
			NodeBaseDTO nodeBaseDTO = NodeBaseDTO.fromNode(dbNode);
			k8sNodes.forEach(k8sNode -> {
				if (nodeBaseDTO.getK8sName().equals(k8sNode.getMetadata().getName())) {
					attachK8SNodeInfo(nodeBaseDTO, k8sNode);
					return;
				}
			});
			if (nodeBaseDTO.getStatus() == null) {
				nodeBaseDTO.setStatus(NodeStatus.UNKNOW);
			}
			resultList.add(nodeBaseDTO);
		});
		return resultList;
	}

	@Override
	public int addNode(NodeBaseDTO nodeBaseDTO) {
		// 1.校验节点名称
		if (isNameExist(nodeBaseDTO.getName(), 0)) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NAME_ALREADY_EXIST);
		}

		// 2.校验节点IP
		if (isIpExist(nodeBaseDTO.getIp())) {
			throw new HAERuntimeException(ResourceResultCode.NODE_IP_ALREADY_EXIST);
		}

		// 3.SSH Ansible节点
		SSHCommandExecutor executor = getSSHExecutorAndLock();

		// 4.保存节点信息到数据库，状态为添加中
		Node dbNode = nodeBaseDTO.toNodeForSave();
		// 这里保证同一个IP生成的名称一致
		String nodeName = ResourceConstants.K8S_NODE_NAME_PREFIX + com.hikvision.hae.common.util.StringUtils.digest(nodeBaseDTO.getIp(), 4);
		try {
			dbNode.setK8sName(nodeName + ResourceConstants.K8S_NODE_NAME_SUFFIX);
			dbNode.setStatus(NodeStatus.BUILDING);
			nodeDBRepo.save(dbNode);
		} catch (Exception e) {
			sshSemaphore.release();
			executor.close();
			throw new HAERuntimeException(ResourceResultCode.WRITE_NODE_INFO_TO_DB_FAIL, e);
		}

		// 5.异步执行脚本，添加节点
		Thread sshThread = new Thread(() -> {
			try {
				// 执行添加节点shell脚本
				String cmd = buildCMD(nodeBaseDTO.getIp(), nodeBaseDTO.getSshUser(), nodeBaseDTO.getSshPwd(), nodeName, 0, executor.getUsername());
				String stdErr = executor.executeReturnErr(cmd);
				if (!StringUtils.isEmpty(stdErr) && stdErr.contains(ANSIBLE_ERROR_MSG)) {
					logger.error("Add node {} to cluster failed.", nodeBaseDTO.getIp());
					dbNode.setStatus(NodeStatus.BUILD_FAILED);
				} else {
					dbNode.setStatus(null);
				}
			} catch (Exception e) {
				logger.error("Add node " + nodeBaseDTO.getIp() + " to cluster failed.", e);
				// 更新节点状态为添加失败
				dbNode.setStatus(NodeStatus.BUILD_FAILED);
			} finally {
				nodeDBRepo.update(dbNode);
				executor.close();
				sshSemaphore.release();
			}
		});
		sshThread.setDaemon(true);
		sshThread.setName("Node-Add-Thread");
		sshThread.start();
		return dbNode.getId();
	}

	/**
	 * @param ip
	 * @param sshUser
	 * @param sshPwd
	 * @param nodeName
	 * @param mode     0：添加节点 其它：硬删除
	 * @return
	 */
	private String buildCMD(String ip, String sshUser, String sshPwd, String nodeName, int mode, String ansibleUser) {
		if (StringUtils.isEmpty(sshUser) || ResourceConstants.DEFAULT_SSH_USER.equals(sshUser)) {
			// ROOT用户
			return String.format(ResourceConstants.DEFAULT_SSH_USER.equals(ansibleUser) ? ROOT_OPERATE_NODE_CMD_PATTERN : SUDO_ROOT_OPERATE_NODE_CMD_PATTERN,
					shellDir,
					mode == 0 ? ResourceConstants.DEFAULT_ADD_NODE_SHELL_FILENAME : ResourceConstants.DEFAULT_DELETE_NODE_SHELL_FILENAME,
					ip, sshPwd, nodeName);
		}

		// 非ROOT用户
		return String.format(ResourceConstants.DEFAULT_SSH_USER.equals(ansibleUser) ? NOT_ROOT_OPERATE_NODE_CMD_PATTERN : SUDO_NOT_ROOT_OPERATE_NODE_CMD_PATTERN,
				shellDir,
				mode == 0 ? ResourceConstants.DEFAULT_ADD_NODE_SHELL_FILENAME : ResourceConstants.DEFAULT_DELETE_NODE_SHELL_FILENAME,
				ip, sshUser, sshPwd, ResourceConstants.DEFAULT_SSH_USER, sshPwd, nodeName);
	}

	@Override
	public NodeBaseDTO hardDeleteNode(int id) {
		// 1.获取节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			return null;
		}

		// 2.获取K8S节点
		io.fabric8.kubernetes.api.model.Node k8sNode = nodeK8SRepo.getNodeByName(dbNode.getK8sName());
		if (k8sNode == null) {
			// K8S无该节点，则直接删除数据库
			nodeDBRepo.remove(dbNode);
			return NodeBaseDTO.fromNode(dbNode);
		}

		// 3.校验是否master节点
		Map<String, String> labels = k8sNode.getMetadata().getLabels();
		if (NodeUtil.isMaster(labels) || NodeUtil.isAnsible(labels)) {
			throw new HAERuntimeException(ResourceResultCode.MASTER_NODE_CAN_NOT_DELETE);
		}

		// 4.校验节点SSH信息
		if (StringUtils.isEmpty(dbNode.getSshPwd())) {
			throw new HAERuntimeException(ResourceResultCode.LACK_NODE_SSH_INFO);
		}

		// 5.SSH Ansible节点
		SSHCommandExecutor executor = getSSHExecutorAndLock();

		// 6.更新节点状态为硬删除中
		try {
			dbNode.setStatus(NodeStatus.HARD_DELETING);
			nodeDBRepo.update(dbNode);
		} catch (Exception e) {
			sshSemaphore.release();
			executor.close();
			throw new HAERuntimeException(ResourceResultCode.WRITE_NODE_INFO_TO_DB_FAIL, e);
		}

		// 7.异步执行脚本，硬删除节点
		Thread sshThread = new Thread(() -> {
			try {
				String nodeName = dbNode.getK8sName().substring(0, dbNode.getK8sName().length() - 9);
				String cmd = buildCMD(dbNode.getIp(), dbNode.getSshUser(), AESUtils.decrypt(dbNode.getSshPwd()), nodeName, 1, executor.getUsername());
				String stdErr = executor.executeReturnErr(cmd);
				if (!StringUtils.isEmpty(stdErr) && stdErr.contains(ANSIBLE_ERROR_MSG)) {
					logger.error("Hard delete node {} from cluster failed.", dbNode.getIp());
					dbNode.setStatus(null);
					nodeDBRepo.update(dbNode);
				} else {
					nodeDBRepo.delete(dbNode);
				}
			} catch (Exception e) {
				logger.error("Hard delete node " + dbNode.getIp() + " from cluster failed.", e);
				// 更新节点状态为未删除
				dbNode.setStatus(null);
				nodeDBRepo.update(dbNode);
			} finally {
				executor.close();
				sshSemaphore.release();
			}
		});
		sshThread.setDaemon(true);
		sshThread.setName("Node-Delete-Thread");
		sshThread.start();
		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public NodeBaseDTO softDeleteNode(int id) {
		// 1.获取节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			return null;
		}

		// 2.删除数据库节点信息
		nodeDBRepo.remove(dbNode);

		// 3.获取K8S节点
		io.fabric8.kubernetes.api.model.Node k8sNode = nodeK8SRepo.getNodeByName(dbNode.getK8sName());
		if (k8sNode != null) {
			// 4.删除K8S节点
			if (!nodeK8SRepo.deleteNodeByName(dbNode.getK8sName())) {
				throw new HAERuntimeException(ResourceResultCode.SOFT_DELETE_NODE_FAIL);
			}
		}
		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public NodeBaseDTO getNodeBaseDetail(int id) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}
		NodeBaseDTO nodeBaseDTO = NodeBaseDTO.fromNode(dbNode);

		if (!StringUtils.isEmpty(dbNode.getK8sName())) {
			// 2.获取K8S节点信息
			io.fabric8.kubernetes.api.model.Node k8sNode = nodeK8SRepo.getNodeByName(dbNode.getK8sName());
			if (k8sNode != null) {
				attachK8SNodeInfo(nodeBaseDTO, k8sNode);
			}
		}

		// 3.数据库中有但K8S中不存在，状态标识为未知
		if (nodeBaseDTO.getStatus() == null) {
			nodeBaseDTO.setStatus(NodeStatus.UNKNOW);
		}
		return nodeBaseDTO;
	}

	@Override
	public NodeBaseDTO mergeNodeLabel(int id, KeyValue label) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}

		// 2.获取K8S节点信息
		io.fabric8.kubernetes.api.model.Node k8sNode = getK8SNode(dbNode.getK8sName());

		// 3.更新K8S节点标签
		k8sNode.getMetadata().getLabels().put(label.getKey(), label.getValue());
		nodeK8SRepo.updateNode(k8sNode);

		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public NodeBaseDTO deleteNodeLabel(int id, String labelKey) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}

		// 2.获取K8S节点信息
		io.fabric8.kubernetes.api.model.Node k8sNode = getK8SNode(dbNode.getK8sName());

		// 3.更新K8S节点标签
		k8sNode.getMetadata().getLabels().remove(labelKey);
		nodeK8SRepo.updateNode(k8sNode);

		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public NodeBaseDTO maintainNode(int id) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}

		// 2.获取K8S节点信息
		io.fabric8.kubernetes.api.model.Node k8sNode = getK8SNode(dbNode.getK8sName());

		// 3.设置节点不可调度
		k8sNode.getSpec().setUnschedulable(true);
		nodeK8SRepo.updateNode(k8sNode);

		// 4.驱逐节点上的POD
		nodeK8SRepo.evictPodsByNodeName(k8sNode.getMetadata().getName());

		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public NodeBaseDTO exitMaintainNode(int id) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}

		// 2.获取K8S节点信息
		io.fabric8.kubernetes.api.model.Node k8sNode = getK8SNode(dbNode.getK8sName());

		// 3.设置节点可调度
		k8sNode.getSpec().setUnschedulable(false);
		nodeK8SRepo.updateNode(k8sNode);

		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public boolean isNameExist(String name, int id) {
		return nodeDBRepo.findByNameAndIdNot(name, id) != null;
	}

	@Override
	public boolean isIpExist(String ip) {
		return nodeDBRepo.findByIp(ip) != null;
	}

	@Override
	public boolean isLabelKeyExist(String labelKey, int id) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}

		// 2.获取K8S节点信息
		io.fabric8.kubernetes.api.model.Node k8sNode = getK8SNode(dbNode.getK8sName());
		return k8sNode.getMetadata().getLabels().containsKey(labelKey);
	}

	@Override
	public NodeDTO getNodeDetail(int id) {
		NodeDTO nodeDTO = new NodeDTO();
		NodeBaseDTO baseDTO = getNodeBaseDetail(id);
		nodeDTO.setNodeBaseDTO(baseDTO);
		NodeResourceDTO resourceDTO = new NodeResourceDTO();
		List<Pod> pods = nodeK8SRepo.getPodsByNodeName(baseDTO.getK8sName());
		double cpuRequest = 0;
		double cpuLimit = 0;
		double memoryRequest = 0;
		double memoryLimit = 0;
		int gpuRequest = 0;
		int gpuLimit = 0;
		int podUsed = 0;
		if (!CollectionUtils.isEmpty(pods)) {
			for (Pod pod : pods) {
				String status = pod.getStatus().getPhase();
				// 过滤掉Succeeded和Failed状态的pod
				if (!PodPhase.Succeeded.name().equals(status) && !PodPhase.Failed.name().equals(status)) {
					podUsed++;
					PodResourceCount podResourceCount = PodUtil.calculateResource(pod);
					cpuRequest += podResourceCount.getCpuRequest();
					cpuLimit += podResourceCount.getCpuLimit();
					memoryRequest += podResourceCount.getMemoryRequest();
					memoryLimit += podResourceCount.getMemoryLimit();
					gpuRequest += podResourceCount.getGpuRequest();
					gpuLimit += podResourceCount.getGpuLimit();
				}
			}
		}
		Map<String, String> requests = new HashMap<>();
		requests.put(CommonConstants.MAP_CPU_RESOURCE_KEY, String.valueOf(DigitUtils.toTwoDigits(cpuRequest)));
		requests.put(CommonConstants.MAP_MEMORY_RESOURCE_KEY, String.valueOf(DigitUtils.toTwoDigits(memoryRequest)));
		requests.put(CommonConstants.MAP_GPU_RESOURCE_KEY_FOR_FRONT, String.valueOf(gpuRequest));
		resourceDTO.setRequests(requests);
		Map<String, String> limits = new HashMap<>();
		limits.put(CommonConstants.MAP_CPU_RESOURCE_KEY, String.valueOf(DigitUtils.toTwoDigits(cpuLimit)));
		limits.put(CommonConstants.MAP_MEMORY_RESOURCE_KEY, String.valueOf(DigitUtils.toTwoDigits(memoryLimit)));
		limits.put(CommonConstants.MAP_GPU_RESOURCE_KEY_FOR_FRONT, String.valueOf(gpuLimit));
		resourceDTO.setLimits(limits);
		resourceDTO.setPodUsed(podUsed);
		nodeDTO.setNodeResourceDTO(resourceDTO);
		return nodeDTO;
	}

	@Override
	public NodeBaseDTO updateNode(NodeBaseDTO nodeBaseDTO) {
		// 1.获取数据库节点信息
		Node dbNode = nodeDBRepo.findOne(nodeBaseDTO.getId());
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}

		// 2.更新数据库节点信息
		Node node = new Node();
		node.setId(nodeBaseDTO.getId());
		if (!StringUtils.isEmpty(nodeBaseDTO.getName())) {
			if (isNameExist(nodeBaseDTO.getName(), nodeBaseDTO.getId())) {
				throw new HAERuntimeException(ResourceResultCode.NODE_NAME_ALREADY_EXIST);
			}
			node.setName(nodeBaseDTO.getName());
		}
		if (!StringUtils.isEmpty(nodeBaseDTO.getSshPwd())) {
			node.setSshUser(StringUtils.isEmpty(nodeBaseDTO.getSshUser()) ? ResourceConstants.DEFAULT_SSH_USER : nodeBaseDTO.getSshUser());
			node.setSshPwd(AESUtils.encrypt(nodeBaseDTO.getSshPwd()));
		}
		nodeDBRepo.update(node);

		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public String getNodeNameByK8SName(String k8sName) {
		Node node = nodeDBRepo.findByK8sName(k8sName);
		return node == null ? "" : node.getName();
	}

	@Override
	public Map<String, String> getK8SNameNodeNameMap() {
		Map<String, String> resultMap = new HashMap<>();
		Iterable<Node> nodes = nodeDBRepo.findAll();
		nodes.forEach(node -> resultMap.put(node.getK8sName(), node.getName()));
		return resultMap;
	}

	@Override
	public NodeBaseDTO getNodeDBInfoById(int id) {
		Node dbNode = nodeDBRepo.findOne(id);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}
		return NodeBaseDTO.fromNode(dbNode);
	}

	@Override
	public void syncNodeList() {
		if (!sshSemaphore.tryAcquire()) {
			throw new HAERuntimeException(ResourceResultCode.NODE_BUILDING_OR_HARD_DELETING_EXIST);
		}

		try {
			syncNodeData();
		} catch (Exception e) {
			throw new HAERuntimeException(ResourceResultCode.SYNC_NODE_LIST_FAILED, e);
		} finally {
			sshSemaphore.release();
		}
	}

	@Override
	public NodeBaseDTO getNodeDBInfoByK8SName(String k8sName) {
		Node dbNode = nodeDBRepo.findByK8sName(k8sName);
		if (dbNode == null) {
			throw new HAERuntimeException(ResourceResultCode.NODE_NOT_EXIST);
		}
		return NodeBaseDTO.fromNode(dbNode);
	}

	private io.fabric8.kubernetes.api.model.Node getK8SNode(String k8sName) {
		if (StringUtils.isEmpty(k8sName)) {
			throw new HAERuntimeException(ResourceResultCode.WRONG_NODE_STATUS);
		}

		// 获取K8S节点信息
		io.fabric8.kubernetes.api.model.Node k8sNode = nodeK8SRepo.getNodeByName(k8sName);
		if (k8sNode == null) {
			throw new HAERuntimeException(ResourceResultCode.WRONG_NODE_STATUS);
		}
		return k8sNode;
	}

	/**
	 * 获取SSH executor，并加线程锁
	 * 请务必在调用该方法后释放锁和关闭executor
	 *
	 * @return
	 */
	private SSHCommandExecutor getSSHExecutorAndLock() {
		// TODO 后续这里可以缓存下Ansible节点信息
		// 1.获取Ansible节点信息
		Map<String, String> ansibleFlagLabel = new HashMap<>();
		ansibleFlagLabel.put(CommonConstants.ANSIBLE_NODE_LABEL_KEY, CommonConstants.ANSIBLE_NODE_LABEL_VALUE);
		List<io.fabric8.kubernetes.api.model.Node> k8sNodes = nodeK8SRepo.listNodes(ansibleFlagLabel);
		if (CollectionUtils.isEmpty(k8sNodes)) {
			throw new HAERuntimeException(ResourceResultCode.ANSIBLE_NODE_NOT_EXIST);
		}

		// 2.获取Ansible节点SSH信息，一般只有一个节点有Ansible标签
		Node ansibleNode = nodeDBRepo.findByK8sName(k8sNodes.get(0).getMetadata().getName());
		if (ansibleNode == null) {
			throw new HAERuntimeException(ResourceResultCode.ANSIBLE_NODE_NOT_EXIST);
		}
		Object[] msgParam = new Object[1];
		msgParam[0] = ansibleNode.getIp();
		if (StringUtils.isEmpty(ansibleNode.getSshPwd())) {
			throw new HAERuntimeException(ResourceResultCode.LACK_ANSIBLE_NODE_SSH_INFO, msgParam);
		}

		// 3.加锁
		if (!sshSemaphore.tryAcquire()) {
			throw new HAERuntimeException(ResourceResultCode.NODE_BUILDING_OR_HARD_DELETING_EXIST);
		}

		String sshUser = StringUtils.isEmpty(ansibleNode.getSshUser()) ? ResourceConstants.DEFAULT_SSH_USER : ansibleNode.getSshUser();
		SSHCommandExecutor executor = new SSHCommandExecutor(ansibleNode.getIp(), sshUser, AESUtils.decrypt(ansibleNode.getSshPwd()));
		try {
			executor.open();
		} catch (JSchException e) {
			executor.close();
			sshSemaphore.release();
			logger.error("SSH ansible node failed", e);
			if (e.getMessage() != null && e.getMessage().contains("Auth")) {
				throw new HAERuntimeException(ResourceResultCode.WRONG_ANSIBLE_NODE_SSH_INFO, msgParam);
			} else {
				throw new HAERuntimeException(ResourceResultCode.SSH_ANSIBLE_NODE_FAIL, msgParam);
			}
		} catch (Exception e) {
			executor.close();
			sshSemaphore.release();
			throw new HAERuntimeException(ResourceResultCode.SSH_ANSIBLE_NODE_FAIL, msgParam, e);
		}
		return executor;
	}

	/**
	 * 追加K8S节点信息
	 *
	 * @param nodeBaseDTO
	 * @param k8sNode
	 */
	private void attachK8SNodeInfo(NodeBaseDTO nodeBaseDTO, io.fabric8.kubernetes.api.model.Node k8sNode) {
		// 设置标签信息
		nodeBaseDTO.setLabels(k8sNode.getMetadata().getLabels());
		// 设置状态信息
		if (nodeBaseDTO.getStatus() == null) {
			boolean isReady = false;
			for (NodeCondition condition : k8sNode.getStatus().getConditions()) {
				if (condition.getType().equalsIgnoreCase("Ready")) {
					isReady = "True".equalsIgnoreCase(condition.getStatus());
					break;
				}
			}
			if (isReady) {
				if (k8sNode.getSpec().getUnschedulable() != null && k8sNode.getSpec().getUnschedulable()) {
					nodeBaseDTO.setStatus(NodeStatus.UNDER_MAINTENANCE);
				} else {
					nodeBaseDTO.setStatus(NodeStatus.READY);
				}
			} else {
				nodeBaseDTO.setStatus(NodeStatus.NOT_READY);
			}
		}
		// 设置规格
		nodeBaseDTO.setCapacity(k8sNode.getStatus().getCapacity());
		// 设置已分配
		nodeBaseDTO.setAllocatable(k8sNode.getStatus().getAllocatable());
	}

}
