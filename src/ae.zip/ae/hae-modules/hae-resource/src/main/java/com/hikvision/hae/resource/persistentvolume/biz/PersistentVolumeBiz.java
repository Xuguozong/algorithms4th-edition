package com.hikvision.hae.resource.persistentvolume.biz;

import com.hikvision.hae.resource.common.operation.KubeOperation;
import io.fabric8.kubernetes.api.model.PersistentVolume;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
public interface PersistentVolumeBiz extends KubeOperation<PersistentVolume> {
    /**
     * 查询满足条件的所有PersistentVolume
     *
     * @param filterQuery 查询条件
     * @return PersistentVolume对象列表
     */
//    List<PersistentVolume> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有PersistentVolume
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return PersistentVolume对象列表
     */
//    Pagination<PersistentVolume> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定name的PersistentVolume
     *
     * @param namespace PV不属于任何命名空间，为固定值null
     * @param name      PersistentVolume的名称
     * @return null或者PersistentVolume对象
     */
//    PersistentVolume getByName(String namespace, String name);

    /**
     * 删除指定name的PersistentVolume
     *
     * @param namespace PV不属于任何命名空间，为固定值null
     * @param name      PersistentVolume的名称
     */
//    void delete(String namespace, String name);

    /**
     * 新建PersistentVolume
     *
     * @param pv 待创建的PersistentVolume对象
     * @return 创建后的PersistentVolume对象
     */
//    PersistentVolume create(PersistentVolume pv);

}
