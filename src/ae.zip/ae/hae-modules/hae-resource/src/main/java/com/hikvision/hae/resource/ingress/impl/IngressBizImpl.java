package com.hikvision.hae.resource.ingress.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.ingress.IngressBiz;
import io.fabric8.kubernetes.api.model.extensions.DoneableIngress;
import io.fabric8.kubernetes.api.model.extensions.Ingress;
import io.fabric8.kubernetes.api.model.extensions.IngressList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
@Service
public class IngressBizImpl
        extends KubeMixedOperation<Ingress, IngressList, DoneableIngress, Resource<Ingress, DoneableIngress>>
        implements IngressBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.Ingress, this);
    }

    @Override
    public MixedOperation<Ingress, IngressList, DoneableIngress, Resource<Ingress, DoneableIngress>> getKubeOperation() {
        return kubeClient.extensions().ingresses();
    }
}
