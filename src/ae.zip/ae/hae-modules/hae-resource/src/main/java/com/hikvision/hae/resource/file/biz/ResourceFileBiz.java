package com.hikvision.hae.resource.file.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.file.dto.ResourceFileDTO;
import com.hikvision.hae.resource.file.dto.ResourceFileGroupDTO;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/17.
 */
public interface ResourceFileBiz {

    ResourceFileGroupDTO createGroup(ResourceFileGroupDTO group);

    List<ResourceFileDTO> createFiles(List<ResourceFileDTO> files);

    Pagination<ResourceFileGroupDTO> findAndPageGroup(String groupName, PageParam pageParam);

    List<ResourceFileDTO> findFilesByGroup(int groupId);

    ResourceFileDTO loadFile(int fileId);

    ResourceFileGroupDTO loadGroup(int groupId);

    void deleteFile(int fileId);

    void deleteGroup(int groupId);
    
    void editFile(ResourceFileDTO fileDto);

    ResourceFileGroupDTO findGroupByName(String groupName);

    void updateGroup(int groupID, String groupName);
}
