package com.hikvision.hae.resource.common.dto;

import io.fabric8.kubernetes.api.model.ObjectReference;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public class SerializedReference {

    private String kind;

    private String apiVersion;

    private ObjectReference reference;

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public ObjectReference getReference() {
        return reference;
    }

    public void setReference(ObjectReference reference) {
        this.reference = reference;
    }
}
