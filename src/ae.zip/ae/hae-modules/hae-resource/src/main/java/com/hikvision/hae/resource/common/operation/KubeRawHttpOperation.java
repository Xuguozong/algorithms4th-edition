package com.hikvision.hae.resource.common.operation;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.rawresource.ResourceVerber;
import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.api.model.KubernetesResourceList;
import io.fabric8.kubernetes.client.utils.Serialization;
import org.springframework.util.StringUtils;

import java.util.Comparator;
import java.util.List;

/**
 * 调用K8S原生的HTTP API处理一些fabric8 kubernetes-client还不支持的资源类型
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
public abstract class KubeRawHttpOperation<T extends HasMetadata, L extends KubernetesResourceList>
        implements KubeOperation<T> {

    @javax.annotation.Resource
    private ResourceVerber resourceVerber;

    /**
     * 强制子类实现此方法，用于定义如向{@code KubeOperationFactory}注册实例等初始化操作
     */
    protected abstract void init();

    /**
     * 获取资源类型
     *
     * @return 资源类型
     */
    protected abstract ResourceKind getResourceKindType();

    /**
     * 获取单个资源的Class类型
     *
     * @return 资源类的Class表示
     */
    protected abstract Class<T> getResourceType();
    /**
     * 获取资源列表类的Class类型
     *
     * @return 资源列表类的Class表示
     */
    protected abstract Class<L> getResourceListType();

    @Override
    @SuppressWarnings("unchecked")
    public List<T> find(FilterQuery filterQuery) {
        String rawJson = resourceVerber.getAllAsJsonString(getResourceKindType(), filterQuery.getNamespace());
        L resourceList = Serialization.unmarshal(rawJson, getResourceListType());
        //按名称过滤
        if (StringUtils.hasText(filterQuery.getName())) {
            List<T> items = resourceList.getItems();
            for (int i = items.size() - 1; i >= 0; i--) {
                if (!items.get(i).getMetadata().getName().contains(filterQuery.getName())) {
                    items.remove(i);
                }
            }
        }
        return resourceList.getItems();
    }

    @Override
    public Pagination<T> findAndPage(FilterQuery filterQuery, PageParam pageParam) {
        List<T> items = this.find(filterQuery);
        if (items.isEmpty()) {
            return Pagination.build(pageParam);
        }
        Comparator<T> comparator = Comparator.comparing((T t) -> t.getMetadata().getName());
        return DataSelector.paginate(items, comparator, pageParam);
    }

    @Override
    public T getByName(String namespace, String name) {
        try {
            String rawJson = resourceVerber.getOneAsJsonString(getResourceKindType(), namespace, name);
            return Serialization.unmarshal(rawJson, getResourceType());
        } catch (Exception e) {
            if (e instanceof HAERuntimeException) {
                HAERuntimeException ex = (HAERuntimeException) e;
                if (ex.getResultCode() == ResourceResultCode.REQUEST_RESOURCE_NOT_EXIST) {
                    return null;
                }
            }
            throw e;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public T create(T t) {
        return (T) resourceVerber.create(getResourceKindType(), t.getMetadata().getNamespace(), Serialization.asJson(t));
    }

    @Override
    public void delete(String namespace, String name) {
        resourceVerber.delete(getResourceKindType(), namespace, name);
    }
}
