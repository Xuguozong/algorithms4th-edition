package com.hikvision.hae.resource.namespace.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.CollectionUtils;
import com.hikvision.hae.common.util.K8SResourceUnitConverter;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.ResourceQuotaKind;
import com.hikvision.hae.resource.namespace.biz.NamespaceBiz;
import com.hikvision.hae.resource.namespace.dto.NamespaceReadDTO;
import com.hikvision.hae.resource.namespace.dto.NamespaceStatus;
import com.hikvision.hae.resource.namespace.dto.NamespaceWriteDTO;
import com.hikvision.hae.resource.namespace.repo.NamespaceK8SRepo;
import io.fabric8.kubernetes.api.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by zhanjiejun on 2017/11/9.
 */
@Service
public class NamespaceBizImpl implements NamespaceBiz {

	private static final String RESOURCE_QUOTA_SUFFIX = "-quota";

	@Autowired
	private NamespaceK8SRepo namespaceK8SRepo;

	@Override
	public List<NamespaceReadDTO> getNamespaces(boolean calculateQuota) {
		List<Namespace> namespaces = namespaceK8SRepo.getNamespaces();
		if (CollectionUtils.isEmpty(namespaces)) {
			return Collections.emptyList();
		}
		List<NamespaceReadDTO> resultList = namespaces.parallelStream().map(namespace -> buildNamespaceDTO(namespace, calculateQuota))
				.sorted((n1, n2) -> n1.getCreateTime().before(n2.getCreateTime()) ? 1 : -1)
				.collect(Collectors.toList());
		return resultList;
	}

	@Override
	public NamespaceReadDTO modifyNamespaceQuota(NamespaceWriteDTO namespaceDTO) {
		String namespaceName = namespaceDTO.getName();
		Namespace namespace = namespaceK8SRepo.getNamespaceByName(namespaceName);
		if (namespace == null) {
			throw new HAERuntimeException(ResourceResultCode.NAMESPACE_NOT_EXIST);
		}
		NamespaceReadDTO result = convertNamespace2DTO(namespace);
		ResourceQuota oldResourceQuota = namespaceK8SRepo.getRQByNamespaceAndName(namespaceName, buildResourceQuotaName(namespaceName));
		if (oldResourceQuota == null) {
			// 创建ResourceQuota
			oldResourceQuota = createQuota(namespaceDTO);
		} else {
			// 更新ResourceQuota
			validateQuota(namespaceDTO, oldResourceQuota);
			ResourceQuotaSpec resourceQuotaSpec = new ResourceQuotaSpecBuilder().addToHard(buildHard(namespaceDTO)).build();
			oldResourceQuota.setSpec(resourceQuotaSpec);
			namespaceK8SRepo.updateRQ(namespaceName, oldResourceQuota);
		}
		result.setHard(oldResourceQuota.getSpec().getHard());

		// 这里必须再获取一次，不然拿不到对应的配额的使用值
		ResourceQuota newResourceQuota = namespaceK8SRepo.getRQByNamespaceAndName(namespaceName, buildResourceQuotaName(namespaceName));
		result.setUsed(newResourceQuota.getStatus().getUsed());
		result.setHasResourceQuota(true);
		return result;
	}

	@Override
	public boolean isNameExist(String name) {
		return namespaceK8SRepo.getNamespaceByName(name) != null;
	}

	@Override
	public NamespaceReadDTO createNamespace(NamespaceWriteDTO namespaceWriteDTO) {
		// 1.校验命名空间
		if (isNameExist(namespaceWriteDTO.getName())) {
			throw new HAERuntimeException(ResourceResultCode.NAMESPACE_ALREADY_EXIST);
		}

		// 2.创建命名空间
		Namespace namespace = new Namespace();
		ObjectMeta objectMeta = new ObjectMeta();
		objectMeta.setName(namespaceWriteDTO.getName());
		namespace.setMetadata(objectMeta);
		namespace = new NamespaceBuilder(namespace, true).build();
		namespace = namespaceK8SRepo.createNamespace(namespace);
		NamespaceReadDTO result = convertNamespace2DTO(namespace);

		// 3.创建ResourceQuota
		boolean needResourceQuota = namespaceWriteDTO.getCpuQuota() > 0 && namespaceWriteDTO.getMemoryQuota() > 0;
		if (needResourceQuota) {
			ResourceQuota resourceQuota = createQuota(namespaceWriteDTO);
			result.setHard(resourceQuota.getSpec().getHard());
			result.setUsed(buildEmptyQuota());
		}
		result.setHasResourceQuota(needResourceQuota);
		return result;
	}

	@Override
	public void deleteNamespaceByName(String name) {
		Namespace namespace = namespaceK8SRepo.getNamespaceByName(name);
		if (namespace == null) {
			return;
		}
		namespaceK8SRepo.deleteNamespaceByName(name);
	}

	@Override
	public NamespaceReadDTO getNamespaceByName(String name) {
		Namespace namespace = namespaceK8SRepo.getNamespaceByName(name);
		if (namespace == null) {
			throw new HAERuntimeException(ResourceResultCode.NAMESPACE_NOT_EXIST);
		}
		return buildNamespaceDTO(namespace, true);
	}

	/**
	 * 创建ResourceQuota
	 *
	 * @param namespaceDTO
	 * @return
	 */
	private ResourceQuota createQuota(NamespaceWriteDTO namespaceDTO) {
		String namespaceName = namespaceDTO.getName();
		ResourceQuota resourceQuota = new ResourceQuota();
		ObjectMeta objectMeta = new ObjectMeta();
		objectMeta.setName(buildResourceQuotaName(namespaceName));
		objectMeta.setNamespace(namespaceName);
		ResourceQuotaSpec resourceQuotaSpec = new ResourceQuotaSpecBuilder().addToHard(buildHard(namespaceDTO)).build();
		resourceQuota.setSpec(resourceQuotaSpec);
		resourceQuota.setMetadata(objectMeta);
		resourceQuota = new ResourceQuotaBuilder(resourceQuota, true).build();
		return namespaceK8SRepo.createRQ(namespaceName, resourceQuota);
	}

	/**
	 * 校验ResourceQuota
	 *
	 * @param namespaceDTO
	 * @param resourceQuota
	 */
	private void validateQuota(NamespaceWriteDTO namespaceDTO, ResourceQuota resourceQuota) {
		double cpuUsed = K8SResourceUnitConverter.convertCPU2Cores(resourceQuota.getStatus().getUsed().get(ResourceQuotaKind.CPU.getKey()).getAmount());
		double memoryUsed = K8SResourceUnitConverter.convertMemory2Gi(resourceQuota.getStatus().getUsed().get(ResourceQuotaKind.MEMORY.getKey()).getAmount());
		int gpuUsed = K8SResourceUnitConverter.formatGPUAmount(resourceQuota.getStatus().getUsed().get(ResourceQuotaKind.GPU.getKey()).getAmount());
		if (namespaceDTO.getCpuQuota() < cpuUsed || namespaceDTO.getMemoryQuota() < memoryUsed || namespaceDTO.getGpuQuota() < gpuUsed) {
			throw new HAERuntimeException(ResourceResultCode.NAMESPACE_QUOTA_LESS_THAN_USED);
		}
	}

	private Map<String, Quantity> buildEmptyQuota() {
		Map<String, Quantity> map = new HashMap<>(3);
		map.put(ResourceQuotaKind.CPU.getKey(), new Quantity("0"));
		map.put(ResourceQuotaKind.MEMORY.getKey(), new Quantity("0"));
		map.put(ResourceQuotaKind.GPU.getKey(), new Quantity("0"));
		return map;
	}

	private Map<String, Quantity> buildHard(NamespaceWriteDTO namespaceDTO) {
		Map<String, Quantity> hard = new HashMap<>(3);
		hard.put(ResourceQuotaKind.CPU.getKey(), new Quantity(String.valueOf(namespaceDTO.getCpuQuota()) + ResourceQuotaKind.CPU.getUnit()));
		hard.put(ResourceQuotaKind.MEMORY.getKey(), new Quantity(String.valueOf(namespaceDTO.getMemoryQuota()) + ResourceQuotaKind.MEMORY.getUnit()));
		hard.put(ResourceQuotaKind.GPU.getKey(), new Quantity(String.valueOf(namespaceDTO.getGpuQuota()) + ResourceQuotaKind.GPU.getUnit()));
		return hard;
	}

	private NamespaceReadDTO buildNamespaceDTO(Namespace namespace, boolean calculateQuota) {
		NamespaceReadDTO namespaceDTO = convertNamespace2DTO(namespace);
		if (calculateQuota && !namespaceDTO.isK8SDefault()) {
			ResourceQuota resourceQuota = namespaceK8SRepo.getRQByNamespaceAndName(namespaceDTO.getName(), buildResourceQuotaName(namespaceDTO.getName()));
			if (resourceQuota != null) {
				namespaceDTO.setHasResourceQuota(true);
				namespaceDTO.setHard(resourceQuota.getStatus().getHard());
				namespaceDTO.setUsed(resourceQuota.getStatus().getUsed());
			} else {
				namespaceDTO.setHasResourceQuota(false);
			}
		}
		return namespaceDTO;
	}

	private NamespaceReadDTO convertNamespace2DTO(Namespace namespace) {
		NamespaceReadDTO namespaceReadDTO = new NamespaceReadDTO();
		String name = namespace.getMetadata().getName();
		namespaceReadDTO.setName(name);
		NamespaceStatus status = NamespaceStatus.parse(namespace.getStatus().getPhase());
		namespaceReadDTO.setStatus(status);
		namespaceReadDTO.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(namespace.getMetadata().getCreationTimestamp().getTime(), new Date()));
		namespaceReadDTO.setK8SDefault(isK8SDefaultNamespace(name));
		return namespaceReadDTO;
	}

	private boolean isK8SDefaultNamespace(String name) {
		return name.equalsIgnoreCase(ResourceConstants.DEFAULT_NAMESPACE_KUBE_SYSTEM) || name.equalsIgnoreCase(ResourceConstants.DEFAULT_NAMESPACE_KUBE_PUBLIC) || name.equalsIgnoreCase(ResourceConstants.DEFAULT_NAMESPACE_DEFAULT);
	}

	private String buildResourceQuotaName(String namespaceName) {
		return namespaceName + RESOURCE_QUOTA_SUFFIX;
	}

}
