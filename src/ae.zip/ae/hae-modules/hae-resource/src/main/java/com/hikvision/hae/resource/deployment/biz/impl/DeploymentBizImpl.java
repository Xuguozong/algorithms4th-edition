package com.hikvision.hae.resource.deployment.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.deployment.biz.DeploymentBiz;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import io.fabric8.kubernetes.api.model.extensions.DeploymentList;
import io.fabric8.kubernetes.api.model.extensions.DoneableDeployment;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.ScalableResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * Deployment领域层操作接口实现
 *
 * @author jianghaiyang5 on 2017/11/3.
 */
@Service
public class DeploymentBizImpl
        extends KubeMixedOperation<Deployment, DeploymentList, DoneableDeployment, ScalableResource<Deployment, DoneableDeployment>>
        implements DeploymentBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.Deployment, this);
    }

    @Override
    public MixedOperation<Deployment, DeploymentList, DoneableDeployment,
            ScalableResource<Deployment, DoneableDeployment>> getKubeOperation() {
        return kubeClient.extensions().deployments();
    }

    @Override
    public Deployment scale(String namespace, String name, int newNum) {
        Deployment deployment = super.getByName(namespace, name);
        if (deployment == null) {
            throw new HAERuntimeException(ResourceResultCode.DEPLOYMENT_NOT_EXIST);
        }
        if (deployment.getSpec().getReplicas() == newNum) {
            return deployment;
        }
        return getKubeOperation().inNamespace(namespace).withName(name).scale(newNum);
    }
}