package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.Role;

import java.util.List;

/**
 * RBAC Role操作
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
public interface RoleBiz {

    /**
     * 查询满足条件的所有 RbacRole
     *
     * @param filterQuery 查询条件
     * @return RbacRole 对象列表
     */
    List<Role> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有 RbacRole
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return RbacRole 对象列表
     */
    Pagination<Role> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定name的 RbacRole
     *
     * @param namespace RbacRole 所在的namespace
     * @param name      RbacRole 的名称
     * @return null或者 RbacRole 对象
     */
    Role getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的 RbacRole
     *
     * @param namespace RbacRole 所在的namespace
     * @param name      RbacRole 的名称
     */
    void delete(String namespace, String name);
}
