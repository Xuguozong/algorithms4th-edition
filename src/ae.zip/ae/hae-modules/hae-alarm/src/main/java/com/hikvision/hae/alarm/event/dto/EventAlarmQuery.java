package com.hikvision.hae.alarm.event.dto;

import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public class EventAlarmQuery {

	private Boolean history;

	/**
	 * 支持模糊查询
	 */
	private String objectName;

	/**
	 * 时间查询模式
	 * 1 -> 最近一次
	 * 其它 -> 首次发生
	 */
	private Integer timeQueryMode;

	private Long start;

	private Long end;

	public Boolean getHistory() {
		return history;
	}

	public void setHistory(Boolean history) {
		this.history = history;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public Integer getTimeQueryMode() {
		return timeQueryMode;
	}

	public void setTimeQueryMode(Integer timeQueryMode) {
		this.timeQueryMode = timeQueryMode;
	}

	public Long getStart() {
		return start;
	}

	public void setStart(Long start) {
		this.start = start;
	}

	public Long getEnd() {
		return end;
	}

	public void setEnd(Long end) {
		this.end = end;
	}

}
