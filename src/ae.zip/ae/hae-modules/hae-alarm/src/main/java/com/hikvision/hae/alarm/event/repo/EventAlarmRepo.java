package com.hikvision.hae.alarm.event.repo;

import com.github.geequery.springdata.annotation.Query;
import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.alarm.event.model.EventAlarm;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.Set;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public interface EventAlarmRepo extends GqRepository<EventAlarm, String> {

	@Query("select id from event_alarm where is_eliminated = :eliminated")
	Set<String> findIdByEliminated(@Param("eliminated") boolean eliminated);

}
