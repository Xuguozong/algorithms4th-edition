package com.hikvision.hae.alarm.event.biz.impl;

import com.google.common.collect.Lists;
import com.hikvision.hae.alarm.event.biz.EventAlarmBiz;
import com.hikvision.hae.alarm.event.dto.EventAlarmQuery;
import com.hikvision.hae.alarm.event.model.EventAlarm;
import com.hikvision.hae.alarm.event.repo.EventAlarmRepo;
import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.vo.PageParam;
import io.fabric8.kubernetes.api.model.Event;
import jef.database.QB;
import jef.database.query.Query;
import jef.database.query.QueryBuilder;
import org.easyframe.enterprise.spring.CommonDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
@Service
@Transactional
public class EventAlarmBizImpl implements EventAlarmBiz {

	@Autowired
	private EventAlarmRepo eventAlarmRepo;

	@Autowired
	private CommonDao dao;

	@Override
	public Page<EventAlarm> findAndPage(PageParam pageParam, EventAlarmQuery query) {
		PageRequest pageRequest = new PageRequest(pageParam.getPageNo() - 1 , pageParam.getPageSize(), new Sort(Sort.Direction.DESC, "firstSeenTime"));
		return eventAlarmRepo.find(buildQuery(query), pageRequest);
	}

	@Override
	public void handleEvents(Collection<Event> events) {
		Set<String> alarmIds = eventAlarmRepo.findIdByEliminated(false);
		List<EventAlarm> insertList = Lists.newArrayList();
		List<EventAlarm> updateList = Lists.newArrayList();
		events.forEach(event -> {
			String id = event.getMetadata().getUid();
			if (alarmIds.contains(id)) {
				updateList.add(EventAlarm.fromEventForUpdate(event));
				alarmIds.remove(id);
			} else {
				insertList.add(EventAlarm.fromEventForInsert(event));
			}
		});

		if (!insertList.isEmpty()) {
			dao.batchInsert(insertList);
		}

		if (!updateList.isEmpty()) {
			dao.batchUpdate(updateList);
		}

		if (!alarmIds.isEmpty()) {
			// FIXME stream.map.collect会导致其它未调用setter方法的字段被更新 GeeQuery的bug T_T
			List<EventAlarm> eliminatedList = new ArrayList<>(alarmIds.size());
			alarmIds.forEach(id -> {
				EventAlarm eventAlarm = new EventAlarm();
				eventAlarm.setId(id);
				eventAlarm.setEliminated(true);
				eliminatedList.add(eventAlarm);
			});
			dao.batchUpdate(eliminatedList);
		}
	}

	@Override
	public long count(EventAlarmQuery query) {
		return eventAlarmRepo.count(buildQuery(query));
	}

	private Query<EventAlarm> buildQuery(EventAlarmQuery query) {
		Query<EventAlarm> resultQuery = QueryBuilder.create(EventAlarm.class);
		if (null != query) {
			if (null != query.getHistory()) {
				resultQuery.addCondition(EventAlarm.Field.eliminated, query.getHistory());
			}
			if (StringUtils.isNotEmpty(query.getObjectName())) {
				resultQuery.addCondition(QB.matchAny(EventAlarm.Field.involvedObjectName, query.getObjectName()));
			}
			if (null != query.getStart()) {
				resultQuery.addCondition(QB.ge(query.getTimeQueryMode() != null && query.getTimeQueryMode() == 1 ? EventAlarm.Field.firstSeenTime :
						EventAlarm.Field.lastSeenTime, new Date(query.getStart())));
			}
			if (null != query.getEnd()) {
				resultQuery.addCondition(QB.le(query.getTimeQueryMode() != null && query.getTimeQueryMode() == 1 ? EventAlarm.Field.firstSeenTime :
						EventAlarm.Field.lastSeenTime, new Date(query.getEnd())));
			}
		}
		return resultQuery;
	}

}
