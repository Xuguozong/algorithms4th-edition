package com.hikvision.hae.alarm.event.biz;

import com.hikvision.hae.alarm.event.dto.EventAlarmQuery;
import com.hikvision.hae.alarm.event.model.EventAlarm;
import com.hikvision.hae.common.vo.PageParam;
import io.fabric8.kubernetes.api.model.Event;
import org.springframework.data.domain.Page;

import java.util.Collection;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public interface EventAlarmBiz {

	Page<EventAlarm> findAndPage(PageParam pageParam, EventAlarmQuery query);

	/**
	 * 处理采集到的事件
	 * 1、已存在告警但并未消除 -> 更新count、lastSeenTime
	 * 2、未消除告警但已不存在事件 -> 更新eliminated
	 * 3、未存在告警 -> 创建告警
	 * @param events
	 */
	void handleEvents(Collection<Event> events);

	long count(EventAlarmQuery query);

}
