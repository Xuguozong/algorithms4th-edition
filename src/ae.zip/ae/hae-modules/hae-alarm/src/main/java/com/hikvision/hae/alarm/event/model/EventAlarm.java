package com.hikvision.hae.alarm.event.model;

import com.github.geequery.orm.annotation.Comment;
import com.hikvision.hae.common.util.UTCDateUtil;
import io.fabric8.kubernetes.api.model.Event;
import io.fabric8.kubernetes.api.model.ObjectReference;
import jef.database.DataObject;
import jef.database.annotation.Type;
import jef.database.dialect.extension.ObjectJsonMapping;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by zhanjiejun on 2018/3/21.
 */
@Entity
@Table(name = "event_alarm")
@Comment("事件告警")
public class EventAlarm extends DataObject {

	/**
	 * 事件ID
	 */
	@Id
	private String id;

	/**
	 * 告警名称
	 */
	private String name;

	/**
	 * 命名空间
	 */
	private String namespace;

	/**
	 * 事件消息
	 */
	@Lob
	private String message;

	/**
	 * 最早出现时间
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "first_seen_time", nullable = false)
	private Date firstSeenTime;

	/**
	 * 最近出现时间
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_seen_time", nullable = false)
	private Date lastSeenTime;

	private int count;

	/**
	 * 关联对象名称，冗余字段
	 */
	@Column(name = "involved_object_name")
	private String involvedObjectName;

	/**
	 * 关联对象
	 */
	@Lob
	@Column(name = "involved_object", columnDefinition = "text")
	@Type(ObjectJsonMapping.class)
	private ObjectReference involvedObject;

	@Column(name = "is_eliminated")
	private boolean eliminated;

	public enum Field implements jef.database.Field {
		id, name, namespace, message, firstSeenTime, lastSeenTime, count, involvedObjectName, involvedObject, eliminated
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getFirstSeenTime() {
		return firstSeenTime;
	}

	public void setFirstSeenTime(Date firstSeenTime) {
		this.firstSeenTime = firstSeenTime;
	}

	public Date getLastSeenTime() {
		return lastSeenTime;
	}

	public void setLastSeenTime(Date lastSeenTime) {
		this.lastSeenTime = lastSeenTime;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getInvolvedObjectName() {
		return involvedObjectName;
	}

	public void setInvolvedObjectName(String involvedObjectName) {
		this.involvedObjectName = involvedObjectName;
	}

	public ObjectReference getInvolvedObject() {
		return involvedObject;
	}

	public void setInvolvedObject(ObjectReference involvedObject) {
		this.involvedObject = involvedObject;
	}

	public boolean isEliminated() {
		return eliminated;
	}

	public void setEliminated(boolean eliminated) {
		this.eliminated = eliminated;
	}

	public static EventAlarm fromEventForInsert(Event event) {
		EventAlarm eventAlarm = new EventAlarm();
		eventAlarm.setId(event.getMetadata().getUid());
		eventAlarm.setName(event.getMetadata().getName());
		eventAlarm.setNamespace(event.getMetadata().getNamespace());
		eventAlarm.setFirstSeenTime(UTCDateUtil.parseUTCTimeToStandardDate(event.getFirstTimestamp().getTime()));
		eventAlarm.setLastSeenTime(UTCDateUtil.parseUTCTimeToStandardDate(event.getLastTimestamp().getTime()));
		eventAlarm.setMessage(event.getMessage());
		eventAlarm.setInvolvedObject(event.getInvolvedObject());
		eventAlarm.setInvolvedObjectName(event.getInvolvedObject().getName());
		eventAlarm.setCount(event.getCount());
		eventAlarm.setEliminated(false);
		return eventAlarm;
	}

	public static EventAlarm fromEventForUpdate(Event event) {
		EventAlarm eventAlarm = new EventAlarm();
		eventAlarm.setId(event.getMetadata().getUid());
		eventAlarm.setCount(event.getCount());
		eventAlarm.setLastSeenTime(UTCDateUtil.parseUTCTimeToStandardDate(event.getLastTimestamp().getTime()));
		return eventAlarm;
	}

}
