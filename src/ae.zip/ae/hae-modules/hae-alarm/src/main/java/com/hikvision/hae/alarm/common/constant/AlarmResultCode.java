package com.hikvision.hae.alarm.common.constant;

/**
 * 告警错误码（15000~15999）
 * Created by zhanjiejun on 2018/3/22.
 */
public class AlarmResultCode {
}
