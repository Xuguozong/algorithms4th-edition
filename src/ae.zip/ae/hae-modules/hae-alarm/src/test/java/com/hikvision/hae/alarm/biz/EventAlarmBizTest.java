package com.hikvision.hae.alarm.biz;

import com.hikvision.hae.AlarmBaseTest;
import com.hikvision.hae.alarm.event.biz.EventAlarmBiz;
import com.hikvision.hae.alarm.event.dto.EventAlarmQuery;
import com.hikvision.hae.common.vo.PageParam;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public class EventAlarmBizTest extends AlarmBaseTest {

	@Autowired
	private EventAlarmBiz eventAlarmBiz;

	@Test
	public void findAndPageHistoryAlarmTest() {
		EventAlarmQuery query = new EventAlarmQuery();
		query.setHistory(false);
		query.setObjectName("redis");
		eventAlarmBiz.findAndPage(new PageParam(0, 1), query);
		query.setHistory(true);
		eventAlarmBiz.findAndPage(new PageParam(0, 1), query);
		query.setHistory(null);
		eventAlarmBiz.findAndPage(new PageParam(0, 1), query);
		query.setObjectName(null);
		eventAlarmBiz.findAndPage(new PageParam(0, 1), query);
	}

}
