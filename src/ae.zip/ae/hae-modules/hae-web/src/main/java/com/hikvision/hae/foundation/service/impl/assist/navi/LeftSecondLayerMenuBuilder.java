package com.hikvision.hae.foundation.service.impl.assist.navi;

import com.hikvision.hae.common.enums.Mode;
import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created by zhouziwei on 2017/11/8.
 */
@Component
public class LeftSecondLayerMenuBuilder extends AbstractMenuBuilder {

    @Resource
    private SysResourceBiz sysResourceBiz;

    /**
     * 构建第二层左侧菜单
     *
     * @param userId  用户ID
     * @param namespace 命名空间
     * @return
     */
    public MenuResourceVO build(String userId, String namespace, Mode mode) {
        SysResourceDTO sysResourceDTO = sysResourceBiz.getResourceTree(SysResourceLayout.LEFT_LV2, mode);
        MenuResourceVO menuResourceVO = MenuResourceVO.readFromDTO(sysResourceDTO);
        replacePathVariable(menuResourceVO, namespace);
        return menuResourceVO;
    }

}
