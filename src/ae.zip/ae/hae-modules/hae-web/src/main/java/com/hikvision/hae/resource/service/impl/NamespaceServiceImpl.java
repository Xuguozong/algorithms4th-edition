package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.util.PodUtil;
import com.hikvision.hae.resource.namespace.biz.NamespaceBiz;
import com.hikvision.hae.resource.namespace.dto.NamespaceReadDTO;
import com.hikvision.hae.resource.namespace.dto.NamespaceWriteDTO;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.service.NamespaceService;
import com.hikvision.hae.resource.vo.NamespaceDetailVO;
import com.hikvision.hae.resource.vo.NamespaceReadVO;
import com.hikvision.hae.resource.vo.NamespaceWriteVO;
import io.fabric8.kubernetes.api.model.Pod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by zhanjiejun on 2017/11/10.
 */
@Service
public class NamespaceServiceImpl implements NamespaceService {

	@Autowired
	private NamespaceBiz namespaceBiz;

	@Autowired
	private PodBiz podBiz;

	@Override
	public List<NamespaceReadVO> getNamespaces(boolean calculateQuota) {
		List<NamespaceReadDTO> namespaceReadDTOs = namespaceBiz.getNamespaces(calculateQuota);
		if (namespaceReadDTOs.isEmpty()) {
			return Collections.emptyList();
		}
		return namespaceReadDTOs.stream().map(n -> ResourceVOBuilder.buildNamespaceVO(n)).collect(Collectors.toList());
	}

	@Override
	public NamespaceReadVO getNamespace(String name) {
		return ResourceVOBuilder.buildNamespaceVO(namespaceBiz.getNamespaceByName(name));
	}

	@Override
	public NamespaceDetailVO getNamespaceDetail(String name) {
		NamespaceDetailVO namespaceOverviewVO = ResourceVOBuilder.buildNamespaceVO(namespaceBiz.getNamespaceByName(name));
		FilterQuery filterQuery = new FilterQuery();
		filterQuery.setNamespace(name);
		List<Pod> pods = podBiz.find(filterQuery);
		namespaceOverviewVO.setTotalPod(pods.size());
		namespaceOverviewVO.setRunningPod((int) pods.stream().filter(pod -> PodUtil.isPodRunning(pod)).count());
		return namespaceOverviewVO;
	}

	@Override
	public NamespaceReadVO createNamespace(NamespaceWriteVO namespaceWriteVO) {
		return ResourceVOBuilder.buildNamespaceVO(namespaceBiz.createNamespace(convertNamespaceVO2DTO(namespaceWriteVO)));
	}

	@Override
	public NamespaceReadVO modifyNamespace(NamespaceWriteVO namespaceWriteVO) {
		return ResourceVOBuilder.buildNamespaceVO(namespaceBiz.modifyNamespaceQuota(convertNamespaceVO2DTO(namespaceWriteVO)));
	}

	@Override
	public void deleteNamespace(String name) {
		namespaceBiz.deleteNamespaceByName(name);
	}

	@Override
	public boolean isNameExist(String name) {
		return namespaceBiz.isNameExist(name);
	}

	private NamespaceWriteDTO convertNamespaceVO2DTO(NamespaceWriteVO namespaceWriteVO) {
		NamespaceWriteDTO namespaceWriteDTO = new NamespaceWriteDTO();
		namespaceWriteDTO.setName(namespaceWriteVO.getName());
		namespaceWriteDTO.setCpuQuota(namespaceWriteVO.getCpuQuota());
		namespaceWriteDTO.setMemoryQuota(namespaceWriteVO.getMemoryQuota());
		namespaceWriteDTO.setGpuQuota(namespaceWriteVO.getGpuQuota());
		return namespaceWriteDTO;
	}

}
