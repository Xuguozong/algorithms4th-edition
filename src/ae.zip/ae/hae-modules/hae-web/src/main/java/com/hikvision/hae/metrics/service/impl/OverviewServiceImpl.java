package com.hikvision.hae.metrics.service.impl;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.domain.PodResourceCount;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.util.AsyncTaskExecutor;
import com.hikvision.hae.common.util.DigitUtils;
import com.hikvision.hae.common.util.K8SResourceUnitConverter;
import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.assist.MetricsVOBuilder;
import com.hikvision.hae.metrics.biz.MetricsBiz;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import com.hikvision.hae.metrics.service.OverviewService;
import com.hikvision.hae.metrics.vo.ClusterInfoVO;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.PodPhase;
import com.hikvision.hae.resource.common.util.PodUtil;
import com.hikvision.hae.resource.namespace.biz.NamespaceBiz;
import com.hikvision.hae.resource.namespace.dto.NamespaceReadDTO;
import com.hikvision.hae.resource.namespace.dto.NamespaceStatus;
import com.hikvision.hae.resource.node.biz.NodeBiz;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import com.hikvision.hae.resource.node.model.NodeStatus;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import io.fabric8.kubernetes.api.model.Pod;
import io.fabric8.kubernetes.api.model.Quantity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by zhanjiejun on 2017/11/21.
 */
@Service
public class OverviewServiceImpl implements OverviewService {

	@Autowired
	private NodeBiz nodeBiz;

	@Autowired
	private NamespaceBiz namespaceBiz;

	@Autowired
	private MetricsBiz metricsBiz;

	@Autowired
	private PodBiz podBiz;

	@Override
	public ClusterInfoVO getClusterInfo() {
		ClusterInfoVO clusterInfoVO = new ClusterInfoVO();

		Runnable nodeInfoTask = () -> {
			List<NodeBaseDTO> nodeBaseDTOs = nodeBiz.listNodes();
			int totalNode = nodeBaseDTOs.size();
			int abnormalNode = 0;
			int totalGpu = 0;
			double totalCpu = 0;
			double totalMemory = 0;
			if (!nodeBaseDTOs.isEmpty()) {
				for (NodeBaseDTO node : nodeBaseDTOs) {
					NodeStatus status = node.getStatus();
					if (NodeStatus.UNKNOW == status || NodeStatus.NOT_READY == status || NodeStatus.BUILD_FAILED == status) {
						abnormalNode++;
					}
					if (node.getCapacity() != null) {
						Quantity gpuCapacity = node.getCapacity().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S);
						if (gpuCapacity != null) {
							totalGpu += Integer.valueOf(gpuCapacity.getAmount());
						}
						Quantity cpuCapacity = node.getCapacity().get(CommonConstants.MAP_CPU_RESOURCE_KEY);
						if (cpuCapacity != null) {
							totalCpu += K8SResourceUnitConverter.convertCPU2Cores(cpuCapacity.getAmount());
						}
						Quantity memoryCapacity = node.getCapacity().get(CommonConstants.MAP_MEMORY_RESOURCE_KEY);
						if (memoryCapacity != null) {
							totalMemory += K8SResourceUnitConverter.convertMemory2Gi(memoryCapacity.getAmount());
						}
					}
				}
			}
			clusterInfoVO.setAbnormalNode(abnormalNode);
			clusterInfoVO.setTotalNode(totalNode);
			clusterInfoVO.setNormalNode(totalNode - abnormalNode);
			clusterInfoVO.setTotalGpu(totalGpu);
			clusterInfoVO.setTotalCpu(DigitUtils.toTwoDigits(totalCpu));
			clusterInfoVO.setTotalMemory(DigitUtils.toTwoDigits(totalMemory));
		};

		Runnable namespaceInfoTask = () -> {
			List<NamespaceReadDTO> namespaceReadDTOs = namespaceBiz.getNamespaces(false);
			int totalNamespace = namespaceReadDTOs.size();
			int abnormalNamespace = 0;
			if (!namespaceReadDTOs.isEmpty()) {
				for (NamespaceReadDTO namespace : namespaceReadDTOs) {
					if (NamespaceStatus.EXCEPTION == namespace.getStatus()) {
						abnormalNamespace++;
					}
				}
			}
			clusterInfoVO.setTotalNamespace(totalNamespace);
			clusterInfoVO.setAbnormalNamespace(abnormalNamespace);
			clusterInfoVO.setNormalNamespace(totalNamespace - abnormalNamespace);
		};

		Runnable podInfoTask = () -> {
			FilterQuery filterQuery = new FilterQuery();
			List<Pod> pods = podBiz.find(filterQuery);
			int podTotal = pods.size();
			int gpuRequest = 0;
			int gpuLimit = 0;
			int podRunning = 0;
			for (Pod pod : pods) {
				String status = pod.getStatus().getPhase();
				// 过滤掉Succeeded和Failed状态的pod
				if (!PodPhase.Succeeded.name().equals(status) && !PodPhase.Failed.name().equals(status)) {
					if (PodUtil.isPodRunning(pod)) {
						podRunning++;
					}
					if (!StringUtils.isEmpty(pod.getSpec().getNodeName())) {
						PodResourceCount podResourceCount = PodUtil.calculateResource(pod);
						gpuRequest += podResourceCount.getGpuRequest();
						gpuLimit += podResourceCount.getGpuLimit();
					}
				}
			}
			clusterInfoVO.setTotalPod(podTotal);
			clusterInfoVO.setRequestGpu(gpuRequest);
			clusterInfoVO.setLimitGpu(gpuLimit);
			clusterInfoVO.setRunningPod(podRunning);
		};

		Runnable[] asyncTasks = new Runnable[]{nodeInfoTask, namespaceInfoTask, podInfoTask};
		AsyncTaskExecutor.executeBatch(asyncTasks);
		return clusterInfoVO;
	}

	@Override
	public MetricsTrendVO metricsClusterTrend(MetricsType metricsType) {
		List<MetricsDTO> metricsDTOs = metricsBiz.metricsCluster(metricsType);
		if (metricsDTOs.isEmpty()) {
			return new MetricsTrendVO();
		}
		if (metricsDTOs.size() == 1) {
			return MetricsVOBuilder.buildMetricsTrendVO("", metricsType, metricsDTOs.get(0));
		}
		List<MetricsDTO.MetricsData> metricsDatas = new ArrayList<>();
		metricsDTOs.forEach(metricsDTO -> {
			if (metricsDTO != null && !CollectionUtils.isEmpty(metricsDTO.getMetrics())) {
				metricsDatas.addAll(metricsDTO.getMetrics());
			}
		});
		Map<String, Long> metricsDataMap = metricsDatas.stream().collect(Collectors.groupingBy(MetricsDTO.MetricsData::getTimestamp, Collectors.summingLong(MetricsDTO.MetricsData::getValue)));
		return MetricsVOBuilder.buildMetricsTrendVO("", metricsType, metricsDataMap);
	}

}
