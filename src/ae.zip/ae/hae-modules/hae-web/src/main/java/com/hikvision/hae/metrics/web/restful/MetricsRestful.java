package com.hikvision.hae.metrics.web.restful;

import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.MetricsQueryVO;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.service.MetricsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 监控Rest层
 * Created by zhanjiejun on 2017/11/20.
 */
@RestController
@RequestMapping("/api/metrics/v1")
public class MetricsRestful {

	@Autowired
	private MetricsService metricsService;

	@GetMapping("/nodes/{id}/trend")
	public AjaxResult<MetricsTrendVO> getNodeMetricsTrend(@PathVariable int id, MetricsQueryVO metricsQuery) {
		AjaxResult<MetricsTrendVO> result = AjaxResult.buildSuccess();
		result.setData(metricsService.getNodeMetricsTrend(id, metricsQuery));
		return result;
	}

	@GetMapping("/nodes/{id}/gpuUsage")
	public AjaxResult<Map<String, String>> getNodeGpuUsage(@PathVariable int id) {
		AjaxResult<Map<String, String>> result = AjaxResult.buildSuccess();
		result.setData(metricsService.getNodeGpuUsage(id));
		return result;
	}

	@GetMapping("/nodes/{id}/gpu/{index}/trend")
	public AjaxResult<MetricsTrendVO> getNodeGpuMetricsTrend(@PathVariable int id, @PathVariable String index, MetricsQueryVO metricsQuery) {
		AjaxResult<MetricsTrendVO> result = AjaxResult.buildSuccess();
		result.setData(metricsService.getNodeGpuMetricsTrend(id, index, metricsQuery));
		return result;
	}

	@GetMapping("/nodes/{id}/gpu/{index}/baseInfo")
	public AjaxResult<GpuBaseInfo> getNodeGpuBaseInfo(@PathVariable int id, @PathVariable String index) {
		AjaxResult<GpuBaseInfo> result = AjaxResult.buildSuccess();
		result.setData(metricsService.getNodeGpuBaseInfo(id, index));
		return result;
	}

	@GetMapping("/namespaces/{namespace}/trend")
	public AjaxResult<MetricsTrendVO> getNamespaceMetricsTrend(@PathVariable String namespace, MetricsQueryVO metricsQuery) {
		AjaxResult<MetricsTrendVO> result = AjaxResult.buildSuccess();
		result.setData(metricsService.getNamespaceMetricsTrend(namespace, metricsQuery));
		return result;
	}

	@GetMapping("/namespaces/{namespace}/pods/{podName}/trend")
	public AjaxResult<MetricsTrendVO> getPodMetricsTrend(@PathVariable String namespace, @PathVariable String podName, MetricsQueryVO metricsQuery) {
		AjaxResult<MetricsTrendVO> result = AjaxResult.buildSuccess();
		result.setData(metricsService.getPodMetricsTrend(namespace, podName, metricsQuery));
		return result;
	}

}
