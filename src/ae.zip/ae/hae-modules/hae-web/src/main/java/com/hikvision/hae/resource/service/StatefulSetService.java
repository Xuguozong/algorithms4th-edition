package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.StatefulSetDetailVO;

/**
 * @author jianghaiyang5 on 2017/11/21.
 */
public interface StatefulSetService {

    /**
     * 分页查询StatefulSet
     *
     * @param namespace 命名空间
     * @param name      StatefulSet名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodControllerItemVO> findAndPage(String namespace, String name, PageParam pageParam);

    /**
     * 查看StatefulSet详情
     *
     * @param namespace 命名空间
     * @param name      StatefulSet名称
     * @return StatefulSet详情
     */
    StatefulSetDetailVO getDetail(String namespace, String name);

    /**
     * 伸缩Pod数量
     *
     * @param namespace   命名空间
     * @param name        StatefulSet名称
     * @param newReplicas 新Pod数量
     */
    void scale(String namespace, String name, int newReplicas);

    /**
     * 删除StatefulSet
     *
     * @param namespace 命名空间
     * @param name      StatefulSet名称
     */
    void delete(String namespace, String name);


}
