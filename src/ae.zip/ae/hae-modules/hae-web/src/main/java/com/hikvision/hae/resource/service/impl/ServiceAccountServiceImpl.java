/**
 * 
 */
package com.hikvision.hae.resource.service.impl;

import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.service.ServiceAccountService;
import com.hikvision.hae.resource.serviceaccount.biz.ServiceAccountBiz;
import com.hikvision.hae.resource.vo.ServiceAccountDetailVO;
import com.hikvision.hae.resource.vo.ServiceAccountListVO;

import io.fabric8.kubernetes.api.model.ServiceAccount;

/**
 * @author qihongfei
 *
 */
@org.springframework.stereotype.Service
public class ServiceAccountServiceImpl implements ServiceAccountService {
	
	private static final Logger logger = LoggerFactory.getLogger(ServiceAccountServiceImpl.class);
	
	@Resource
	private ServiceAccountBiz serviceAccountBiz;
	
	@Resource
    private KubeEventHelper kubeEventHelper;

	@Override
	public Pagination<ServiceAccountListVO> findAndPage(String namespace, String name, PageParam pageParam) {

		FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<ServiceAccount> serviceAccountPage = serviceAccountBiz.findAndPage(filterQuery, pageParam);
        if (serviceAccountPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }
        
        Function<Collection<ServiceAccount>, Collection<ServiceAccountListVO>> rowsConverter = 
        		(Collection<ServiceAccount> saList) -> serviceAccountPage.getRows().stream().map(svc -> ResourceVOBuilder.buildServiceAccountListVO(svc)).collect(Collectors.toList());
        
		return new Pagination<>(serviceAccountPage, rowsConverter);
	}

	@Override
	public ServiceAccountDetailVO getDetail(String namespace, String name) {

		ServiceAccount serviceAccount = serviceAccountBiz.getByName(namespace, name);
		if (serviceAccount == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在ServiceAccount[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.SERVICE_ACCOUNT_NOT_EXIST);
        }
		
		return ResourceVOBuilder.buildServiceAccountDetailVO(serviceAccount);
	}

	@Override
	public void delete(String namespace, String name) {
		serviceAccountBiz.delete(namespace, name);
		kubeEventHelper.publishDeleteEvent(ActionLogModules.SERVICE_ACCOUNT, PrincipalCategory.SERVICE_ACCOUNT, namespace, name, "删除Service Account");
	}

}
