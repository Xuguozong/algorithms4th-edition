package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.util.encrypt.RSAUtils;
import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.UserActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.util.eventcenter.event.UserOperationEvent;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.foundation.assit.FoundationVOBuilder;
import com.hikvision.hae.foundation.service.UserService;
import com.hikvision.hae.foundation.vo.ModifyPwdVO;
import com.hikvision.hae.foundation.vo.UserReadVO;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Validator;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
@RestController
@RequestMapping("/api/user/v1")
public class UserRestful {

	@Resource
	private UserService userService;

	@Resource
	private Validator validator;

	@Resource
	private EventPublisher eventPublisher;

	@PutMapping("/users/modifyPwd")
	public AjaxResult<Void> updateOwnUserPwd(@RequestBody ModifyPwdVO modifyPwd) {
		boolean isIlleaglArg = modifyPwd == null || !CollectionUtils.isEmpty(validator.validate(modifyPwd));
		if (isIlleaglArg) {
			return new AjaxResult<>(CommonResultCode.ILLEGAL_ARGUMENT);
		}
		String ordinalNewPwd = RSAUtils.decode(modifyPwd.getNewPwd());
		String ordinalConfirmPwd = RSAUtils.decode(modifyPwd.getConfirmPwd());
		if (!ordinalNewPwd.equals(ordinalConfirmPwd)) {
			return new AjaxResult<>(CommonResultCode.ILLEGAL_ARGUMENT);
		}
		String ordinalOldPwd = RSAUtils.decode(modifyPwd.getOptPwd());
		LoginUser loginUser = LoginUtils.getLoginUser();
		userService.modifyPassword(loginUser.getUsername(), ordinalOldPwd, ordinalNewPwd);

		// 记录操作日志
		UserOperationEvent operEvent = UserOperationEvent.builder().source(ActionLogModules.USER_MANAGE)
				.principalCategory(PrincipalCategory.USER).actionType(UserActionType.UPDATE_PASSWORD).actorIp(loginUser.getClientIP())
				.actorId(loginUser.getId()).principalName(loginUser.getUsername()).principalIndexCode(loginUser.getId()).remark("修改密码").build();
		eventPublisher.publish(operEvent);
		return AjaxResult.buildSuccess();
	}

	/**
	 * 获取我的信息
	 *
	 * @return
	 */
	@GetMapping("/users/baseInfo")
	public AjaxResult<UserReadVO> getOwnInfo() {
		LoginUser loginUser = LoginUtils.getLoginUser();
		return new AjaxResult<>(CommonResultCode.SUCCESS, FoundationVOBuilder.buildUserReadVO(userService.getUserByName(loginUser.getUsername())));
	}

}
