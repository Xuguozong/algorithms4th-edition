package com.hikvision.hae.resource.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.ObjectMapperSingleton;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.rawresource.ResourceVerber;
import com.hikvision.hae.resource.service.RawResourceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.Yaml;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Map;


/**
 * @author jianghaiyang5 on 2017/11/9.
 */
@Service
public class RawResourceServiceImpl implements RawResourceService {
    private static final Logger logger = LoggerFactory.getLogger(RawResourceServiceImpl.class);

    @Resource
    private ResourceVerber resourceVerber;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public String getResource(ResourceKind kind, String namespace, String name) {
        String jsonText = resourceVerber.getOneAsJsonString(kind, namespace, name);
        try {
            JsonNode jsonNode = ObjectMapperSingleton.getJSONMapperInstance().readTree(jsonText);
            return ObjectMapperSingleton.getYAMLInstance().writeValueAsString(jsonNode);
        } catch (IOException e) {
            DelayedLogger.error(logger, () -> "无法将资源namespace[" + namespace + "], kind[" + kind + "], name[" + name + "]的JSON定义转换成YAML", e);
            throw new HAERuntimeException(CommonResultCode.INVALID_JSON_TEXT);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void updateResource(String newYamlText) {
        Yaml yaml = new Yaml();
        Map<String, Object> doc;
        try {
            doc = (Map<String, Object>) yaml.load(newYamlText);
        } catch (Exception e) {
            throw new HAERuntimeException(ResourceResultCode.MALFORMED_KUBE_DOCUMENT, e);
        }
        ResourceKind kind = ResourceKind.parse((String) doc.get("kind"));
        Map<String, Object> metadata = (Map<String, Object>) doc.get("metadata");
        String namespace = metadata.get("namespace") == null ? null : (String) metadata.get("namespace");
        String name = (String) metadata.get("name");
        String newJsonText;
        try {
            newJsonText = ObjectMapperSingleton.getJSONMapperInstance().writeValueAsString(doc);
        } catch (JsonProcessingException e) {
            DelayedLogger.error(logger, () -> "根据JsonNode对象获取Json字符串异常", e);
            throw new HAERuntimeException(CommonResultCode.INVALID_YAML_TEXT, e);
        }
        resourceVerber.update(kind, namespace, name, newJsonText);
        kubeEventHelper.publishUpdateEvent(ActionLogModules.YAML_EDIT, PrincipalCategory.parse(kind.getCode()), namespace, name, "编辑资源YAML");
    }
}
