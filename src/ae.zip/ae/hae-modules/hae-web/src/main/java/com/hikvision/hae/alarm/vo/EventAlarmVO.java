package com.hikvision.hae.alarm.vo;

import java.util.Date;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public class EventAlarmVO {

	private String id;

	private String name;

	private String namespace;

	private String message;

	private Date firstSeenTime;

	private Date lastSeenTime;

	private int count;

	private InvolvedObjectVO involvedObject;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getFirstSeenTime() {
		return firstSeenTime;
	}

	public void setFirstSeenTime(Date firstSeenTime) {
		this.firstSeenTime = firstSeenTime;
	}

	public Date getLastSeenTime() {
		return lastSeenTime;
	}

	public void setLastSeenTime(Date lastSeenTime) {
		this.lastSeenTime = lastSeenTime;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public InvolvedObjectVO getInvolvedObject() {
		return involvedObject;
	}

	public void setInvolvedObject(InvolvedObjectVO involvedObject) {
		this.involvedObject = involvedObject;
	}

	public static class InvolvedObjectVO {

		private String kind;

		private String name;

		private String namespace;

		public String getKind() {
			return kind;
		}

		public void setKind(String kind) {
			this.kind = kind;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getNamespace() {
			return namespace;
		}

		public void setNamespace(String namespace) {
			this.namespace = namespace;
		}
	}

}
