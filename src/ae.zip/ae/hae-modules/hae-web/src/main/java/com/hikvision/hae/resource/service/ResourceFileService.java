package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.BatchOperResultVO;
import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ResourceFileGroupVO;
import com.hikvision.hae.resource.vo.ResourceFileVO;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
public interface ResourceFileService {

    BatchOperResultVO deployFromFile(int fileId);

    BatchOperResultVO deployFromGroup(int groupId);

    BatchOperResultVO deleteFromFile(int fileId);

    Pagination<ResourceFileGroupVO> findAndPageFileGroup(String groupName, PageParam pageParam);

    BatchOperResultVO uploadResourceFiles(int groupId, String groupName, boolean exec, List<KeyValue> fileList);

    void deleteFile(int fileId);

    void deleteGroup(int groupId);

    void updateGroupName(int groupID, String groupName);

    ResourceFileGroupVO findGroup(String groupName);

    ResourceFileVO loadFile(int fileId);
    
    void editFile(int fileId, String fileContent);
}
