package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.limitrange.biz.LimitRangeBiz;
import com.hikvision.hae.resource.service.LimitRangeService;
import com.hikvision.hae.resource.vo.LimitRangeDetailVO;
import com.hikvision.hae.resource.vo.LimitRangeItemVO;
import io.fabric8.kubernetes.api.model.LimitRange;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author by zhouzhigang6 on 2018/1/23.
 */
@Service
public class LimitRangeServiceImpl implements LimitRangeService {

	@Resource
	private LimitRangeBiz limitRangeBiz;

	@Resource
	private KubeEventHelper kubeEventHelper;

	@Override
	public Pagination<LimitRangeItemVO> findAndPage(String namespace, String name, PageParam pageParam) {
		FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
		Pagination<LimitRange> limitRangePage = limitRangeBiz.findAndPage(filterQuery, pageParam);
		// 无满足条件的数据
		if (limitRangePage.getTotal() == 0) {
			return Pagination.build(pageParam);
		}
		Function<Collection<LimitRange>, Collection<LimitRangeItemVO>> rowsConverter =
				(Collection<LimitRange> dtoList) -> dtoList.stream().map(ResourceVOBuilder::buildLimitRangeItemVO).collect(Collectors.toList());
		return new Pagination<>(limitRangePage, rowsConverter);
	}

	@Override
	public LimitRangeDetailVO getDetail(String namespace, String name) {
		LimitRange limitRange = limitRangeBiz.getByName(namespace, name);
		if (limitRange == null) {
			throw new HAERuntimeException(ResourceResultCode.LIMIT_RANGE_NOT_EXIST);
		}
		return ResourceVOBuilder.buildLimitRangeDetailVO(limitRange);
	}

	@Override
	public void delete(String namespace, String name) {
		limitRangeBiz.delete(namespace, name);
		kubeEventHelper.publishDeleteEvent(ActionLogModules.LIMIT_RANGE, PrincipalCategory.LIMIT_RANGE, namespace, name, "删除limit限制（LimitRange）");
	}
}
