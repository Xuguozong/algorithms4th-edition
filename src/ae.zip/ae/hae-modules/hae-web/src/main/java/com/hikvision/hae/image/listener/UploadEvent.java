package com.hikvision.hae.image.listener;

import com.hikvision.hae.file.model.UploadFile;

public abstract class UploadEvent {

	protected UploadFile upload;
	
	public UploadEvent(UploadFile upload) {
		this.upload = upload;
	}

	public UploadFile getUploadRecord() {
		return upload;
	}
}
