package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.util.encrypt.JWTUtil;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.foundation.common.constant.FoundationResultCode;
import com.hikvision.hae.foundation.service.UserService;
import com.hikvision.hae.foundation.vo.LoginVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

/**
 * Created by zhanjiejun on 2018/3/20.
 */
@RestController
@RequestMapping("/api")
public class TokenRestful {

	@Autowired
	private UserService userService;

	@PostMapping("/token")
	public AjaxResult<String> getToken(@RequestBody LoginVO user) {
		String userName = user.getUsername();
		String orginPwd;
		try {
			orginPwd = new String(Base64.getDecoder().decode(user.getPassword()), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return new AjaxResult<>(CommonResultCode.ILLEGAL_ARGUMENT);
		}

		boolean isAuth = userService.auth(userName, orginPwd);
		if (!isAuth) {
			return new AjaxResult<>(FoundationResultCode.USERNAME_OR_PASSWORD_ERROR);
		}

		AjaxResult<String> result = AjaxResult.buildSuccess();
		result.setData(JWTUtil.signJWT(CommonConstants.JWT_SEC, userName));
		return result;
	}

}
