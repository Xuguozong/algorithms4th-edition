package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.event.biz.EventBiz;
import com.hikvision.hae.resource.service.EventService;
import com.hikvision.hae.resource.vo.EventItemVO;
import io.fabric8.kubernetes.api.model.Event;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/27.
 */
@Service
public class EventServiceImpl implements EventService {

    @Resource
    private EventBiz eventBiz;

    @Override
    public Pagination<EventItemVO> findAndPage(String namespace, String ownerKind, String ownerName, PageParam pageParam) {
        Pagination<Event> eventPage = eventBiz.findAndPage(namespace, ResourceKind.parse(ownerKind), ownerName, pageParam);
        if (eventPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }
        Function<Collection<Event>, Collection<EventItemVO>> eventRowsConverter =
                (Collection<Event> eventList) -> eventList.stream().map(ResourceVOBuilder::buildEventItemVO).collect(Collectors.toList());
        return new Pagination<>(eventPage, eventRowsConverter);
    }
}
