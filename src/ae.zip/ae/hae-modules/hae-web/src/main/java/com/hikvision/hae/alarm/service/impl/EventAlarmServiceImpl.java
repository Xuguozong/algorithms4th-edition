package com.hikvision.hae.alarm.service.impl;

import com.hikvision.hae.alarm.assist.AlarmVOBuilder;
import com.hikvision.hae.alarm.event.biz.EventAlarmBiz;
import com.hikvision.hae.alarm.event.dto.EventAlarmQuery;
import com.hikvision.hae.alarm.event.model.EventAlarm;
import com.hikvision.hae.alarm.service.EventAlarmService;
import com.hikvision.hae.alarm.vo.EventAlarmVO;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
@Service
@Transactional
public class EventAlarmServiceImpl implements EventAlarmService {

	@Autowired
	private EventAlarmBiz eventAlarmBiz;

	@Override
	public Pagination<EventAlarmVO> findAndPage(PageParam pageParam, EventAlarmQuery query) {
		Page<EventAlarm> page = eventAlarmBiz.findAndPage(pageParam, query);
		List<EventAlarmVO> resultList = Optional.ofNullable(page.getContent())
				.map(rows -> rows.stream().map(row -> AlarmVOBuilder.fromEventAlarm(row)).collect(Collectors.toList()))
				.orElse(Collections.emptyList());
		Pagination<EventAlarmVO> resultPage = Pagination.build(pageParam);
		resultPage.setRows(resultList);
		resultPage.setTotal(page.getTotalElements());
		resultPage.setLastPage(page.getTotalPages());
		return resultPage;
	}

	@Override
	public long count(EventAlarmQuery query) {
		return eventAlarmBiz.count(query);
	}

}
