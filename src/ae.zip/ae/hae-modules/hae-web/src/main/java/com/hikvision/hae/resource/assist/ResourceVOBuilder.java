package com.hikvision.hae.resource.assist;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.domain.PodResourceCount;
import com.hikvision.hae.common.util.K8SResourceUnitConverter;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.common.enums.ContainerStatusEnum;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.util.NodeUtil;
import com.hikvision.hae.resource.common.util.PodUtil;
import com.hikvision.hae.resource.event.biz.assist.EventHelper;
import com.hikvision.hae.resource.file.dto.ResourceFileDTO;
import com.hikvision.hae.resource.file.dto.ResourceFileGroupDTO;
import com.hikvision.hae.resource.namespace.dto.NamespaceReadDTO;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import com.hikvision.hae.resource.node.dto.NodeResourceDTO;
import com.hikvision.hae.resource.service.dto.EndpointDTO;
import com.hikvision.hae.resource.vo.*;
import io.fabric8.kubernetes.api.model.*;
import io.fabric8.kubernetes.api.model.extensions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
@Component
public class ResourceVOBuilder {

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private NodeLabelChecker nodeLabelChecker;

	private static ResourceVOBuilder resourceVOBuilder;

	@PostConstruct
	public void init() {
		resourceVOBuilder = this;
		resourceVOBuilder.messageSource = messageSource;
		resourceVOBuilder.nodeLabelChecker = nodeLabelChecker;
	}

	public static List<String> getContainerImages(PodTemplateSpec podTemplateSpec) {
		List<Container> containers = podTemplateSpec.getSpec().getContainers();
		return containers.stream().map(Container::getImage).collect(Collectors.toList());
	}

	public static PodControllerItemVO buildPodControllerItemVO(Deployment deployment, Function<Deployment, PodInfo> podInfoFunc) {
		PodControllerItemVO vo = new PodControllerItemVO();
		vo.setNamespace(deployment.getMetadata().getNamespace());
		vo.setName(deployment.getMetadata().getName());
		vo.setImages(getContainerImages(deployment.getSpec().getTemplate()));
		vo.setLabels(deployment.getMetadata().getLabels());
		PodInfo podInfo = podInfoFunc.apply(deployment);
		vo.setRunningPods(podInfo.getRunning());
		vo.setDesiredPods(podInfo.getDesired());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(deployment.getMetadata().getCreationTimestamp().getTime()));
		vo.setType(ResourceKind.Deployment.name());
		return vo;
	}

	public static PodControllerItemVO buildPodControllerItemVO(StatefulSet statefulSet, Function<StatefulSet, PodInfo> podInfoFunc) {
		PodControllerItemVO vo = new PodControllerItemVO();
		vo.setNamespace(statefulSet.getMetadata().getNamespace());
		vo.setName(statefulSet.getMetadata().getName());
		vo.setImages(getContainerImages(statefulSet.getSpec().getTemplate()));
		vo.setLabels(statefulSet.getMetadata().getLabels());
		PodInfo podInfo = podInfoFunc.apply(statefulSet);
		vo.setRunningPods(podInfo.getRunning());
		vo.setDesiredPods(podInfo.getDesired());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(statefulSet.getMetadata().getCreationTimestamp().getTime()));
		vo.setType(ResourceKind.StatefulSet.name());
		return vo;
	}

	public static PodControllerItemVO buildPodControllerItemVO(ReplicaSet replicaSet, Function<ReplicaSet, PodInfo> podInfoFunc) {
		PodControllerItemVO rsItemVO = new PodControllerItemVO();
		rsItemVO.setNamespace(replicaSet.getMetadata().getNamespace());
		rsItemVO.setName(replicaSet.getMetadata().getName());
		rsItemVO.setLabels(replicaSet.getMetadata().getLabels());
		PodInfo podInfo = podInfoFunc.apply(replicaSet);
		rsItemVO.setRunningPods(podInfo.getRunning());
		rsItemVO.setDesiredPods(podInfo.getDesired());
		List<Container> containers = replicaSet.getSpec().getTemplate().getSpec().getContainers();
		rsItemVO.setImages(containers.stream().map(Container::getImage).collect(Collectors.toList()));
		rsItemVO.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(replicaSet.getMetadata().getCreationTimestamp().getTime()));
		rsItemVO.setType(ResourceKind.ReplicaSet.name());
		return rsItemVO;
	}

	public static PodControllerItemVO buildPodControllerItemVO(ReplicationController rc, Function<ReplicationController, PodInfo> podInfoFunc) {
		PodControllerItemVO vo = new PodControllerItemVO();
		vo.setNamespace(rc.getMetadata().getNamespace());
		vo.setName(rc.getMetadata().getName());
		vo.setLabels(rc.getMetadata().getLabels());
		PodInfo podInfo = podInfoFunc.apply(rc);
		vo.setRunningPods(podInfo.getRunning());
		vo.setDesiredPods(podInfo.getDesired());
		List<Container> containers = rc.getSpec().getTemplate().getSpec().getContainers();
		vo.setImages(containers.stream().map(Container::getImage).collect(Collectors.toList()));
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(rc.getMetadata().getCreationTimestamp().getTime()));
		vo.setType(ResourceKind.ReplicationController.name());
		return vo;
	}

	public static PodControllerItemVO buildPodControllerItemVO(Job job, Function<Job, PodInfo> podInfoFunc) {
		PodControllerItemVO vo = new PodControllerItemVO();
		vo.setNamespace(job.getMetadata().getNamespace());
		vo.setName(job.getMetadata().getName());
		vo.setLabels(job.getMetadata().getLabels());
		PodInfo podInfo = podInfoFunc.apply(job);
		vo.setRunningPods(podInfo.getRunning());
		vo.setDesiredPods(podInfo.getDesired());
		List<Container> containers = job.getSpec().getTemplate().getSpec().getContainers();
		vo.setImages(containers.stream().map(Container::getImage).collect(Collectors.toList()));
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(job.getMetadata().getCreationTimestamp().getTime()));
		vo.setType(ResourceKind.Job.name());
		return vo;
	}

	public static PodControllerItemVO buildPodControllerItemVO(DaemonSet daemonSet, Function<DaemonSet, PodInfo> podInfoFunc) {
		PodControllerItemVO vo = new PodControllerItemVO();
		vo.setNamespace(daemonSet.getMetadata().getNamespace());
		vo.setName(daemonSet.getMetadata().getName());
		vo.setLabels(daemonSet.getMetadata().getLabels());
		PodInfo podInfo = podInfoFunc.apply(daemonSet);
		vo.setRunningPods(podInfo.getRunning());
		vo.setDesiredPods(podInfo.getDesired());
		List<Container> containers = daemonSet.getSpec().getTemplate().getSpec().getContainers();
		vo.setImages(containers.stream().map(Container::getImage).collect(Collectors.toList()));
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(daemonSet.getMetadata().getCreationTimestamp().getTime()));
		vo.setType(ResourceKind.DaemonSet.name());
		vo.setWarningMessages(podInfo.getWarningMessages());
		return vo;
	}

	public static DeploymentDetailVO.RollingUpdateStrategy buildRollingUpdateStrategyVO(RollingUpdateDeployment rollingUpdateDeployment) {
		IntOrString maxSurgeStr = rollingUpdateDeployment.getMaxSurge();
		String maxSurge = StringUtils.hasText(maxSurgeStr.getStrVal()) ? maxSurgeStr.getStrVal() : String.valueOf(maxSurgeStr.getIntVal());
		IntOrString maxUnavailableStr = rollingUpdateDeployment.getMaxUnavailable();
		String maxUnavailable = StringUtils.hasText(maxUnavailableStr.getStrVal()) ?
				maxUnavailableStr.getStrVal() : String.valueOf(maxUnavailableStr.getIntVal());
		return new DeploymentDetailVO.RollingUpdateStrategy(maxSurge, maxUnavailable);
	}


	public static HPAItemVO buildHPAItemVO(HorizontalPodAutoscaler hpa) {
		HPAItemVO hpaItemVO = new HPAItemVO();
		hpaItemVO.setNamespace(hpa.getMetadata().getNamespace());
		hpaItemVO.setName(hpa.getMetadata().getName());
		hpaItemVO.setTargetCPUUtilizationPercentage(hpa.getSpec().getTargetCPUUtilizationPercentage());
		hpaItemVO.setCurrentCPUUtilizationPercentage(hpa.getStatus().getCurrentCPUUtilizationPercentage());
		hpaItemVO.setMinReplicas(hpa.getSpec().getMinReplicas());
		hpaItemVO.setMaxReplicas(hpa.getSpec().getMaxReplicas());
		hpaItemVO.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(hpa.getMetadata().getCreationTimestamp().getTime()));
		return hpaItemVO;
	}

	public static EventItemVO buildEventItemVO(Event event) {
		EventItemVO eventItemVO = new EventItemVO();
		eventItemVO.setMessage(event.getMessage());
		eventItemVO.setSourceComponent(event.getSource().getComponent());
		eventItemVO.setSourceHost(event.getSource().getHost());
		eventItemVO.setObject(event.getInvolvedObject().getFieldPath());
		eventItemVO.setCount(event.getCount());
		eventItemVO.setFirstSeen(UTCDateUtil.parseUTCTimeToStandardDate(event.getFirstTimestamp().getTime()));
		eventItemVO.setLastSeen(UTCDateUtil.parseUTCTimeToStandardDate(event.getLastTimestamp().getTime()));
		return eventItemVO;
	}

	public static NamespaceDetailVO buildNamespaceVO(NamespaceReadDTO namespaceReadDTO) {
		NamespaceDetailVO namespaceVO = new NamespaceDetailVO();
		namespaceVO.setName(namespaceReadDTO.getName());
		namespaceVO.setStatus(namespaceReadDTO.getStatus().name());
		namespaceVO.setStatusName(resourceVOBuilder.messageSource.getMessage(namespaceReadDTO.getStatus().i18nKey(), null, "", LocaleContextHolder.getLocale()));
		namespaceVO.setCreateTime(namespaceReadDTO.getCreateTime());
		namespaceVO.setHasResourceQuota(namespaceReadDTO.isHasResourceQuota());
		namespaceVO.setK8SDefault(namespaceReadDTO.isK8SDefault());
		if (!namespaceReadDTO.isK8SDefault()) {
			if (namespaceReadDTO.getHard() != null) {
				namespaceVO.setCpuTotal(K8SResourceUnitConverter.convertCPU2Cores(namespaceReadDTO.getHard().get(CommonConstants.MAP_CPU_RESOURCE_KEY).getAmount()));
				namespaceVO.setMemoryTotal(K8SResourceUnitConverter.convertMemory2Gi(namespaceReadDTO.getHard().get(CommonConstants.MAP_MEMORY_RESOURCE_KEY).getAmount()));
				namespaceVO.setGpuTotal(K8SResourceUnitConverter.formatGPUAmount(namespaceReadDTO.getHard().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S).getAmount()));
			}
			if (namespaceReadDTO.getUsed() != null) {
				namespaceVO.setCpuUsed(K8SResourceUnitConverter.convertCPU2Cores(namespaceReadDTO.getUsed().get(CommonConstants.MAP_CPU_RESOURCE_KEY).getAmount()));
				namespaceVO.setMemoryUsed(K8SResourceUnitConverter.convertMemory2Gi(namespaceReadDTO.getUsed().get(CommonConstants.MAP_MEMORY_RESOURCE_KEY).getAmount()));
				namespaceVO.setGpuUsed(K8SResourceUnitConverter.formatGPUAmount(namespaceReadDTO.getUsed().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S).getAmount()));
			}
		}
		return namespaceVO;
	}

	public static NodeBaseVO buildNodeBaseVO(NodeBaseDTO nodeBaseDTO) {
		NodeBaseVO nodeBaseVO = new NodeBaseVO();
		nodeBaseVO.setId(nodeBaseDTO.getId());
		nodeBaseVO.setName(nodeBaseDTO.getName());
		nodeBaseVO.setStatusName(resourceVOBuilder.messageSource.getMessage(nodeBaseDTO.getStatus().i18nKey(), null, "", LocaleContextHolder.getLocale()));
		nodeBaseVO.setStatus(nodeBaseDTO.getStatus().name());
		nodeBaseVO.setIp(nodeBaseDTO.getIp());
		nodeBaseVO.setCreateTime(nodeBaseDTO.getCreateTime());
		nodeBaseVO.setSshUser(nodeBaseDTO.getSshUser());
		if (nodeBaseDTO.getCapacity() != null) {
			Map<String, String> capacity = new HashMap<>();
			Quantity cpuCapacity = nodeBaseDTO.getCapacity().get(CommonConstants.MAP_CPU_RESOURCE_KEY);
			capacity.put(CommonConstants.MAP_CPU_RESOURCE_KEY,
					cpuCapacity == null ? "0" : String.valueOf(K8SResourceUnitConverter.convertCPU2Cores(cpuCapacity.getAmount())));
			Quantity memoryCapacity = nodeBaseDTO.getCapacity().get(CommonConstants.MAP_MEMORY_RESOURCE_KEY);
			capacity.put(CommonConstants.MAP_MEMORY_RESOURCE_KEY,
					memoryCapacity == null ? "0" : String.valueOf(K8SResourceUnitConverter.convertMemory2Gi(memoryCapacity.getAmount())));
			Quantity gpuCapacity = nodeBaseDTO.getCapacity().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S);
			capacity.put(CommonConstants.MAP_GPU_RESOURCE_KEY_FOR_FRONT,
					gpuCapacity == null ? "0" : String.valueOf(gpuCapacity.getAmount()));
			Quantity podCapacity = nodeBaseDTO.getCapacity().get(CommonConstants.MAP_POD_RESOURCE_KEY);
			capacity.put(CommonConstants.MAP_POD_RESOURCE_KEY, podCapacity == null ? "0" : podCapacity.getAmount());
			nodeBaseVO.setCapacity(capacity);

			if (nodeBaseDTO.getAllocatable() != null) {
				Map<String, String> allocatable = new HashMap<>();
				Quantity cpuAllocatable = nodeBaseDTO.getAllocatable().get(CommonConstants.MAP_CPU_RESOURCE_KEY);
				allocatable.put(CommonConstants.MAP_CPU_RESOURCE_KEY,
						cpuAllocatable == null ? capacity.get(CommonConstants.MAP_CPU_RESOURCE_KEY) : String.valueOf(K8SResourceUnitConverter.convertCPU2Cores(cpuAllocatable.getAmount())));
				Quantity memoryAllocatable = nodeBaseDTO.getAllocatable().get(CommonConstants.MAP_MEMORY_RESOURCE_KEY);
				allocatable.put(CommonConstants.MAP_MEMORY_RESOURCE_KEY,
						memoryAllocatable == null ? capacity.get(CommonConstants.MAP_MEMORY_RESOURCE_KEY) : String.valueOf(K8SResourceUnitConverter.convertMemory2Gi(memoryAllocatable.getAmount())));
				Quantity gpuAllocatable = nodeBaseDTO.getAllocatable().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S);
				allocatable.put(CommonConstants.MAP_GPU_RESOURCE_KEY_FOR_FRONT, gpuAllocatable == null ?
						capacity.get(CommonConstants.MAP_GPU_RESOURCE_KEY_FOR_FRONT) : String.valueOf(gpuAllocatable.getAmount()));
				nodeBaseVO.setAllocatable(allocatable);
			}
		}

		List<LabelVO> resultLabels = new ArrayList<>();
		Map<String, String> labels = nodeBaseDTO.getLabels();
		if (labels != null) {
			nodeBaseVO.setMaster(NodeUtil.isMaster(labels));
			nodeBaseVO.setAnsible(NodeUtil.isAnsible(labels));
			nodeBaseDTO.getLabels().forEach((k, v) -> {
				resultLabels.add(new LabelVO(k, v, resourceVOBuilder.nodeLabelChecker.isSystemDefault(k)));
			});
		}
		nodeBaseVO.setLabels(resultLabels);
		return nodeBaseVO;
	}

	public static NodeResourceVO buildNodeResourceVO(NodeResourceDTO nodeResourceDTO) {
		NodeResourceVO nodeResourceVO = new NodeResourceVO();
		nodeResourceVO.setPodUsed(nodeResourceDTO.getPodUsed());
		nodeResourceVO.setLimits(nodeResourceDTO.getLimits());
		nodeResourceVO.setRequests(nodeResourceDTO.getRequests());
		return nodeResourceVO;
	}

	public static DeploymentStatusInfoVO buildDeploymentStatusInfoVO(Deployment deployment) {
		DeploymentStatusInfoVO vo = new DeploymentStatusInfoVO();
		vo.setAvailable(deployment.getStatus().getAvailableReplicas());
		vo.setReplicas(deployment.getStatus().getReplicas());
		vo.setUnavailable(deployment.getStatus().getUnavailableReplicas());
		vo.setUpdated(deployment.getStatus().getUpdatedReplicas());
		return vo;
	}

	public static PodInfoVO buildPodInfoVO(PodInfo podInfoDTO) {
		PodInfoVO vo = new PodInfoVO();
		vo.setCurrent(podInfoDTO.getCurrent());
		vo.setDesired(podInfoDTO.getDesired());
		vo.setFailed(podInfoDTO.getFailed());
		vo.setPending(podInfoDTO.getPending());
		vo.setRunning(podInfoDTO.getRunning());
		vo.setSucceeded(podInfoDTO.getSucceeded());
		return vo;
	}

	public static PodItemVO buildPodItemVO(Pod pod, Map<String, String> nodeNames, List<Event> eventList) {
		PodItemVO vo = new PodItemVO();
		vo.setNamespace(pod.getMetadata().getNamespace());
		vo.setName(pod.getMetadata().getName());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(pod.getMetadata().getCreationTimestamp().getTime()));
		vo.setNodeName(nodeNames.get(pod.getSpec().getNodeName()));

		List<ContainerStatus> containerStatuses = pod.getStatus().getContainerStatuses();
		int restartCount = containerStatuses.stream().collect(Collectors.summingInt(ContainerStatus::getRestartCount));
		String containerStatus = ContainerStatusEnum.Running.toString(); // 容器状态
		if (CollectionUtils.isEmpty(containerStatuses)) {
			containerStatus = null;
		}
		String reason = null; // 原因（非正常时）
		// 从dashboard中前端对展示的状态的处理逻辑来看，通过倒序遍历，执行下面的逻辑
		// 实际取的就是第一个状态的数据，故此按照这种逻辑处理前端展示的状态
		if (containerStatus != null) {
			ContainerStatus firstStatus = containerStatuses.get(0);
			if (firstStatus.getState().getTerminated() != null) {
				ContainerStateTerminated terminated = firstStatus.getState().getTerminated();
				containerStatus = ContainerStatusEnum.Terminated.toString();
				reason = terminated.getReason();
				if (StringUtils.isEmpty(reason)) {
					if (terminated.getSignal() != null) {
						reason = "Signal:" + terminated.getSignal();
					} else {
						reason = "ExitCode:" + terminated.getExitCode();
					}
				}
			} else if (firstStatus.getState().getWaiting() != null) {
				containerStatus = ContainerStatusEnum.Waiting.toString();
				reason = firstStatus.getState().getWaiting().getReason();
			}
		}

		// 设置警告消息（如果容器状态不正常）
		if (!com.hikvision.hae.resource.pod.biz.assist.PodHelper.isReadyOrSucceeded(pod)) {
			eventList = EventHelper.filterByInvolvedObjectUid(eventList, pod.getMetadata().getUid());
			List<String> warningMessages = new ArrayList<>();
			eventList.forEach(e -> warningMessages.add(e.getMessage()));
			vo.setWarningMessages(warningMessages);
		}

		vo.setRestartCount(restartCount);
		vo.setPhase(pod.getStatus().getPhase());
		vo.setContainerStatus(containerStatus);
		vo.setReason(reason);
		PodResourceCount podResourceCount = PodUtil.calculateResource(pod);
		vo.setGpuRequest(podResourceCount.getGpuRequest());
		return vo;
	}

	public static ServiceItemVO buildServiceItemVO(Service service,
												   Function<Service, EndpointDTO> internalEndpointFunc,
												   Function<Service, List<EndpointDTO>> externalEndpointFunc) {
		ServiceItemVO vo = new ServiceItemVO();
		vo.setNamespace(service.getMetadata().getNamespace());
		vo.setName(service.getMetadata().getName());
		vo.setLabels(service.getMetadata().getLabels());
		vo.setClusterIP(service.getSpec().getClusterIP());

		EndpointDTO internal = internalEndpointFunc.apply(service);
		ServiceItemVO.EndpointVO internalVO = buildEndpointVO(internal);
		vo.setInternalEndpoint(internalVO);

		List<EndpointDTO> externals = externalEndpointFunc.apply(service);
		if (!CollectionUtils.isEmpty(externals)) {
			vo.setExternalEndpoints(externals.stream().map(ResourceVOBuilder::buildEndpointVO).collect(Collectors.toList()));
		}

		vo.setType(service.getSpec().getType());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(service.getMetadata().getCreationTimestamp().getTime()));
		return vo;
	}

	private static ServiceItemVO.PortVO buildServicePortVO(ServicePort sp) {
		ServiceItemVO.PortVO spVO = new ServiceItemVO.PortVO();
		spVO.setNodePort(sp.getNodePort());
		spVO.setPort(sp.getPort());
		spVO.setProtocol(sp.getProtocol());
		IntOrString targetPort = sp.getTargetPort();
		spVO.setTargetPort(StringUtils.hasText(targetPort.getStrVal()) ? targetPort.getStrVal() : String.valueOf(targetPort.getIntVal()));
		return spVO;
	}

	public static ServiceItemVO.EndpointVO buildEndpointVO(EndpointDTO endpointDTO) {
		List<ServicePort> servicePorts = endpointDTO.getPorts();
		List<ServiceItemVO.PortVO> ports = servicePorts.stream().map(ResourceVOBuilder::buildServicePortVO).collect(Collectors.toList());
		ServiceItemVO.EndpointVO endpointVO = new ServiceItemVO.EndpointVO();
		endpointVO.setHost(endpointDTO.getHost());
		endpointVO.setPorts(ports);
		return endpointVO;
	}

	public static StorageClassVO buildStorageClassVO(StorageClass storageClass) {
		StorageClassVO vo = new StorageClassVO();
		vo.setName(storageClass.getMetadata().getName());
		vo.setLabels(storageClass.getMetadata().getLabels());
		vo.setAnnotations(storageClass.getMetadata().getAnnotations());
		vo.setProvisioner(storageClass.getProvisioner());
		vo.setParameters(storageClass.getParameters());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(storageClass.getMetadata().getCreationTimestamp().getTime()));
		return vo;
	}

	public static PersistentVolumeItemVO buildPersistentVolumeItemVO(PersistentVolume persistentVolume) {
		PersistentVolumeItemVO vo = new PersistentVolumeItemVO();
		vo.setName(persistentVolume.getMetadata().getName());
		vo.setLabels(persistentVolume.getMetadata().getLabels());
		vo.setAccessModes(persistentVolume.getSpec().getAccessModes());
		vo.setCapacity(buildVolumeCapacity(persistentVolume.getSpec().getCapacity()));
		vo.setStatus(persistentVolume.getStatus().getPhase());
		ObjectReference ref = persistentVolume.getSpec().getClaimRef();
		if (ref != null) {
			vo.setClaim(ref.getNamespace() + "/" + ref.getName());
		}

		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(persistentVolume.getMetadata().getCreationTimestamp().getTime()));
		return vo;
	}

	// Currently, storage size is the only resource that can be set or requested.
	// Future attributes may include IOPS, throughput, etc
	private static Map<String, String> buildVolumeCapacity(Map<String, Quantity> cap) {
		if (cap == null) {
			return null;
		}
		Map<String, String> capacity = new HashMap<>();
		cap.forEach((res, quantity) -> capacity.put(res, quantity.getAmount()));
		return capacity;
	}

	public static PersistentVolumeDetailVO buildPersistentVolumeDetailVO(PersistentVolume persistentVolume) {
		PersistentVolumeDetailVO vo = new PersistentVolumeDetailVO();
		vo.setName(persistentVolume.getMetadata().getName());
		vo.setLabels(persistentVolume.getMetadata().getLabels());
		vo.setAnnotations(persistentVolume.getMetadata().getAnnotations());
		vo.setCapacity(buildVolumeCapacity(persistentVolume.getSpec().getCapacity()));
		vo.setAccessModes(persistentVolume.getSpec().getAccessModes());
		vo.setStatus(persistentVolume.getStatus().getPhase());
		vo.setReclaimPolicy(persistentVolume.getSpec().getPersistentVolumeReclaimPolicy());
		ObjectReference ref = persistentVolume.getSpec().getClaimRef();
		if (ref != null) {
			vo.setClaim(ref.getNamespace() + "/" + ref.getName());
		}
		vo.setReason(persistentVolume.getStatus().getReason());
		vo.setMessage(persistentVolume.getStatus().getMessage());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(persistentVolume.getMetadata().getCreationTimestamp().getTime()));
		//具体存储的信息: 目前只记录HostPath和NFS
		HostPathVolumeSource hostPathPV = persistentVolume.getSpec().getHostPath();
		NFSVolumeSource nfsPV = persistentVolume.getSpec().getNfs();
		ISCSIVolumeSource iscsiPV = persistentVolume.getSpec().getIscsi();
		PersistentVolumeSourceVO source;
		if (hostPathPV != null) {
			source = new PersistentVolumeSourceVO("HostPath", hostPathPV);
		} else if (nfsPV != null) {
			source = new PersistentVolumeSourceVO("NFS", nfsPV);
		} else if (iscsiPV != null) {
			source = new PersistentVolumeSourceVO("ISCSI", iscsiPV);
		} else {
			source = null;
		}
		vo.setSource(source);
		return vo;
	}

	public static PersistentVolumeClaimVO buildPersistentVolumeClaimVO(PersistentVolumeClaim persistentVolumeClaim) {
		PersistentVolumeClaimVO vo = new PersistentVolumeClaimVO();
		vo.setNamespace(persistentVolumeClaim.getMetadata().getNamespace());
		vo.setName(persistentVolumeClaim.getMetadata().getName());
		vo.setVolume(persistentVolumeClaim.getSpec().getVolumeName());
		vo.setStatus(persistentVolumeClaim.getStatus().getPhase());
		vo.setLabels(persistentVolumeClaim.getMetadata().getLabels());
		vo.setAnnotations(persistentVolumeClaim.getMetadata().getAnnotations());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(persistentVolumeClaim.getMetadata().getCreationTimestamp().getTime()));
		vo.setCapacity(buildVolumeCapacity(persistentVolumeClaim.getStatus().getCapacity()));
		vo.setAccessModes(persistentVolumeClaim.getSpec().getAccessModes());
		return vo;
	}


	public static IngressItemVO buildIngressItemVO(Ingress ingress) {
		IngressItemVO vo = new IngressItemVO();
		vo.setNamespace(ingress.getMetadata().getNamespace());
		vo.setName(ingress.getMetadata().getName());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(ingress.getMetadata().getCreationTimestamp().getTime()));
		List<LoadBalancerIngress> loadBalancerIngresses = ingress.getStatus().getLoadBalancer().getIngress();
		if (!CollectionUtils.isEmpty(loadBalancerIngresses)) {
			List<String> endpoints = loadBalancerIngresses.stream().map(LoadBalancerIngress::getIp).collect(Collectors.toList());
			vo.setEndpoints(endpoints);
		}
		return vo;
	}

	public static IngressDetailVO buildIngressDetailVO(Ingress ingress) {
		IngressDetailVO vo = new IngressDetailVO();
		vo.setNamespace(ingress.getMetadata().getNamespace());
		vo.setName(ingress.getMetadata().getName());
		vo.setLabels(ingress.getMetadata().getLabels());
		vo.setAnnotations(ingress.getMetadata().getAnnotations());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(ingress.getMetadata().getCreationTimestamp().getTime()));
		List<LoadBalancerIngress> loadBalancerIngresses = ingress.getStatus().getLoadBalancer().getIngress();
		if (!CollectionUtils.isEmpty(loadBalancerIngresses)) {
			List<String> endpoints = loadBalancerIngresses.stream().map(LoadBalancerIngress::getIp).collect(Collectors.toList());
			vo.setEndpoints(endpoints);
		}
		return vo;
	}

	public static ResourceFileVO buildResourceFileVO(ResourceFileDTO dto) {
		ResourceFileVO vo = new ResourceFileVO();
		vo.setId(dto.getId());
		vo.setGroupId(dto.getGroupId());
		vo.setFileName(dto.getFileName());
		vo.setContent(dto.getContent());
		vo.setCreateTime(dto.getCreateTime());
		return vo;
	}

	public static ResourceFileGroupVO buildResourceFileGroupVO(ResourceFileGroupDTO dto, List<ResourceFileVO> files) {
		ResourceFileGroupVO vo = new ResourceFileGroupVO();
		vo.setId(dto.getId());
		vo.setGroupName(dto.getGroupName());
		vo.setCreateTime(dto.getCreateTime());
		vo.setFiles(files);
		return vo;
	}

	public static ConfigMapItemVO buildConfigMapItemVO(ConfigMap configMap) {
		ConfigMapItemVO vo = new ConfigMapItemVO();
		vo.setName(configMap.getMetadata().getName());
		vo.setNamespace(configMap.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(configMap.getMetadata().getCreationTimestamp().getTime()));
		vo.setLabels(configMap.getMetadata().getLabels());
		return vo;
	}

	public static ConfigMapDetailVO buildConfigMapDetailVO(ConfigMap configMap) {
		ConfigMapDetailVO vo = new ConfigMapDetailVO();
		vo.setName(configMap.getMetadata().getName());
		vo.setNamespace(configMap.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(configMap.getMetadata().getCreationTimestamp().getTime()));
		vo.setLabels(configMap.getMetadata().getLabels());
		vo.setAnnotations(configMap.getMetadata().getAnnotations());
		vo.setData(configMap.getData());
		return vo;
	}

	public static ResourceQuotaItemVO buildResourceQuotaItemVO(ResourceQuota resourceQuota) {
		ResourceQuotaItemVO vo = new ResourceQuotaItemVO();
		vo.setName(resourceQuota.getMetadata().getName());
		vo.setNamespace(resourceQuota.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(resourceQuota.getMetadata().getCreationTimestamp().getTime()));
		return vo;
	}

	public static ResourceQuotaDetailVO buildResourceQuotaDetailVO(ResourceQuota resourceQuota) {
		ResourceQuotaDetailVO vo = new ResourceQuotaDetailVO();
		vo.setName(resourceQuota.getMetadata().getName());
		vo.setNamespace(resourceQuota.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(resourceQuota.getMetadata().getCreationTimestamp().getTime()));
		vo.setLabels(resourceQuota.getMetadata().getLabels());
		vo.setAnnotations(resourceQuota.getMetadata().getAnnotations());
		vo.setResourceQuotaSpec(resourceQuota.getSpec());
		return vo;
	}

	public static LimitRangeItemVO buildLimitRangeItemVO(LimitRange limitRange) {
		LimitRangeItemVO vo = new LimitRangeItemVO();
		vo.setName(limitRange.getMetadata().getName());
		vo.setNamespace(limitRange.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(limitRange.getMetadata().getCreationTimestamp().getTime()));
		return vo;
	}

	public static LimitRangeDetailVO buildLimitRangeDetailVO(LimitRange limitRange) {
		LimitRangeDetailVO vo = new LimitRangeDetailVO();
		vo.setName(limitRange.getMetadata().getName());
		vo.setNamespace(limitRange.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(limitRange.getMetadata().getCreationTimestamp().getTime()));
		vo.setLabels(limitRange.getMetadata().getLabels());
		vo.setAnnotations(limitRange.getMetadata().getAnnotations());
		vo.setLimitRangeSpec(limitRange.getSpec());
		return vo;
	}

	public static SecretItemVO buildSecretItemVO(Secret secret) {
		SecretItemVO vo = new SecretItemVO();
		vo.setName(secret.getMetadata().getName());
		vo.setNamespace(secret.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(secret.getMetadata().getCreationTimestamp().getTime()));
		return vo;
	}

	public static SecretDetailVO buildSecretDetailVO(Secret secret) {
		SecretDetailVO vo = new SecretDetailVO();
		vo.setName(secret.getMetadata().getName());
		vo.setNamespace(secret.getMetadata().getNamespace());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(secret.getMetadata().getCreationTimestamp().getTime()));
		vo.setLabels(secret.getMetadata().getLabels());
		vo.setAnnotations(secret.getMetadata().getAnnotations());
		vo.setData(secret.getData());
		return vo;
	}

	/**
	 * 创建服务账号列表VO
	 *
	 * @param serviceAccount 服务账号资源
	 * @return 服务账号列表VO
	 */
	public static ServiceAccountListVO buildServiceAccountListVO(ServiceAccount serviceAccount) {

		ServiceAccountListVO result = new ServiceAccountListVO();
		result.setName(serviceAccount.getMetadata().getName());
		result.setNamespace(serviceAccount.getMetadata().getNamespace());
		result.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(serviceAccount.getMetadata().getCreationTimestamp().getTime()));
		return result;
	}

	/**
	 * 创建服务账号列表VO
	 *
	 * @param serviceAccount 服务账号资源
	 * @return 服务账号列表VO
	 */
	public static ServiceAccountDetailVO buildServiceAccountDetailVO(ServiceAccount serviceAccount) {

		ServiceAccountDetailVO result = new ServiceAccountDetailVO();
		result.setName(serviceAccount.getMetadata().getName());
		result.setNamespace(serviceAccount.getMetadata().getNamespace());
		result.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(serviceAccount.getMetadata().getCreationTimestamp().getTime()));
		result.setAutomountServiceAccountToken(serviceAccount.getAutomountServiceAccountToken());
		Map<String, String> imagePullSecrets = new HashMap<>();
		//TODO
		result.setImagePullSecrets(imagePullSecrets);
		Map<String, String> secrets = new HashMap<>();
		//TODO
		result.setSecrets(secrets);
		return result;
	}
}
