package com.hikvision.hae.image.vo;

import com.hikvision.hae.file.model.UploadFile;

public class UploadFileItemVO {

	private String id;

	private String nativePath;

	private String fileName;

	private String status;

	private String failedReason;

	private int currentTrunk;

	private int trunks;

	private long totalSize;

	private String statusName;

	public UploadFileItemVO(UploadFile origin) {
		this.id = origin.getFileId();
		this.nativePath = origin.getNativePath();
		this.fileName = origin.getFileName();
		this.status = origin.getStatus().name();
		this.statusName = origin.getStatus().getContent();
		this.failedReason = origin.getFailedReason();
		this.currentTrunk = origin.getCurrentTrunk();
		this.trunks = origin.getTotalChunks();
		this.totalSize = origin.getTotalSize();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNativePath() {
		return nativePath;
	}

	public void setNativePath(String nativePath) {
		this.nativePath = nativePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFailedReason() {
		return failedReason;
	}

	public void setFailedReason(String failedReason) {
		this.failedReason = failedReason;
	}

	public int getCurrentTrunk() {
		return currentTrunk;
	}

	public void setCurrentTrunk(int currentTrunk) {
		this.currentTrunk = currentTrunk;
	}

	public int getTrunks() {
		return trunks;
	}

	public void setTrunks(int trunks) {
		this.trunks = trunks;
	}

	public long getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
}
