package com.hikvision.hae.resource.service;

import com.hikvision.hae.resource.common.enums.ResourceKind;

/**
 * 操作K8S资源对象的原生JSON
 *
 * @author jianghaiyang5 on 2017/11/9.
 */
public interface RawResourceService {
    /**
     * 查询资源
     *
     * @param kind      资源类型
     * @param namespace 命名空间
     * @param name      资源名称
     * @return 资源的原生JSON
     */
    String getResource(ResourceKind kind, String namespace, String name);

    /**
     * 修改资源
     *
     * @param newYamlText 资源的新定义
     */
    void updateResource(String newYamlText);

}
