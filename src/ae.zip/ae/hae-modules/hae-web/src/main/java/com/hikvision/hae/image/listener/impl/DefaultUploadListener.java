package com.hikvision.hae.image.listener.impl;

import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.image.listener.PushFileEvent;
import com.hikvision.hae.image.listener.PushListener;
import com.hikvision.hae.image.listener.UploadFileCompleteEvent;
import com.hikvision.hae.image.listener.UploadListener;
import com.hikvision.hae.image.service.UploadStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.Comparator;

@Service
public class DefaultUploadListener implements UploadListener {

	private static Logger logger = LoggerFactory.getLogger(DefaultUploadListener.class);

	@Resource
	private PushListener pushListener;

	@Resource
	private UploadFileBiz uploadBiz;

	@Resource
	private UploadStatusService statusService;

	/**
	 * 合并上传文件，合并后的文件交给推送服务处理
	 */
	@Override
    @Async("getDockerFileMergePool")
	public void process(UploadFileCompleteEvent event) {
		String fileId = event.getUploadFileId();
		String fileName = event.getUploadFileName();
		logger.info("开始合并文件id:{} name:{}", fileId, fileName);
		File uploadDir = new File(event.getUploadPath());
		File[] uploadParts = uploadDir.listFiles();
		if (uploadParts.length != event.totalTrunks()) {
			logger.error("临时文件夹中的分片数量与实际记录的分片数量不一致，文件id:{} name:{}", fileId, fileName);
			statusService.updateToMergeError(fileId, "临时文件夹中保存的文件不完整");
			return;
		}
		statusService.updateToMerging(fileId);
		Arrays.sort(uploadParts, new Comparator<File>() {
			@Override
			public int compare(File f1, File f2) {
				String f1Name = f1.getName();
				String f2Name = f2.getName();
				return Integer.parseInt(f1Name) - Integer.parseInt(f2Name);
			}
		});
		File outFile = new File(event.getUploadPath(), fileName);
		try (FileOutputStream fout = new FileOutputStream(outFile)) {
			FileChannel outChannel = fout.getChannel();
			long copyCount = 0;
			for (File f : uploadParts) {
				try (FileChannel inChannel = new FileInputStream(f).getChannel()) {
					inChannel.transferTo(0, inChannel.size(), outChannel);
					copyCount += inChannel.size();
				}
				if (!f.delete()) {
					logger.warn("删除文件分片失败{}", f.getAbsolutePath());
				}
			}
			if (copyCount != event.getUploadRecord().getTotalSize()) {
				logger.error("合并文件id:{} name:{}失败，合成后文件大小：{}和上传文件大小：{}不相等", fileId, fileName, copyCount, event.getUploadRecord().getTotalSize());
				statusService.updateToMergeError(fileId, "镜像文件上传不完整");
				return;
			}
			logger.info("合并上传文件id:{} name:{}成功", fileId, fileName);
			statusService.updateToWaitingPush(fileId);
		} catch (IOException e) {
			logger.error("合并上传文件id:" + fileId + " name:" + fileName + "发生异常", e);
			statusService.updateToMergeError(event.getUploadFileId(), StringUtils.isEmpty(e.getMessage()) ? "合并镜像文件失败" : e.getMessage());
			return;
		}
		PushFileEvent pushEvent = new PushFileEvent(event.getUploadRecord(), outFile);
		pushListener.process(pushEvent);
	}

}
