package com.hikvision.hae.common.vo;

import com.hikvision.hae.common.enums.MetricsType;
import io.swagger.annotations.ApiParam;

/**
 * Created by zhanjiejun on 2018/4/9.
 */
public class MetricsQueryVO {

	@ApiParam(required = true)
	private MetricsType metricsType;

	@ApiParam(value = "默认15Min前时间戳")
	private Long start;

	@ApiParam(value = "默认当前时间时间戳")
	private Long end;

	public MetricsType getMetricsType() {
		return metricsType;
	}

	public void setMetricsType(MetricsType metricsType) {
		this.metricsType = metricsType;
	}

	public Long getStart() {
		return start;
	}

	public void setStart(Long start) {
		this.start = start;
	}

	public Long getEnd() {
		return end;
	}

	public void setEnd(Long end) {
		this.end = end;
	}
}
