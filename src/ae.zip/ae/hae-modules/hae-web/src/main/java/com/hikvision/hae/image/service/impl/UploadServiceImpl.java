package com.hikvision.hae.image.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.eventcenter.enums.ImageActionType;
import com.hikvision.hae.file.biz.UploadConfigBiz;
import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.dto.CreateUploadFileDTO;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.listener.UploadFileCompleteEvent;
import com.hikvision.hae.image.listener.UploadListener;
import com.hikvision.hae.image.service.UploadService;
import com.hikvision.hae.image.service.UploadStatusService;
import com.hikvision.hae.image.vo.UploadFileVO;
import com.hikvision.hae.common.constant.ImageResultCode;

@Service
public class UploadServiceImpl extends BaseImageService implements UploadService {

	private static final Logger logger = LoggerFactory.getLogger(UploadServiceImpl.class);

	@Resource
	private UploadFileBiz uploadBiz;

	@Resource
	private UploadConfigBiz configService;

	@Resource
	private UploadListener uploadListener;

	@Resource
	private UploadStatusService statusService;

	private List<UploadStatus> legalState;

	private AtomicLong index = new AtomicLong(1);

	@PostConstruct
	public void init() {
		legalState = new ArrayList<>(2);
		legalState.add(UploadStatus.UPLOADING);
		legalState.add(UploadStatus.UPLOAD_BREAK);
	}

	@Override
	public void preUpload(MultipartFile uploadFile, UploadFileVO uploadInfo) {
		String fileId = uploadInfo.getId();
		String originalFileName = uploadInfo.getFileName();
		UploadFile file = uploadBiz.getById(fileId, true);
		if (file == null) {
			String configPath = configService.uploadLocation();
			File saveParentPath = new File(new File(configPath), originalFileName + index.getAndIncrement());

			CreateUploadFileDTO createDTO = new CreateUploadFileDTO();
			createDTO.setFileId(uploadInfo.getId());
			createDTO.setNativePath(uploadInfo.getNativePath());
			createDTO.setFileName(originalFileName);
			createDTO.setCurrentTrunk(1);
			createDTO.setTotalChunks(uploadInfo.getTrunks());
			createDTO.setTmpSavePath(saveParentPath.getAbsolutePath());
			createDTO.setTotalSize(uploadInfo.getTotalSize());
			file = uploadBiz.create(createDTO);
			// fire event
			statusService.updateToUploading(file.getFileId());
			publishActionLog(ImageActionType.UPLOAD, file.getFileName(), "上传镜像文件");
			logger.info("新建文件上传记录：{}", file);
		} else {
			if (!legalState.contains(file.getStatus())) {
				logger.warn("当前状态不允许上传文件片段{}", file.toString());
				throw new HAERuntimeException(ImageResultCode.ILLEGAL_UPLOAD_STATUS_ERROR);
			}
			if (UploadStatus.UPLOAD_BREAK == file.getStatus()) {
				if (uploadInfo.getTrunk() == file.getCurrentTrunk() && uploadInfo.getTrunks() == file.getTotalChunks()) {
					logger.info("恢复文件{}断点上传", file.getFileName());
					// TODO 检查原有片段是否完整
					statusService.updateToUploading(uploadInfo.getId());
					publishActionLog(ImageActionType.BREAKPOINT_UPLOAD, file.getFileName(), "继续断点上传镜像文件");
				} else {
					logger.error("恢复断点上传信息不正确，上传记录信息：{}，当前请求信息：{}", file.toString(), uploadInfo.toString());
					throw new HAERuntimeException(ImageResultCode.ILLEGAL_UPLOADBREAK_ERROR);
				}
			}
		}
	}

	@Override
	public void upload(MultipartFile uploadFile, UploadFileVO uploadInfo) {
		UploadFile file = uploadBiz.getById(uploadInfo.getId(), false);
		// save upload part
		File saveParentPath = new File(file.getFilePath());
		if (!saveParentPath.exists()) {
			saveParentPath.mkdirs();
		}
		File currentFile = new File(saveParentPath, String.valueOf(uploadInfo.getTrunk()));
		try {
			uploadFile.transferTo(currentFile);
		} catch (IllegalStateException | IOException e) {
			throw new HAERuntimeException(ImageResultCode.SAVE_UPLOADFILE_TRUNK_ERROR, e);
		}
		// check MD5
		try (FileInputStream md5Stream = new FileInputStream(currentFile)) {
			String currentPartMD5 = DigestUtils.md5Hex(md5Stream);
			if (!uploadInfo.getMd5Checksum().equalsIgnoreCase(currentPartMD5)) {
				logger.info("当前上传块MD5：{}，客户端MD5：{}", currentPartMD5, uploadInfo.getMd5Checksum());
				throw new HAERuntimeException(ImageResultCode.BAD_UPLOADFILE_CHECKSUM);
			}
		} catch (IOException e) {
			throw new HAERuntimeException(ImageResultCode.BAD_UPLOADFILE_CHECKSUM, e);
		}
		uploadBiz.updateCurrentTrunk(uploadInfo.getId(), uploadInfo.getTrunk());
	}

	@Override
	public void postUpload(MultipartFile uploadFile, UploadFileVO uploadInfo) {
		if (uploadInfo.getTrunk() == uploadInfo.getTrunks()) {
			UploadFile file = uploadBiz.getById(uploadInfo.getId(), false);
			logger.info("文件{}各段上传完毕", file);
			statusService.updateToWaitingMerge(uploadInfo.getId());
			UploadFileCompleteEvent event = new UploadFileCompleteEvent(file);
			uploadListener.process(event);
		}
	}

	@Override
	public void interruptUpload(String fileId) {
		UploadFile file = uploadBiz.getById(fileId, true);
		if (file == null) {
			throw new HAERuntimeException(ImageResultCode.UPLOADFILE_DONOT_EXIST);
		}
		if (UploadStatus.UPLOADING != file.getStatus()) {
			throw new HAERuntimeException(ImageResultCode.INTERRUPT_UPLOADING_FILE_ONLY);
		}
		statusService.updateToUploadBreak(fileId);
	}

}
