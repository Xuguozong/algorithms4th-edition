package com.hikvision.hae.image.listener;

import com.hikvision.hae.file.model.UploadFile;

public class UploadFileCompleteEvent extends UploadEvent {

	public UploadFileCompleteEvent(UploadFile upload) {
		super(upload);
	}
	
	public String getUploadFileId() {
		return upload.getFileId();
	}
	
	public String getUploadPath() {
		return upload.getFilePath();
	}
	
	public String getUploadFileName() {
		return upload.getFileName();
	}
	
	public int totalTrunks() {
		return upload.getTotalChunks();
	}

}
