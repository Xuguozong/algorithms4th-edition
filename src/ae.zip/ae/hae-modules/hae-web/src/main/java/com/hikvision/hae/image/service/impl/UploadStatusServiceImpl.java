package com.hikvision.hae.image.service.impl;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.listener.StatusEvent;
import com.hikvision.hae.image.listener.StatusListener;
import com.hikvision.hae.image.service.UploadStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Service
public class UploadStatusServiceImpl implements UploadStatusService {
	
	private List<UploadStatus> finalStatus;
	
	@Autowired
	private UploadFileBiz uploadFileBiz;

	@Autowired(required = false)
	private List<StatusListener> listeners;
	
	@PostConstruct
	public void init() {
		finalStatus = new ArrayList<>();
		finalStatus.add(UploadStatus.MERGE_ERROR);
		finalStatus.add(UploadStatus.PUSH_ERROR);
		finalStatus.add(UploadStatus.PUSHED);
	}
	
	private void updateStatus(String fileId, UploadStatus status, String reason) {
		uploadFileBiz.updateStatus(fileId, status, reason);
		if (listeners == null) {
			throw new HAERuntimeException(CommonResultCode.IMAGE_MANAGE_NOT_SUPPORTED);
		}
		// fire status change event
		listeners.forEach(listener -> listener.process(new StatusEvent(fileId, status)));
		if(finalStatus.contains(status)) {
			uploadFileBiz.clean(fileId);
		}
	}

	@Override
	public void updateToUploading(String fileId) { updateStatus(fileId, UploadStatus.UPLOADING, null); }

	@Override
	public void updateToUploadBreak(String fileId) {
		updateStatus(fileId, UploadStatus.UPLOAD_BREAK, null);
	}

	@Override
	public void updateToWaitingPush(String fileId) {
		updateStatus(fileId, UploadStatus.WAITING_PUSH, null);
	}

	@Override
	public void updateToMergeError(String fileId, String reason) {
		updateStatus(fileId, UploadStatus.MERGE_ERROR, reason);
	}

	@Override
	public void updateToPushing(String fileId) {
		updateStatus(fileId, UploadStatus.PUSHING, null);
	}

	@Override
	public void updateToPushError(String fileId, String reason) {
		updateStatus(fileId, UploadStatus.PUSH_ERROR, reason);
	}

	@Override
	public void updateToPushed(String fileId) {
		updateStatus(fileId, UploadStatus.PUSHED, null);
	}

	@Override
	public void updateToMerging(String field) {
		updateStatus(field, UploadStatus.MERGING, null);
	}

	@Override
	public void updateToWaitingMerge(String field) {
		updateStatus(field, UploadStatus.WAITING_MERGE, null);
	}

}
