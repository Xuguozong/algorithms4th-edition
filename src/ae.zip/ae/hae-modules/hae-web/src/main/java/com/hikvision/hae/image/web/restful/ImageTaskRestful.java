package com.hikvision.hae.image.web.restful;

import com.hikvision.hae.common.constant.ImageResultCode;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.image.service.ImageTaskService;
import com.hikvision.hae.image.vo.ImageEntityVO;
import com.hikvision.hae.image.vo.ImageTaskVO;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 14:12 2018/3/16
 * @Description :  镜像任务：上传程序包，获取、创建、更新镜像任务
 */
@RestController
@RequestMapping("/api/task/v1")
public class ImageTaskRestful {

	private static final Logger LOGGER = LoggerFactory.getLogger(ImageTaskRestful.class);

	@Autowired
	private ImageTaskService imageTaskService;

	@ApiOperation(value = "上传程序包")
	@ApiImplicitParams({@ApiImplicitParam(name = "multipartFile", value = "程序包文件"),
			@ApiImplicitParam(name = "id", value = "镜像任务ID"),
			@ApiImplicitParam(name = "fileName", value = "程序包文件名称")})
	@PostMapping("/upload")
	public AjaxResult<ImageTaskVO> uploadProgramFile(MultipartFile file, Integer id, String fileName) {
		if (null == file) {
			return new AjaxResult<>(ImageResultCode.PROGRAM_UPLOAD_EMPTY);
		}
		AjaxResult ajaxResult = AjaxResult.buildSuccess();
		ImageTaskVO imageTaskVO = new ImageTaskVO();
		imageTaskVO.setId(imageTaskService.uploadProgram(file, id, fileName));
		ajaxResult.setData(imageTaskVO);
		return ajaxResult;
	}

	@ApiOperation(value = "提交镜像任务")
	@PostMapping("/submit/{id}")
	public AjaxResult<Void> submitTask(@PathVariable Integer id, @RequestBody ImageEntityVO imageEntityVO) {
		imageTaskService.submitTask(id, imageEntityVO);
		return AjaxResult.buildSuccess();
	}

	@ApiOperation(value = "浏览镜像任务")
	@PostMapping("/scan")
	public AjaxResult<ImageTaskVO> scanTask(@RequestBody ImageEntityVO imageEntityVO) {
		ImageTaskVO imageTaskVO = imageTaskService.scanTask(imageEntityVO);
		AjaxResult ajaxResult = AjaxResult.buildSuccess();
		ajaxResult.setData(imageTaskVO);
		return ajaxResult;
	}

	@ApiOperation(value = "获取镜像任务列表")
	@GetMapping("/tasks")
	public AjaxResult<List<ImageTaskVO>> getAllTask() {
		List<ImageTaskVO> imageTaskVOS = imageTaskService.getAllTask();
		AjaxResult ajaxResult = AjaxResult.buildSuccess();
		ajaxResult.setData(imageTaskVOS);
		return ajaxResult;
	}

	@DeleteMapping("/tasks")
	public AjaxResult<Void> clearTask(@RequestBody int[] ids) {
		if (ids != null && ids.length > 0) {
			for (int id : ids) {
				imageTaskService.clearTask(id);
			}
		}
		return AjaxResult.buildSuccess();
	}
}
