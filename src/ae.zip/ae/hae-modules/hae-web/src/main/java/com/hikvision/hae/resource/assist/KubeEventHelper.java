package com.hikvision.hae.resource.assist;

import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.KubeResourceActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.util.eventcenter.event.UserOperationEvent;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

/**
 * @author jianghaiyang5 on 2017/11/28.
 */
@Component
public class KubeEventHelper {

    @Resource
    private EventPublisher eventPublisher;

    public void publishAddEvent(String source, PrincipalCategory category, String namespace, String name, String remark) {
        publishEvent(source, category, namespace, name, KubeResourceActionType.ADD, remark);
    }

    public void publishUpdateEvent(String source, PrincipalCategory category, String namespace, String name, String remark) {
        publishEvent(source, category, namespace, name, KubeResourceActionType.UPDATE, remark);
    }

    public void publishScaleEvent(String source, PrincipalCategory category, String namespace, String name, String remark) {
        publishEvent(source, category, namespace, name, KubeResourceActionType.SCALE, remark);
    }

    public void publishDeleteEvent(String source, PrincipalCategory category, String namespace, String name, String remark) {
        publishEvent(source, category, namespace, name, KubeResourceActionType.DELETE, remark);
    }

    private void publishEvent(String source, PrincipalCategory category, String namespace, String name, KubeResourceActionType actionType, String remark) {
        if (StringUtils.hasText(namespace)) {
            name = namespace + "/" + name;
        }
        UserOperationEvent event = UserOperationEvent.builder().source(source)
                .principalCategory(category).actionType(actionType)
                .principalName(name).principalIndexCode("")
                .actorIp(LoginUtils.getLoginUser().getClientIP())
                .actorId(LoginUtils.getLoginUser().getId())
                .remark(remark).build();
        eventPublisher.publish(event);
    }

}
