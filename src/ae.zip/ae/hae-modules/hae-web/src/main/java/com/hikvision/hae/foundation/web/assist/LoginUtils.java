package com.hikvision.hae.foundation.web.assist;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.util.encrypt.JWTUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Base64;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
@Component
public class LoginUtils {

	private static final String GATEWAY_AUTHORIZATION_HEADER_KEY = "Authorization";

	private static final String GATEWAY_AUTHORIZATION_HEADER_VALUE_PREFIX = "Bearer";

	private static final String API_AUTHORIZATION_HEADER_KEY = "Token";

	private static final Logger logger = LoggerFactory.getLogger(LoginUtils.class);

	private static LoginUtils loginUtil;

	@Value("${deploy.mode:single}")
	private String deployMode;

	@PostConstruct
	public void init() {
		loginUtil = this;
		loginUtil.deployMode = this.deployMode;
	}

	public static LoginUser getLoginUser() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		return getLoginUser(request);
	}

	public static String getClientIP(HttpServletRequest request) {
		String xForwardedFor = request.getHeader("X-Forwarded-For");
		return StringUtils.isBlank(xForwardedFor) ? request.getRemoteAddr() : xForwardedFor;
	}

	public static LoginUser getLoginUser(HttpServletRequest request) {
		LoginUser loginUser = null;
		if (apiAuth(request)) {
			// 优先判断是否为接口认证
			loginUser = buildDefaultUser();
		} else {
			// 判断是否为登录认证
			if (CommonConstants.SINGLE_DEPLOY_MODE.equals(loginUtil.deployMode)) {
				// 通过自带登录页面登录
				HttpSession session = request.getSession();
				if (session != null) {
					loginUser = (LoginUser) session.getAttribute(CommonConstants.LOGIN_USER);
				}
			} else if (gatewayAuth(request)) {
				// 通过网关登录
				loginUser = buildDefaultUser();
			}
		}
		if (loginUser != null) {
			loginUser.setClientIP(getClientIP(request));
		}
		return loginUser;
	}

	private static boolean gatewayAuth(HttpServletRequest request) {
		String authContent = request.getHeader(GATEWAY_AUTHORIZATION_HEADER_KEY);
		return StringUtils.isNotBlank(authContent) && authContent.startsWith(GATEWAY_AUTHORIZATION_HEADER_VALUE_PREFIX) && validateGatewayAuthContent(authContent);
	}

	private static boolean validateGatewayAuthContent(String authContent) {
		try {
			String jwt = authContent.substring(GATEWAY_AUTHORIZATION_HEADER_VALUE_PREFIX.length());
			String[] jwtSplit = jwt.split("\\.");
			String payload = jwtSplit[1];
			JSONObject payloadObject = JSONObject.parseObject(new String(Base64.getDecoder().decode(payload), "UTF-8"));
			String sub = payloadObject.getString("sub");
			return "admin".equals(sub);
		} catch (Exception e) {
			logger.error("Validate gateway auth content failed", e);
			return false;
		}
	}

	private static boolean apiAuth(HttpServletRequest request) {
		String authContent = request.getHeader(API_AUTHORIZATION_HEADER_KEY);
		return StringUtils.isNotBlank(authContent) && JWTUtil.verifyJWT(CommonConstants.JWT_SEC, authContent);
	}

	private static LoginUser buildDefaultUser() {
		// FIXME 后续根据用户体系修改，先写死
		LoginUser loginUser = new LoginUser();
		loginUser.setUsername("admin");
		loginUser.setId("788a8ac28753407682ef93444f3cdf87");
		return loginUser;
	}

}
