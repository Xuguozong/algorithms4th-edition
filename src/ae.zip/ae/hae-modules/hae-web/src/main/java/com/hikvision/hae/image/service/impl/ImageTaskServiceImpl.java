package com.hikvision.hae.image.service.impl;

import com.google.common.base.Strings;
import com.hikvision.hae.common.constant.ImageResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.file.biz.UploadConfigBiz;
import com.hikvision.hae.image.constant.ImageTaskConstant;
import com.hikvision.hae.image.listener.ImageTaskEvent;
import com.hikvision.hae.image.listener.ImageTaskListener;
import com.hikvision.hae.image.service.ImageTaskService;
import com.hikvision.hae.image.vo.ImageEntityVO;
import com.hikvision.hae.image.vo.ImageTaskVO;
import com.hikvision.hae.img.biz.ImageTaskBiz;
import com.hikvision.hae.img.dto.ImageTaskDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Validator;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.StringJoiner;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 14:18 2018/3/16
 * @Description :  镜像任务  实现类
 */
@Service
public class ImageTaskServiceImpl implements ImageTaskService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ImageTaskServiceImpl.class);
	private AtomicLong dirIndex = new AtomicLong(Integer.valueOf(0));

	@Autowired
	private UploadConfigBiz uploadConfigBiz;

	@Autowired
	private ImageTaskBiz imageTaskBiz;

	@Autowired
	private ImageTaskListener imageTaskListener;

	@Autowired
	private Validator validator;

	public Integer uploadProgram(MultipartFile file, Integer id, String fileName) {
		//1.生成文件目录
		String configPath;
		if (null != id) {
			ImageTaskDTO imageTaskDTO = imageTaskBiz.getImageTaskByID(id);
			configPath = imageTaskDTO.getProgramPath();
		} else {
			configPath = uploadConfigBiz.uploadLocation() + ImageTaskConstant.TASK_ROOT_PATH +
					ImageTaskConstant.PROGRAM + dirIndex.incrementAndGet();
			File parentDir = new File(configPath);
			if (!parentDir.exists()) {
				parentDir.mkdirs();
			}
		}

		//2.产生文件对象
		File curretFile = new File(configPath, fileName);
		try {
			//3.传输文件
			file.transferTo(curretFile);
		} catch (IOException e) {
			LOGGER.info("{}文件上传到{}失败", fileName, configPath);
			throw new HAERuntimeException(ImageResultCode.PROGRAM_UPLOAD_FAILED, e);
		}
		//4.可以校验一下MD5  暂不处理  预留

		//5.创建或者更新数据任务
		if (null == id) {
			return imageTaskBiz.create(fileName, configPath);
		}
		imageTaskBiz.updateProgramName(id, fileName);
		return id;
	}

	@Override
	public void submitTask(Integer id, ImageEntityVO imageEntityVO) {
		//1.校验参数的合法性
		checkTaskParam(imageEntityVO);
		ImageTaskDTO dto = imageTaskBiz.getImageTaskByID(id);
		if (null == dto || !dto.getProgramName().equals(imageEntityVO.getProgramName())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_NOT_EXSIT);
		}

		//2.构造dockerfile文件内容
		String content = buildDockerFileContent(imageEntityVO);

		//3.更新镜像任务content内容
		imageTaskBiz.updateTask(id, content, imageEntityVO.getTaskName(), imageEntityVO.getRepository(), imageEntityVO.getTag());

		//4.制作镜像
		ImageTaskEvent event = new ImageTaskEvent();
		event.setImageTaskDTO(dto);
		imageTaskListener.process(event);
	}

	@Override
	public ImageTaskVO scanTask(ImageEntityVO imageEntityVO) {
		checkTaskParam(imageEntityVO);
		String content = buildDockerFileContent(imageEntityVO);
		ImageTaskVO taskVo = new ImageTaskVO();
		taskVo.setId(null);
		taskVo.setStatus(null);
		taskVo.setTag(imageEntityVO.getTag());
		taskVo.setRepository(imageEntityVO.getRepository());
		taskVo.setTaskName(imageEntityVO.getTaskName());
		taskVo.setProgramName(imageEntityVO.getProgramName());
		taskVo.setContent(content);
		return taskVo;
	}

	@Override
	public List<ImageTaskVO> getAllTask() {
		List<ImageTaskDTO> taskDTOS = imageTaskBiz.getAllTask();
		return ImageTaskVO.convertToList(taskDTOS);
	}

	@Override
	public void clearTask(int id) {
		ImageTaskDTO imageTaskDTO = imageTaskBiz.getImageTaskByID(id);
		if (imageTaskDTO != null) {
			imageTaskBiz.removeImageDIR(imageTaskDTO.getProgramPath());
			imageTaskBiz.deleteTaskById(id);
		}
	}

	/**
	 * 构建dockerfile文件内容
	 *
	 * @param imageEntityVO 镜像原始参数
	 * @return 返回构造文件的内容content
	 */
	private String buildDockerFileContent(ImageEntityVO imageEntityVO) {
		//1.生成from基础镜像命令
		String fromShell = ImageTaskConstant.Command.FROM + imageEntityVO.getBaseImage();

		//2.生成创建文件夹命令
		Pattern patternDIR = Pattern.compile(ImageTaskConstant.PARAM_PATTERN);
		Matcher matcherDIR = patternDIR.matcher(ImageTaskConstant.SHELL_DIR);
		String dirShell = ImageTaskConstant.Command.RUN + matcherDIR.replaceAll(imageEntityVO.getWorkDir());

		//3.拷贝程序包到工作目录下
		String copyShell = ImageTaskConstant.Command.COPY + imageEntityVO.getProgramName() +
				ImageTaskConstant.SPACE + imageEntityVO.getWorkDir();

		//4.修改程序包执行权限
		String chmodShell = ImageTaskConstant.Command.RUN + ImageTaskConstant.SHELL_CHMOD +
				imageEntityVO.getWorkDir() + ImageTaskConstant.SLASH + imageEntityVO.getProgramName();

		//5.生成挂载目录命令 volume
		String volumeShell = ImageTaskConstant.Command.VOLUME + "/tmp";

		//6.生成工作目录 workdir
		String workdirShell = ImageTaskConstant.Command.WORKDIR + imageEntityVO.getWorkDir();

		//7.生成程序执行命令 entryShell
		String entryShell = ImageTaskConstant.Command.ENTRYPOINT + imageEntityVO.getProgramSH();

		//8.拼接字符串  生成文件内容
		StringJoiner joiner = new StringJoiner(System.getProperty("line.separator"));
		joiner.add(fromShell).add(dirShell).add(copyShell).add(chmodShell).
				add(volumeShell).add(workdirShell).add(entryShell);

		return joiner.toString();
	}

	/**
	 * 校验上传的参数  暂时还没想到比较好的校验方式  后面需要完善
	 *
	 * @param imageEntityVO 构建docker镜像参数
	 */
	private void checkTaskParam(ImageEntityVO imageEntityVO) {

		if (Strings.isNullOrEmpty(imageEntityVO.getTaskName())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_NAME_EMPTY);
		}

		if (Strings.isNullOrEmpty(imageEntityVO.getBaseImage())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_BASEIMAGE_EMPTY);
		}

		if (Strings.isNullOrEmpty(imageEntityVO.getImageSH())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_IMAGESH_EMPTY);
		}

		if (Strings.isNullOrEmpty(imageEntityVO.getProgramSH())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_PROGRAMSH_EMPTY);
		}

		if (Strings.isNullOrEmpty(imageEntityVO.getRepository())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_REPOSITORY_EMPTY);
		}

		if (Strings.isNullOrEmpty(imageEntityVO.getTag())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_TAG_EMPTY);
		}

		if (Strings.isNullOrEmpty(imageEntityVO.getWorkDir())) {
			throw new HAERuntimeException(ImageResultCode.IMAGE_TASK_WORKDIR_EMPTY);
		}
	}
}
