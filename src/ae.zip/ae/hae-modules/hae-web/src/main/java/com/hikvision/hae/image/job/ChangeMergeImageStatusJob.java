package com.hikvision.hae.image.job;

import com.google.common.collect.Maps;
import com.hikvision.hae.common.util.CollectionUtils;
import com.hikvision.hae.common.util.eventcenter.event.Event;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.listener.StatusEvent;
import com.hikvision.hae.image.listener.StatusListener;
import com.hikvision.hae.image.service.UploadRecordService;
import com.hikvision.hae.image.service.UploadStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.List;
import java.util.Map;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 11:19 2018/2/9
 * @Description :  修改合并上传文件的中间状态
 */
@Configuration
@ConditionalOnProperty(prefix = "image", name = "enabled", havingValue = "true", matchIfMissing=true)
public class ChangeMergeImageStatusJob implements StatusListener {

    private static Logger logger = LoggerFactory.getLogger(ChangeMergeImageStatusJob.class);

    private Map uploadFileMergeEventMap = Maps.newConcurrentMap();

    @Autowired
    private UploadStatusService uploadStatusService;

    @Autowired
    private UploadRecordService uploadRecordService;

    @Override
    public void process(StatusEvent event) {
        if (event.getStatus() == UploadStatus.WAITING_MERGE || event.getStatus() == UploadStatus.MERGING){
            uploadFileMergeEventMap.putIfAbsent(event.getFileId(), event.getStatus());
        }
        if (event.getStatus() == UploadStatus.WAITING_PUSH || event.getStatus() == UploadStatus.MERGE_ERROR){
            uploadFileMergeEventMap.remove(event.getFileId());
        }
    }

    @Scheduled(fixedRateString ="${job.config.cleanMergeFileFailInterval:120000}")
    public void handleStatusWaitingMergeAndMerging(){
        List<UploadFile> uploadFiles = uploadRecordService.mergeFileMiddleStatusList();
        if (!CollectionUtils.isEmpty(uploadFiles)){
            uploadFiles.forEach(e->{
                if (!uploadFileMergeEventMap.containsKey(e.getFileId())){
                    logger.info("合并文件{}，服务器内部出错", e.getFileId());
                    uploadStatusService.updateToMergeError(e.getFileId(), "合并文件服务器内部出错");
                }
            });
        }
    }

}
