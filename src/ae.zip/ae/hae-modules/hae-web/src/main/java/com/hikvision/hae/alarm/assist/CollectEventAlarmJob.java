package com.hikvision.hae.alarm.assist;

import com.hikvision.hae.alarm.event.biz.EventAlarmBiz;
import com.hikvision.hae.resource.event.biz.EventBiz;
import io.fabric8.kubernetes.api.model.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 采集事件告警定时任务
 * Created by zhanjiejun on 2018/3/22.
 */
@Configuration
public class CollectEventAlarmJob {

	@Autowired
	private EventBiz eventBiz;

	@Autowired
	private EventAlarmBiz eventAlarmBiz;

	private static final Logger logger = LoggerFactory.getLogger(CollectEventAlarmJob.class);

	@Scheduled(fixedDelayString = "${event.alarm.collectPeriod:120000}")
	public void collectEventAlarm() {
		logger.debug("Start collect warning event...");
		List<Event> allEvents = eventBiz.findAll();
		// 只采集Kind为Pod、Type为Warning的事件作为告警
		List<Event> warningEvents = allEvents.stream()
										.filter(e -> "warning".equalsIgnoreCase(e.getType()) && "pod".equalsIgnoreCase(e.getInvolvedObject().getKind()))
									.collect(Collectors.toList());
		eventAlarmBiz.handleEvents(warningEvents);
		logger.debug("Collect warning event done.");
	}

}
