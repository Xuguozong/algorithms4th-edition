package com.hikvision.hae.foundation.assit;

import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Created by zhanjiejun on 2017/12/14.
 */
@Component
public class SysResourceIniter {

	@Autowired
	private SysResourceBiz sysResourceBiz;

	@Value("${image.enabled:true}")
	private boolean imageEnabled;

	@Value("${log.enabled:true}")
	private boolean logEnabled;

	@PostConstruct
	public void init() {
		sysResourceBiz.updateResourceDeletedFlag("IMAGE_MANAGE", !imageEnabled);
		sysResourceBiz.updateResourceDeletedFlag("LOG", !logEnabled);
	}

}
