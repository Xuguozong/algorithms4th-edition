package com.hikvision.hae.log.vo;

import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.log.dto.LogQueryDTO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 日志查询条件
 * <p>
 * Created by zhouziwei on 2017/11/9.
 */
public class LogQueryVO implements Serializable {

	private static final long serialVersionUID = -484632414849900797L;

	private Long startTime;

	private Long endTime;

	/**
	 * 简单式下支持时间+命名空间+POD名称+容器名称查询
	 */
	private String podName;

	private String containerName;

	private String namespace;

	/**
	 * 高级模式支持语句查询
	 * kubernetes.labels.k8s-app:filebeat AND kubernetes.pod.name:filebeat-bvs59 AND message:Beat
	 */
	private String queryStatement;

	public String getPodName() {
		return podName;
	}

	public void setPodName(String podName) {
		this.podName = podName;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public Long getStartTime() {
		return startTime;
	}

	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}

	public Long getEndTime() {
		return endTime;
	}

	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}

	public String getQueryStatement() {
		return queryStatement;
	}

	public void setQueryStatement(String queryStatement) {
		this.queryStatement = queryStatement;
	}

	public LogQueryDTO toQueryDTO() {
		LogQueryDTO logQueryDTO = new LogQueryDTO();
		if (this.startTime != null) {
			logQueryDTO.setDateRangeStart(UTCDateUtil.formatDateToUTCTime(new Date(this.startTime)));
		}
		if (this.endTime != null) {
			logQueryDTO.setDateRangeEnd(UTCDateUtil.formatDateToUTCTime(new Date(this.endTime)));
		}
		if (StringUtils.isNotEmpty(queryStatement)) {
			logQueryDTO.setFilters(queryStatement);
		} else {
			List<String> queryTerms = new ArrayList<>();
			if (StringUtils.isNotEmpty(this.namespace)) {
				queryTerms.add("kubernetes.namespace:" + this.namespace);
			}
			if (StringUtils.isNotEmpty(this.podName)) {
				queryTerms.add("kubernetes.pod.name:" + this.podName);
			}
			if (StringUtils.isNotEmpty(this.containerName)) {
				queryTerms.add("kubernetes.container.name:" + this.containerName);
			}
			if (!queryTerms.isEmpty()) {
				StringBuilder queryStatement = new StringBuilder(queryTerms.get(0));
				for (int i = 1; i < queryTerms.size(); i++) {
					queryStatement.append(" AND ").append(queryTerms.get(i));
				}
				logQueryDTO.setFilters(queryStatement.toString());
			}
		}
		return logQueryDTO;
	}

}
