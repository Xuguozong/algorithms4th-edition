package com.hikvision.hae.foundation.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.service.NavigationService;
import com.hikvision.hae.foundation.service.impl.assist.navi.LeftFirstLayerMenuBuilder;
import com.hikvision.hae.foundation.service.impl.assist.navi.LeftSecondLayerMenuBuilder;
import com.hikvision.hae.foundation.service.impl.assist.navi.MenuResourceQuery;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import com.hikvision.hae.foundation.vo.SimpleMenuResourceVO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 页面导航数据相关的视图业务
 * <p>
 * Created by zhouziwei on 2017/11/8.
 */
@Service
public class NavigationServiceImpl implements NavigationService {
	private static final Logger logger = LoggerFactory.getLogger(NavigationServiceImpl.class);

	@Resource
	private SysResourceBiz sysResourceBiz;

	@Resource
	private LeftFirstLayerMenuBuilder leftFirstLayerMenuBuilder;

	@Resource
	private LeftSecondLayerMenuBuilder leftSecondLayerMenuBuilder;

	@Override
	public List<MenuResourceVO> getMainMenu(MenuResourceQuery menuResourceQuery) {
		MenuResourceVO leftMenu;
		if (StringUtils.isBlank(menuResourceQuery.getNamespace())) {
			// 1.1 左侧 首层菜单
			leftMenu = leftFirstLayerMenuBuilder.build(menuResourceQuery.getUserId());
		} else {
			// 1.2 左侧 二层菜单
			leftMenu = leftSecondLayerMenuBuilder.build(menuResourceQuery.getUserId(), menuResourceQuery.getNamespace(), menuResourceQuery.getMode());
		}
		// 打印调试日志
		DelayedLogger.debug(logger, () -> JSONObject.toJSONString(leftMenu));
		return leftMenu.getClist();
	}


	@Override
	public SimpleMenuResourceVO getSimpleMenuByCode(String sysResourceCode) {
		if (sysResourceCode == null) {
			return null;
		}
		SysResourceDTO menu = sysResourceBiz.getResourceByCode(sysResourceCode);
		return SimpleMenuResourceVO.readFromDTO(menu);
	}

}
