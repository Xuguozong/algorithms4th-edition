package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ReplicationControllerDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;

/**
 * @author jianghaiyang5 on 2017/11/13.
 */
public interface ReplicationControllerService {

    /**
     * 分页查询ReplicationController
     *
     * @param namespace 命名空间
     * @param name      ReplicationController名称
     * @param labels    标签字符串 形如：k1;k2:v2
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodControllerItemVO> findAndPage(String namespace, String name, String labels, PageParam pageParam);

    /**
     * 查看ReplicationController详情
     *
     * @param namespace 命名空间
     * @param name      ReplicationController名称
     * @return ReplicationController详情
     */
    ReplicationControllerDetailVO getDetail(String namespace, String name);

    /**
     * 伸缩Pod数量
     *
     * @param namespace   命名空间
     * @param name        ReplicationController名称
     * @param newReplicas 新Pod数量
     */
    void scale(String namespace, String name, int newReplicas);

    /**
     * 删除ReplicationController
     *
     * @param namespace 命名空间
     * @param name      ReplicationController名称
     */
    void delete(String namespace, String name);
}
