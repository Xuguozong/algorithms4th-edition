package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.hpa.biz.HPABiz;
import com.hikvision.hae.resource.service.HorizontalPodAutoscalerService;
import com.hikvision.hae.resource.vo.HPAItemVO;
import io.fabric8.kubernetes.api.model.HorizontalPodAutoscaler;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/27.
 */
@Service
public class HorizontalPodAutoscalerServiceImpl implements HorizontalPodAutoscalerService {

    @Resource
    private HPABiz hpaBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public List<HPAItemVO> find(String namespace, String ownerKind, String ownerName) {
        ResourceKind kind = ResourceKind.parse(ownerKind);
        List<HorizontalPodAutoscaler> hpaList = hpaBiz.find(namespace, kind, ownerName);
        return hpaList.stream().map(ResourceVOBuilder::buildHPAItemVO).collect(Collectors.toList());
    }

    @Override
    public void delete(String namespace, String name) {
        hpaBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.HORIZONTAL_POD_AUTOSCALER,
                PrincipalCategory.HORIZONTAL_POD_AUTOSCALER, namespace, name, "删除容器组水平伸缩器（HPA）");
    }
}
