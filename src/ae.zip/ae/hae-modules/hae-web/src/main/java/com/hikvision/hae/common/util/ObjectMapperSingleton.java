package com.hikvision.hae.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;

/**
 * ObjectMapper单例
 */
public class ObjectMapperSingleton {

    private static final ObjectMapper JSON_INSTANCE = new ObjectMapper();

    private static final YAMLMapper YAML_INSTANCE = new YAMLMapper();

    public static ObjectMapper getJSONMapperInstance() {
        return JSON_INSTANCE;
    }

    public static YAMLMapper getYAMLInstance() {
        return YAML_INSTANCE;
    }

}
