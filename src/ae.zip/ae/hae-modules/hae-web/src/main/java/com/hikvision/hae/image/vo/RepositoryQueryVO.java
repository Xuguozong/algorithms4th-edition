package com.hikvision.hae.image.vo;

import com.hikvision.hae.common.vo.PageParam;

public class RepositoryQueryVO {

	private PageParam pageParam;
	
	private int projectId;

	public PageParam getPageParam() {
		return pageParam;
	}

	public void setPageParam(PageParam pageParam) {
		this.pageParam = pageParam;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
}
