package com.hikvision.hae.common.vo;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 监控趋势图VO
 * Created by zhanjiejun on 2017/11/20.
 */
public class MetricsTrendVO {

	private String unit;

	private List<Trend> trend;

	public static class Trend {

		private String resourceId;

		/**
		 * key -> timestamp
		 * value -> value
		 */
		private Map<String, String> metrics;

		public String getResourceId() {
			return resourceId;
		}

		public void setResourceId(String resourceId) {
			this.resourceId = resourceId;
		}

		public Map<String, String> getMetrics() {
			return metrics;
		}

		public void setMetrics(Map<String, String> metrics) {
			this.metrics = metrics;
		}
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public List<Trend> getTrend() {
		return trend;
	}

	public void setTrend(List<Trend> trend) {
		this.trend = trend;
	}
}
