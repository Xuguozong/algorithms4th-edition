package com.hikvision.hae.image.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.common.util.eventcenter.enums.ImageActionType;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.image.service.ImageRepositoryService;
import com.hikvision.hae.image.service.ImageService;
import com.hikvision.hae.image.vo.RepositoryConfigVO;
import com.hikvision.hae.image.vo.RepositoryQueryVO;
import com.hikvision.hae.img.biz.ImageDownloadBiz;
import com.hikvision.hae.img.biz.ImageRepositoryBiz;
import com.hikvision.hae.img.biz.ImageRepositoryConfigBiz;
import com.hikvision.hae.img.dto.DownloadImageDTO;
import com.hikvision.hae.common.constant.ImageResultCode;
import com.hikvision.hae.img.entity.ImageProjectEntity;
import com.hikvision.hae.img.entity.ImageRepositoryEntity;
import com.hikvision.hae.img.entity.ImageRepositoryTagEntity;
import com.spotify.docker.client.exceptions.DockerException;

/**
 * 镜像仓库项目、仓库数据展示
 * 后端接口是支持分页的，但是没有总数量，为了前端表格组件统一样式，列表数据采取假分页形式
 * @author qiuzhihao
 */
@Service
public class ImageServiceImpl extends BaseImageService implements ImageRepositoryService, ImageService {

	@Resource
	private ImageRepositoryBiz repoBiz;
	
	@Resource
	private ImageDownloadBiz downloadBiz;
	
	@Resource
	private ImageRepositoryConfigBiz configService;

	@Override
	public Pagination<ImageProjectEntity> project(PageParam pageInfo) {
		List<ImageProjectEntity> allProject = repoBiz.projectList();
		if (pageInfo == null) {
			return Pagination.build(allProject);
		}
		return DataSelector.paginate(allProject, null, pageInfo);
	}

	@Override
	public void createProject(String projectName) {
		repoBiz.createProject(projectName);
	}

	@Override
	public boolean isProjectExist(String projectName) {
		return repoBiz.isProjectExist(projectName);
	}

	@Override
	public void deleteProject(long projectId) {
		if(repoBiz.getProject(projectId) != null) {
			repoBiz.deleteProject(projectId);
		} else {
			throw new HAERuntimeException(ImageResultCode.PROJECT_NOT_EXIST);
		}
	}

	@Override
	public Pagination<ImageRepositoryEntity> repository(RepositoryQueryVO query) {
		List<ImageRepositoryEntity> allRepos = repoBiz.repositoryList(query.getProjectId());
		if (null == query.getPageParam()) {
			return Pagination.build(allRepos);
		}
		return DataSelector.paginate(allRepos, null, query.getPageParam());
	}

	@Override
	public List<ImageRepositoryTagEntity> repositoryTagList(String repoName) {
		return repoBiz.repositoryTagList(repoName);
	}

	@Override
	public InputStream downloadImage(String imageFullName) {
		DownloadImageDTO downloadDTO = new DownloadImageDTO(configService.accessInfo(), imageFullName);
		try {
			publishActionLog(ImageActionType.DOWNLOAD, imageFullName, "下载镜像");
			return downloadBiz.downloadImage(downloadDTO);
		} catch (DockerException | InterruptedException | IOException e) {
			throw new HAERuntimeException(ImageResultCode.DOWNLOAD_IMAGE_ERROR, e);
		}
	}

	@Override
	public void deleteRepository(String repoName) {
		repoBiz.deleteRepository(repoName);
	}

	@Override
	public void deleteRepositoryTag(String repoName, String tag) {
		publishActionLog(ImageActionType.DELETE, repoName + ":" + tag, "删除镜像");
		repoBiz.deleteRepositoryTag(repoName, tag);
	}

	@Override
	public RepositoryConfigVO getImageRepositoryConfigData() {
		RepositoryConfigVO config = new RepositoryConfigVO();
		config.setBaseHost(configService.accessInfo().getHarborAccessInfo());
		return config;
	}
}
