package com.hikvision.hae.image.listener;

import com.hikvision.hae.file.model.UploadStatus;

public class StatusEvent {

	private String fileId;
	
	private UploadStatus status;
	
	public StatusEvent(String fileId, UploadStatus status) {
		this.fileId = fileId;
		this.status = status;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public UploadStatus getStatus() {
		return status;
	}

	public void setStatus(UploadStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "StatusEvent{" +
				"fileId='" + fileId + '\'' +
				", status=" + status +
				'}';
	}
}
