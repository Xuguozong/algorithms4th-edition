package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.daemonset.DaemonSetBiz;
import com.hikvision.hae.resource.replicaset.biz.ReplicaSetBiz;
import com.hikvision.hae.resource.replicationcontroller.biz.ReplicationControllerBiz;
import com.hikvision.hae.resource.service.ServiceResourceService;
import com.hikvision.hae.resource.service.biz.ServiceBiz;
import com.hikvision.hae.resource.service.dto.EndpointDTO;
import com.hikvision.hae.resource.vo.ServiceDetailVO;
import com.hikvision.hae.resource.vo.ServiceItemVO;
import io.fabric8.kubernetes.api.model.ReplicationController;
import io.fabric8.kubernetes.api.model.Service;
import io.fabric8.kubernetes.api.model.extensions.DaemonSet;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
@org.springframework.stereotype.Service
public class ServiceResourceServiceImpl implements ServiceResourceService {
	private static final Logger logger = LoggerFactory.getLogger(ServiceResourceServiceImpl.class);

	@Resource
	private DaemonSetBiz daemonSetBiz;

	@Resource
	private ReplicaSetBiz replicaSetBiz;

	@Resource
	private ReplicationControllerBiz replicationControllerBiz;

	@Resource
	private ServiceBiz serviceBiz;

	@Resource
	private KubeEventHelper kubeEventHelper;

	@Override
	public Pagination<ServiceItemVO> findAndPage(String namespace, String name, String ownerKind, String ownerName, PageParam pageParam) {
		FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
		Pagination<ServiceItemVO> result = new Pagination<>();
		Collection<Service> serviceList;
		if (pageParam != null) {
			Map<String, String> postResourceSelector = addOwnerAsQueryParam(namespace, ownerKind, ownerName);
			Pagination<Service> servicePage = serviceBiz.findAndPage(filterQuery, postResourceSelector, pageParam);
			result.copyIgnoreRows(servicePage);
			serviceList = servicePage.getRows();
		} else {
			serviceList = serviceBiz.find(filterQuery);
		}
		if (!CollectionUtils.isEmpty(serviceList)) {
			Function<Collection<Service>, Collection<ServiceItemVO>> rowsConverter =
					(Collection<Service> dtoList) -> dtoList.stream()
							.map(svc -> ResourceVOBuilder.buildServiceItemVO(svc, serviceBiz::getInternalEndpoint, serviceBiz::getExternalEndpoint))
							.collect(Collectors.toList());
			result.setRows(rowsConverter.apply(serviceList));
		}
		return result;
	}

	@Override
	public ServiceDetailVO getDetail(String namespace, String name) {
		//Service基础属性
		Service service = serviceBiz.getByName(namespace, name);
		if (service == null) {
			DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Service[" + name + "]");
			throw new HAERuntimeException(ResourceResultCode.SERVICE_NOT_EXIST);
		}
		ServiceDetailVO vo = new ServiceDetailVO();
		vo.setNamespace(service.getMetadata().getNamespace());
		vo.setName(service.getMetadata().getName());
		vo.setLabels(service.getMetadata().getLabels());
		vo.setAnnotations(service.getMetadata().getAnnotations());
		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(service.getMetadata().getCreationTimestamp().getTime()));
		vo.setSelectors(service.getSpec().getSelector());
		vo.setType(service.getSpec().getType());
		vo.setClusterIP(service.getSpec().getClusterIP());
		vo.setInternalEndpoint(ResourceVOBuilder.buildEndpointVO(serviceBiz.getInternalEndpoint(service)));
		List<EndpointDTO> externals = serviceBiz.getExternalEndpoint(service);
		if (!CollectionUtils.isEmpty(externals)) {
			vo.setExternalEndpoints(externals.stream().map(ResourceVOBuilder::buildEndpointVO).collect(Collectors.toList()));
		}
		return vo;
	}

	@Override
	public void delete(String namespace, String name) {
		serviceBiz.delete(namespace, name);
		kubeEventHelper.publishDeleteEvent(ActionLogModules.SERVICE, PrincipalCategory.SERVICE, namespace, name, "删除服务（Service）");
	}

	@Override
	public Service create(Service service) {
		Service createService;
		try {
			createService = serviceBiz.create(service);
		} catch (Exception e) {
			logger.error("Create service" + service.getMetadata().getNamespace() + "@" + service.getMetadata().getName() + " failed", e);
			throw new HAERuntimeException(ResourceResultCode.CREATE_SERVICE_FAIL);
		}
		return createService;
	}

	private Map<String, String> addOwnerAsQueryParam(String namespace, String ownerKindStr, String ownerName) {
		if (StringUtils.isEmpty(ownerKindStr)) {
			return null;
		}
		ResourceKind ownerKind = ResourceKind.parse(ownerKindStr);
		Map<String, String> postResourceSelector;
		switch (ownerKind) {
			case DaemonSet:
				DaemonSet daemonSet = daemonSetBiz.getByName(namespace, ownerName);
				postResourceSelector = daemonSet == null ? null : daemonSet.getSpec().getSelector().getMatchLabels();
				break;
			case ReplicaSet:
				ReplicaSet replicaSet = replicaSetBiz.getByName(namespace, ownerName);
				postResourceSelector = replicaSet == null ? null : replicaSet.getSpec().getSelector().getMatchLabels();
				break;
			case ReplicationController:
				ReplicationController rc = replicationControllerBiz.getByName(namespace, ownerName);
				postResourceSelector = rc == null ? null : rc.getSpec().getSelector();
				break;
			default:
				postResourceSelector = null;
		}
		if (postResourceSelector == null) {
			DelayedLogger.error(logger, () -> "无效的Service关联方. Kind: " + ownerKindStr + ", Name: " + ownerName);
			throw new HAERuntimeException(ResourceResultCode.INVALID_SERVICE_OWNER);
		}
		return postResourceSelector;
	}
}
