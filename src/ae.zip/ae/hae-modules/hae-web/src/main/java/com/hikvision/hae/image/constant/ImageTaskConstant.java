package com.hikvision.hae.image.constant;


/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 13:51 2018/3/19
 * @Description :  dockerfile命令相关的脚本常量
 */
public class ImageTaskConstant {

    /**
     * shell 创建文件夹命令
     */
    public static String SHELL_DIR = "mkdir {}";

    /**
     * shell 程序执行命令
     */
    public static String SHELL_CHMOD = "chmod 777 ";

    /**
     * 变量表达式
     */
    public static String PARAM_PATTERN = "\\{\\}";

    /**
     * 冒号变量
     */
    public static String COLON = ":";

    /**
     * 正斜杠
     */
    public static String SLASH = "/";

    /**
     * 空格字符常量
     */
    public static String SPACE = " ";

    /**
     * 镜像任务存储先关文件的根路径
     */
    public static String TASK_ROOT_PATH = "/image_task/";

    /**
     * 程序文件和dockerfile存放的目录
     */
    public static String PROGRAM = "program";

    /**
     * dockerfile文件名
     */
    public static String DOCKER_FILE = "Dockerfile";

    /**
     * 通过dockerfile方式  包含的所有指令
     */
    public static class Command{
        public static final String FROM = "FROM ";
        public static final String MAINTAINER = "MAINTAINER ";
        public static final String RUN = "RUN ";
        public static final String CMD = "CMD ";
        public static final String EXPOSE = "EXPOSE ";
        public static final String ENV = "ENV ";
        public static final String ADD = "ADD ";
        public static final String COPY = "COPY ";
        public static final String ENTRYPOINT = "ENTRYPOINT ";
        public static final String VOLUME = "VOLUME ";
        public static final String USER = "USER ";
        public static final String WORKDIR = "WORKDIR ";
        public static final String ONBUILD = "ONBUILD ";
    }
}
