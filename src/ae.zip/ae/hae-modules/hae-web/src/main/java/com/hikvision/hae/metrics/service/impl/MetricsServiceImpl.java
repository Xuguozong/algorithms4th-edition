package com.hikvision.hae.metrics.service.impl;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.vo.MetricsQueryVO;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.assist.MetricsVOBuilder;
import com.hikvision.hae.metrics.biz.MetricsBiz;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import com.hikvision.hae.metrics.dto.MetricsQueryDTO;
import com.hikvision.hae.metrics.service.MetricsService;
import com.hikvision.hae.resource.node.biz.NodeBiz;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import io.fabric8.kubernetes.api.model.Quantity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
@Service
public class MetricsServiceImpl implements MetricsService {

	@Autowired
	private MetricsBiz metricsBiz;

	@Autowired
	private NodeBiz nodeBiz;

	@Override
	public MetricsTrendVO getNodeMetricsTrend(int nodeId, MetricsQueryVO metricsQuery) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoById(nodeId);
		switch (metricsQuery.getMetricsType()) {
			case NETWORK_RATE:
				metricsQuery.setMetricsType(MetricsType.NETWORK_RX_RATE);
				MetricsQueryDTO metricsQueryDTO = convertQueryVO2DTO(metricsQuery);
				MetricsDTO networkRXRate = metricsBiz.metricsNode(nodeBaseDTO.getK8sName(), metricsQueryDTO);
				metricsQueryDTO.setMetricsType(MetricsType.NETWORK_TX_RATE);
				MetricsDTO networkTXRate = metricsBiz.metricsNode(nodeBaseDTO.getK8sName(), metricsQueryDTO);
				return MetricsVOBuilder.buildMetricsTrendVO(String.valueOf(nodeId), MetricsType.NETWORK_RATE, networkRXRate, networkTXRate);
			default:
				MetricsDTO metricsDTO = metricsBiz.metricsNode(nodeBaseDTO.getK8sName(), convertQueryVO2DTO(metricsQuery));
				return MetricsVOBuilder.buildMetricsTrendVO(String.valueOf(nodeId), metricsQuery.getMetricsType(), metricsDTO);
		}
	}

	@Override
	public Map<String, String> getNodeGpuUsage(int nodeId) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeBaseDetail(nodeId);
		int gpuCount = 0;
		if (nodeBaseDTO.getCapacity() != null) {
			Quantity gpuCapacity = nodeBaseDTO.getCapacity().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S);
			if (gpuCapacity != null) {
				gpuCount = Integer.valueOf(gpuCapacity.getAmount());
			}
		}
		Map<String, String> gpuUsages = new HashMap<>();
		if (gpuCount <= 0) {
			return gpuUsages;
		}
		MetricsQueryVO metricsQuery = new MetricsQueryVO();
		metricsQuery.setMetricsType(MetricsType.GPU_USAGE);
		MetricsQueryDTO metricsQueryDTO = convertQueryVO2DTO(metricsQuery);
		for (int i = 0; i < gpuCount; i++) {
			String gpuIndex = String.valueOf(i);
			MetricsDTO metricsDTO = metricsBiz.metricsNodeGpu(nodeBaseDTO.getK8sName(), gpuIndex, metricsQueryDTO);
			if (metricsDTO != null && !CollectionUtils.isEmpty(metricsDTO.getMetrics())) {
				int size = metricsDTO.getMetrics().size();
				// 取最后一次监控的数据作为当前时间的实时使用率
				gpuUsages.put(gpuIndex, String.valueOf(metricsDTO.getMetrics().get(size - 1).getValue()));
			} else {
				gpuUsages.put(gpuIndex, "NA");
			}
		}
		return gpuUsages;
	}

	@Override
	public MetricsTrendVO getNodeGpuMetricsTrend(int nodeId, String gpuIndex, MetricsQueryVO metricsQuery) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoById(nodeId);
		MetricsDTO metricsDTO = metricsBiz.metricsNodeGpu(nodeBaseDTO.getK8sName(), gpuIndex, convertQueryVO2DTO(metricsQuery));
		return MetricsVOBuilder.buildMetricsTrendVO(gpuIndex, metricsQuery.getMetricsType(), metricsDTO);
	}

	@Override
	public GpuBaseInfo getNodeGpuBaseInfo(int nodeId, String gpuIndex) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoById(nodeId);
		return metricsBiz.getNodeGpuBaseInfo(nodeBaseDTO.getK8sName(), gpuIndex);
	}

	@Override
	public MetricsTrendVO getNamespaceMetricsTrend(String namespace, MetricsQueryVO metricsQuery) {
		MetricsDTO metricsDTO = metricsBiz.metricsNamespace(namespace, convertQueryVO2DTO(metricsQuery));
		return MetricsVOBuilder.buildMetricsTrendVO(namespace, metricsQuery.getMetricsType(), metricsDTO);
	}

	@Override
	public MetricsTrendVO getPodMetricsTrend(String namespace, String podName, MetricsQueryVO metricsQuery) {
		MetricsDTO metricsDTO = metricsBiz.metricsPod(namespace, podName, convertQueryVO2DTO(metricsQuery));
		return MetricsVOBuilder.buildMetricsTrendVO(podName, metricsQuery.getMetricsType(), metricsDTO);
	}

	private MetricsQueryDTO convertQueryVO2DTO(MetricsQueryVO metricsQuery) {
		Date start = metricsQuery.getStart() == null ? null : new Date(metricsQuery.getStart());
		Date end = metricsQuery.getEnd() == null ? null : new Date(metricsQuery.getEnd());
		if (start == null || end == null) {
			// 不传查询时间则默认查询15分钟的数据
			Calendar calendar = Calendar.getInstance();
			end = calendar.getTime();
			calendar.add(Calendar.MINUTE, -15);
			start = calendar.getTime();
		}
		return new MetricsQueryDTO(metricsQuery.getMetricsType(), start, end);
	}

}
