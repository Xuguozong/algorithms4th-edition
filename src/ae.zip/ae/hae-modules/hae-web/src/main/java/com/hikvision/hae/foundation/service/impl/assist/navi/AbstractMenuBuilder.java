package com.hikvision.hae.foundation.service.impl.assist.navi;

import com.hikvision.hae.common.util.CollectionUtils;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * Created by zhouziwei on 2017/11/8.
 */
public class AbstractMenuBuilder {

	/**
	 * 替换掉URL中命名空间占位符
	 *
	 * @param menu      菜单资源
	 * @param namespace 命名空间
	 */
	public void replacePathVariable(MenuResourceVO menu, String namespace) {
		String url = menu.getUrl();
		if (StringUtils.isNotBlank(url)) {
			url = url.replace("{namespace}", namespace);
		}
		menu.setUrl(url);
		List<MenuResourceVO> children = menu.getClist();
		if (CollectionUtils.isEmpty(children)) {
			return;
		}
		children.stream().forEach(m -> replacePathVariable(m, namespace));
	}

}
