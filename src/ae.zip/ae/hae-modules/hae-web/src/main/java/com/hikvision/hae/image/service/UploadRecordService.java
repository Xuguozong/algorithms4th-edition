package com.hikvision.hae.image.service;

import java.util.List;

import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.image.vo.UploadFileItemVO;

public interface UploadRecordService {

	List<UploadFileItemVO> getUploadRecordList();
	
	void deleteUploadRecord(String fileId);
	
	List<UploadFile> uploadFileMiddleStatusList();
	
	List<UploadFile> pushImageMiddleStatusList();

	List<UploadFile> mergeFileMiddleStatusList();
}
