package com.hikvision.hae.image.listener;

import com.hikvision.hae.img.dto.ImageTaskDTO;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 11:12 2018/3/20
 * @Description :  镜像任务事件
 */
public class ImageTaskEvent {

    private ImageTaskDTO imageTaskDTO;

    public ImageTaskDTO getImageTaskDTO() {
        return imageTaskDTO;
    }

    public void setImageTaskDTO(ImageTaskDTO imageTaskDTO) {
        this.imageTaskDTO = imageTaskDTO;
    }
}
