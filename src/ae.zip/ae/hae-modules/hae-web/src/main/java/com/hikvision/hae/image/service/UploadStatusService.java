package com.hikvision.hae.image.service;

public interface UploadStatusService {
	
	void updateToUploading(String fileId);
	
	void updateToUploadBreak(String fileId);
	
	void updateToWaitingPush(String fileId);
	
	void updateToMergeError(String fileId, String reason);
	
	void updateToPushing(String fileId);
	
	void updateToPushError(String fileId, String reason);
	
	void updateToPushed(String fileId);

	void updateToMerging(String field);

	void updateToWaitingMerge(String field);
}
