package com.hikvision.hae.log.web.restful;

import com.hikvision.hae.log.service.LogService;
import com.hikvision.hae.log.vo.LogQueryVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
@Controller
@RequestMapping("/log")
public class LogDownloadRestful {

	private static final Logger logger = LoggerFactory.getLogger(LogDownloadRestful.class);

	@Autowired
	private LogService logService;

	@GetMapping("/download")
	public void downloadLogs(LogQueryVO logQuery, HttpServletResponse response) {
		List<String> logs = logService.downloadLogs(logQuery);
		response.setCharacterEncoding("utf-8");
		response.setContentType("charset=utf-8; text/plain");
		String fileName = System.currentTimeMillis() + ".log";
		response.setHeader("Content-Disposition", "attachment;fileName=" + fileName);
		try (BufferedWriter osw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream()))) {
			for (String log : logs) {
				osw.write(log);
				osw.newLine();
			}
		} catch (IOException e) {
			logger.error("文件下载失败", e);
		}
	}

}
