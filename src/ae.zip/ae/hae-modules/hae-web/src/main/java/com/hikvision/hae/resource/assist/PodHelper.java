package com.hikvision.hae.resource.assist;

import com.alibaba.fastjson.JSON;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.common.dto.SerializedReference;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import io.fabric8.kubernetes.api.model.*;
import io.fabric8.kubernetes.api.model.extensions.DaemonSet;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import io.fabric8.kubernetes.api.model.extensions.StatefulSet;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Function;

import static com.hikvision.hae.resource.vo.PodDetailVO.*;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public class PodHelper {

	/**
	 * 计算环境变量的值
	 *
	 * @return 计算后的环境变量值
	 */
	private static String evalEnvValueFrom(EnvVarSource src, Container container, Pod pod,
										   List<ConfigMap> configMaps, List<Secret> secrets) {
		if (src.getConfigMapKeyRef() != null) {
			String name = src.getConfigMapKeyRef().getName();
			Optional<ConfigMap> optional = configMaps.stream()
					.filter(configMap -> Objects.equals(configMap.getMetadata().getName(), name))
					.findFirst();
			return optional.map(configMap -> configMap.getData().get(src.getConfigMapKeyRef().getKey())).orElse("");
		} else if (src.getSecretKeyRef() != null) {
			String name = src.getSecretKeyRef().getName();
			Optional<Secret> optional = secrets.stream()
					.filter(secret -> Objects.equals(secret.getMetadata().getName(), name))
					.findFirst();
			return optional.map(secret -> {
				String encrypted = secret.getData().get(src.getSecretKeyRef().getKey()); //k8s中的secret都是Base64编码后的加密字符
				return new String(Base64.getDecoder().decode(encrypted), StandardCharsets.UTF_8);
			}).orElse("");
		} else if (src.getResourceFieldRef() != null) {
			return extractContainerResourceValue(src.getResourceFieldRef(), container);
		} else if (src.getFieldRef() != null) {
			return extractFieldPathValue(src.getFieldRef(), pod);
		} else {
			return "";
		}
	}

	private static String extractContainerResourceValue(ResourceFieldSelector fs, Container container) {
		switch (fs.getResource()) {
			case "limits.cpu":
				return container.getResources().getLimits().get("cpu").getAmount();
			case "limits.memory":
				return container.getResources().getLimits().get("memory").getAmount();
			case "requests.cpu":
				return container.getResources().getRequests().get("cpu").getAmount();
			case "requests.memory":
				return container.getResources().getRequests().get("memory").getAmount();
			default:
				return "环境变量中不支持的容器资源（" + fs.getResource() + "）";
		}
	}

	//1.6版本仅支持：metadata.name, metadata.namespace, metadata.uid, spec.nodeName, spec.serviceAccountName, status.hostIP, status.podIP
	private static String extractFieldPathValue(ObjectFieldSelector objectFieldSelector, Pod pod) {
		String fieldPath = objectFieldSelector.getFieldPath();
		switch (fieldPath) {
			case "metadata.name":
				return pod.getMetadata().getName();
			case "metadata.namespace":
				return pod.getMetadata().getNamespace();
			case "metadata.uid":
				return pod.getMetadata().getUid();
			case "spec.nodeName":
				return pod.getSpec().getNodeName();
			case "spec.serviceAccountName":
				return pod.getSpec().getServiceAccountName();
			case "status.hostIP":
				return pod.getStatus().getHostIP();
			case "status.podIP":
				return pod.getStatus().getPodIP();
			default:
				return "环境变量中不支持的FieldPath引用（" + fieldPath + "）";
		}
	}

	public static List<ContainerVO> extractContainerInfo(List<Container> containers, Pod pod, List<ConfigMap> configMaps, List<Secret> secrets) {
		List<ContainerVO> containerVOList = new ArrayList<>();
		containers.forEach(container -> {
			List<EnvVarVO> envVarVOList = new ArrayList<>();
			for (EnvVar envVar : container.getEnv()) {
				String value = envVar.getValueFrom() != null ?
						PodHelper.evalEnvValueFrom(envVar.getValueFrom(), container, pod, configMaps, secrets) : envVar.getValue();
				envVarVOList.add(new EnvVarVO(envVar.getName(), value));
			}
			ContainerVO containerVO = new ContainerVO();
			containerVO.setName(container.getName());
			containerVO.setImage(container.getImage());
			containerVO.setCommands(container.getCommand());
			containerVO.setEnv(envVarVOList);
			containerVO.setArgs(container.getArgs());
			containerVOList.add(containerVO);
		});
		return containerVOList;
	}

	public static List<ConditionVO> buildConditionvO(Pod pod) {
		List<ConditionVO> conditionVOList = new ArrayList<>();
		pod.getStatus().getConditions().forEach(condition -> {
			ConditionVO vo = new ConditionVO();
			vo.setType(condition.getType());
			vo.setStatus(condition.getStatus());
			if (condition.getLastProbeTime() != null) {
				vo.setLastProbeTime(UTCDateUtil.parseUTCTimeToStandardDate(condition.getLastProbeTime().getTime()));
			}
			vo.setLastTransitionTime(UTCDateUtil.parseUTCTimeToStandardDate(condition.getLastTransitionTime().getTime()));
			vo.setReason(condition.getReason());
			vo.setMessage(condition.getMessage());
			conditionVOList.add(vo);
		});
		return conditionVOList;
	}

	public static PodControllerItemVO getPodController(Pod pod, PodBiz podBiz) {
		Map<String, String> annos = pod.getMetadata().getAnnotations();
		if (annos == null) {
			return null;
		}
		String creatorAnnotation = annos.get(ResourceConstants.CREATED_BY_ANNOTATION);
		if (creatorAnnotation == null || !creatorAnnotation.startsWith("{")) {
			return null;
		}
		SerializedReference serializedReference = JSON.parseObject(creatorAnnotation, SerializedReference.class);
		ResourceKind kind = ResourceKind.parse(serializedReference.getReference().getKind());
		String namespace = serializedReference.getReference().getNamespace();
		String name = serializedReference.getReference().getName();
		HasMetadata hashMetadata = KubeOperationFactory.getOperation(kind).getByName(namespace, name);

		PodControllerItemVO podControllerItemVO;
		switch (kind) {
			case ReplicationController:
				ReplicationController replicationController = (ReplicationController) hashMetadata;
				Function<ReplicationController, PodInfo> podInfoFunc1 = (ReplicationController rc) ->
						podBiz.getPodInfo(rc.getSpec().getSelector(), namespace, rc.getStatus().getReplicas(),
								rc.getSpec().getReplicas(), rc.getMetadata().getUid());
				podControllerItemVO = ResourceVOBuilder.buildPodControllerItemVO(replicationController, podInfoFunc1);
				break;
			case ReplicaSet:
				ReplicaSet replicaSet = (ReplicaSet) hashMetadata;
				Function<ReplicaSet, PodInfo> podInfoFunc2 = (ReplicaSet rs) ->
						podBiz.getPodInfo(rs.getSpec().getSelector(), namespace, rs.getStatus().getReplicas(),
								rs.getSpec().getReplicas(), rs.getMetadata().getUid());
				podControllerItemVO = ResourceVOBuilder.buildPodControllerItemVO(replicaSet, podInfoFunc2);
				break;
			case DaemonSet:
				DaemonSet daemonSet = (DaemonSet) hashMetadata;
				Function<DaemonSet, PodInfo> podInfoFunc3 = (DaemonSet ds) ->
						podBiz.getPodInfo(ds.getSpec().getSelector(), namespace, ds.getStatus().getCurrentNumberScheduled(),
								ds.getStatus().getDesiredNumberScheduled(), ds.getMetadata().getUid());
				podControllerItemVO = ResourceVOBuilder.buildPodControllerItemVO(daemonSet, podInfoFunc3);
				break;
			case Job:
				Job job = (Job) hashMetadata;
				Function<Job, PodInfo> podInfoFunc4 = (Job jb) ->
						podBiz.getPodInfo(jb.getSpec().getSelector(), namespace, jb.getStatus().getActive(), jb.getSpec().getCompletions(), null);
				podControllerItemVO = ResourceVOBuilder.buildPodControllerItemVO(job, podInfoFunc4);
				break;
			case StatefulSet:
				StatefulSet statefulSet = (StatefulSet) hashMetadata;
				Function<StatefulSet, PodInfo> podInfoFunc5 = (StatefulSet ss) ->
						podBiz.getPodInfo(ss.getSpec().getSelector(), namespace, ss.getStatus().getReplicas(),
								ss.getSpec().getReplicas(), ss.getMetadata().getUid());
				podControllerItemVO = ResourceVOBuilder.buildPodControllerItemVO(statefulSet, podInfoFunc5);
				break;
			default:
				podControllerItemVO = null;
		}
		return podControllerItemVO;
	}

}
