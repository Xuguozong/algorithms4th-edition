package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.foundation.service.NavigationService;
import com.hikvision.hae.foundation.service.impl.assist.navi.MenuResourceQuery;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import com.hikvision.hae.common.enums.Mode;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by zhanjiejun on 2017/12/11.
 */
@RestController
@RequestMapping("/api/menu/v1")
public class MenuRestful {

	@Autowired
	private NavigationService navigationService;

	@GetMapping("/menus/left")
	public AjaxResult<List<MenuResourceVO>> getMainMenu(@RequestParam(required = false) String namespace,
														@RequestParam(required = false) Mode mode) {
		AjaxResult<List<MenuResourceVO>> result = AjaxResult.buildSuccess();
		LoginUser loginUser = LoginUtils.getLoginUser();
		MenuResourceQuery menuResourceQuery = new MenuResourceQuery(loginUser.getId(), namespace, mode);
		result.setData(navigationService.getMainMenu(menuResourceQuery));
		return result;
	}

}
