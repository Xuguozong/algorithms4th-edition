package com.hikvision.hae.image.listener.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.image.constant.ImageTaskConstant;
import com.hikvision.hae.image.listener.ImageTaskEvent;
import com.hikvision.hae.image.listener.ImageTaskListener;
import com.hikvision.hae.img.biz.ImageRepositoryConfigBiz;
import com.hikvision.hae.img.biz.ImageTaskBiz;
import com.hikvision.hae.img.dto.ImageRepositoryAccessInfo;
import com.hikvision.hae.img.dto.ImageTaskDTO;
import com.hikvision.hae.img.dto.TaskStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 11:19 2018/3/20
 * @Description :  镜像监听器 默认实现类
 */
@Service
public class DefaultImageTaskListener implements ImageTaskListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultImageTaskListener.class);

	@Autowired
	private ImageRepositoryConfigBiz imageRepositoryConfigBiz;

	@Autowired
	private ImageTaskBiz imageTaskBiz;

	@Override
	@Async(value = "getDockerBuildPool")
	public void process(ImageTaskEvent event) {
		//1.更新镜像任务为制作状态
		ImageTaskDTO dto = event.getImageTaskDTO();
		imageTaskBiz.updateStatus(dto.getId(), TaskStatus.BUILDING, "构建中");

		//2.生成dockerfile
		File dockerFile = new File(dto.getProgramPath(), ImageTaskConstant.DOCKER_FILE);
		try (OutputStream outputStream = new FileOutputStream(dockerFile)) {
			outputStream.write(dto.getContent().getBytes());
		} catch (Exception e) {
			LOGGER.info("目录{}生成Dockerfile异常", dto.getProgramPath());
			imageTaskBiz.updateStatus(dto.getId(), TaskStatus.FAIlURE, "生成Dockerfile时失败");
			return;
		}

		//3.通过dockerfile生成docker
		ImageRepositoryAccessInfo info = imageRepositoryConfigBiz.accessInfo();
		String dockerTag = dto.getRepository() + ImageTaskConstant.COLON + dto.getTag();
		try {
			imageTaskBiz.buildDocker(dockerTag, new File(dto.getProgramPath()), info);
		} catch (HAERuntimeException e) {
			imageTaskBiz.updateStatus(dto.getId(), TaskStatus.FAIlURE, "通过Dockerfile构建镜像失败");
			return;
		}

		//4.推送镜像
		try {
			imageTaskBiz.pushDocker(dockerTag, info);
		} catch (HAERuntimeException e) {
			imageTaskBiz.updateStatus(dto.getId(), TaskStatus.FAIlURE, "向镜像仓库推送镜像失败");
			return;
		}

		//5.更新镜像任务为成功状态
		imageTaskBiz.updateStatus(dto.getId(), TaskStatus.SUCCESS, "成功");

		//6.清理产生的垃圾文件
		imageTaskBiz.removeImageDIR(dto.getProgramPath());
	}
}
