package com.hikvision.hae.alarm.web.restful;

import com.hikvision.hae.alarm.event.dto.EventAlarmQuery;
import com.hikvision.hae.alarm.service.EventAlarmService;
import com.hikvision.hae.alarm.vo.EventAlarmVO;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
@RestController
@RequestMapping("/api/eventAlarm/v1")
public class EventAlarmRestful {

	@Autowired
	private EventAlarmService eventAlarmService;

	/**
	 * @param pageSize
	 * @param pageNo
	 * @param query    查询条件
	 * @return
	 */
	@ApiOperation(value = "分页查询事件告警", produces = "application/json")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "path", name = "pageSize", dataType = "int", required = true, value = "页大小"),
			@ApiImplicitParam(paramType = "path", name = "pageNo", dataType = "int", required = true, value = "页码"),
			@ApiImplicitParam(paramType = "query", name = "history", dataType = "Boolean", value = "是否历史告警，不传代表查询全部"),
			@ApiImplicitParam(paramType = "query", name = "objectName", dataType = "String", value = "告警对象名称，支持模糊查询"),
			@ApiImplicitParam(paramType = "query", name = "timeQueryMode", dataType = "Integer", value = "时间查询模式，1代表最近一次，0代表首次告警"),
			@ApiImplicitParam(paramType = "query", name = "start", dataType = "Long", value = "时间过滤起始时间"),
			@ApiImplicitParam(paramType = "query", name = "end", dataType = "Long", value = "时间过滤结束时间")
	})
	@GetMapping("/eventAlarms/{pageSize}/{pageNo}")
	public AjaxResult<Pagination<EventAlarmVO>> findAndPage(@PathVariable int pageSize,
															@PathVariable int pageNo,
															EventAlarmQuery query) {
		AjaxResult<Pagination<EventAlarmVO>> result = AjaxResult.buildSuccess();
		result.setData(eventAlarmService.findAndPage(new PageParam(pageNo, pageSize), query));
		return result;
	}

	@ApiOperation(value = "查询事件告警数量", produces = "application/json")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", name = "history", dataType = "Boolean", value = "是否历史告警，不传代表查询全部"),
			@ApiImplicitParam(paramType = "query", name = "objectName", dataType = "String", value = "告警对象名称，支持模糊查询"),
			@ApiImplicitParam(paramType = "query", name = "timeQueryMode", dataType = "Integer", value = "时间查询模式，1代表最近一次，0代表首次告警"),
			@ApiImplicitParam(paramType = "query", name = "start", dataType = "Long", value = "时间过滤起始时间"),
			@ApiImplicitParam(paramType = "query", name = "end", dataType = "Long", value = "时间过滤结束时间")
	})
	@GetMapping("/eventAlarms/count")
	public AjaxResult<Long> countCurrentAlarm(EventAlarmQuery query) {
		AjaxResult<Long> result = AjaxResult.buildSuccess();
		result.setData(eventAlarmService.count(query));
		return result;
	}

}
