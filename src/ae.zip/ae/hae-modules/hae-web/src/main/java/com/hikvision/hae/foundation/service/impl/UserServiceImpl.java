package com.hikvision.hae.foundation.service.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.foundation.common.constant.FoundationResultCode;
import com.hikvision.hae.foundation.common.exception.ForceModifyPwdException;
import com.hikvision.hae.foundation.service.UserService;
import com.hikvision.hae.foundation.user.biz.UserBiz;
import com.hikvision.hae.foundation.user.dto.UserDTO;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.security.auth.login.AccountNotFoundException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserBiz userBiz;

	@Override
	public LoginUser login(String username, String orginPwd) throws LoginException {
		UserDTO userDTO = userBiz.findByUsername(username);
		if (userDTO == null) {
			throw new AccountNotFoundException();
		}
		if (!BCrypt.checkpw(orginPwd, userDTO.getPassword())) {
			throw new FailedLoginException();
		}
		if (userDTO.isForceModifyPwd()) {
			throw new ForceModifyPwdException(userDTO.getId());
		}
		LoginUser loginUser = new LoginUser();
		loginUser.setId(userDTO.getId());
		loginUser.setUsername(userDTO.getUsername());
		loginUser.setRealName(userDTO.getRealName());
		loginUser.setPhoneNumber(userDTO.getPhoneNumber());
		loginUser.setEmail(userDTO.getEmail());
		return loginUser;
	}

	@Override
	public boolean auth(String username, String orginPwd) {
		UserDTO userDTO = userBiz.findByUsername(username);
		return userDTO != null && BCrypt.checkpw(orginPwd, userDTO.getPassword());
	}

	@Override
	public void forceModifyPassword(String username, String newPassword) {
		if (!userBiz.isUserExist(username)) {
			throw new HAERuntimeException(FoundationResultCode.USER_NOT_EXIST);
		}
		userBiz.modifyPwd(username, newPassword);
	}

	@Override
	public void modifyPassword(String username, String oldPwd, String newPwd) {
		UserDTO userDTO = userBiz.findByUsername(username);
		if (userDTO == null) {
			throw new HAERuntimeException(FoundationResultCode.USER_NOT_EXIST);
		}
		// 校验旧密码
		if (!BCrypt.checkpw(oldPwd, userDTO.getPassword())) {
			throw new HAERuntimeException(FoundationResultCode.WRONG_OLD_PASSWORD);
		}
		userBiz.modifyPwd(username, newPwd);
	}

	@Override
	public UserDTO getUserByName(String username) {
		UserDTO userDTO = userBiz.findByUsername(username);
		if (userDTO == null) {
			throw new HAERuntimeException(FoundationResultCode.USER_NOT_EXIST);
		}
		return userDTO;
	}

}
