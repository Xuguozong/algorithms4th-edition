package com.hikvision.hae;

import jef.codegen.EntityEnhancer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import pl.allegro.tech.boot.autoconfigure.handlebars.HandlebarsAutoConfiguration;

/**
 * 工程启动类
 *
 * @author zhanjiejun
 */
@SpringBootApplication
public class HAEApplication {

    public static void main(String[] args) throws Exception {
        // 配置文件加密
        System.setProperty("jasypt.encryptor.password", "hae_jasypt");
        System.setProperty("jasypt.encryptor.proxyPropertySources", "true");
        // 并行共享线程池大小，取10和核数*2中的较小者
        int currentCPUThreadCount = Runtime.getRuntime().availableProcessors();
        System.setProperty("java.assist.concurrent.ForkJoinPool.common.parallelism", String.valueOf(Math.min(currentCPUThreadCount * 2, 10)));
        SpringApplication.run(HAEApplication.class, args);
    }

}
