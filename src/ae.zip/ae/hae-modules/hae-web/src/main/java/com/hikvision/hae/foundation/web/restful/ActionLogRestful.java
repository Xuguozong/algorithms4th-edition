package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import com.hikvision.hae.foundation.service.ActionLogService;
import com.hikvision.hae.foundation.vo.ActionLogVO;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 操作日志Ajax请求处理器
 *
 * Created by zhouziwei on 2017/11/2.
 */
@Api(description = "操作日志")
@RestController
@RequestMapping(value = "/api/actionLog/v1")
public class ActionLogRestful {

    @Resource
    private ActionLogService actionLogService;

    /**
     * 获取操作日志列表
     *
     * @param startTime 起始时间，毫秒
     * @param endTime   截止时间， 毫秒
     * @param fq        模糊查询参数名。 fq = FuzzyQuery
     * @return 操作日志分页数据
     */
    @GetMapping("/actionLogs/{pageSize}/{pageNo}")
    public AjaxResult<Pagination<ActionLogVO>> listLogs(@PathVariable int pageSize,
                                                        @PathVariable int pageNo,
                                                        @RequestParam(required = false) Long startTime,
                                                        @RequestParam(required = false) Long endTime,
                                                        @RequestParam(required = false) String fq) {

        PageParam pageParam = new PageParam();
        pageParam.setPageNo(pageNo);
        pageParam.setPageSize(pageSize);
        ActionLogQuery queryParam = new ActionLogQuery();
        if (startTime != null) {
            queryParam.setStartTime(new Date(startTime));
        }
        if (endTime != null) {
            queryParam.setEndTime(new Date(endTime));
        }
        queryParam.setFq(fq);
        Pagination<ActionLogVO> pagination = actionLogService.findAndPage(queryParam, pageParam);
        return new AjaxResult<>(CommonResultCode.SUCCESS, pagination);
    }

}
