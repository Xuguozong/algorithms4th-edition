package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.DaemonSetDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
public interface DaemonSetService {

    /**
     * 分页查询DaemonSet
     *
     * @param namespace 命名空间
     * @param name      DaemonSet名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodControllerItemVO> findAndPage(String namespace, String name, PageParam pageParam);

    /**
     * 查看DaemonSet详情
     *
     * @param namespace 命名空间
     * @param name      DaemonSet名称
     * @return DaemonSet详情
     */
    DaemonSetDetailVO getDetail(String namespace, String name);

    /**
     * 删除DaemonSet
     *
     * @param namespace 命名空间
     * @param name      DaemonSet名称
     */
    void delete(String namespace, String name);
}
