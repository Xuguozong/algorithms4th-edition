package com.hikvision.hae.image.listener;

public interface UploadListener extends EventListener<UploadFileCompleteEvent> {

}
