package com.hikvision.hae.foundation.service.impl;

import com.hikvision.hae.common.i18n.Localeable;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.foundation.actionlog.biz.ActionLogBiz;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogDTO;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import com.hikvision.hae.foundation.service.ActionLogService;
import com.hikvision.hae.foundation.vo.ActionLogVO;
import jef.common.wrapper.Page;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by zhouziwei on 2017/11/2.
 */
@Service
public class ActionLogServiceImpl implements ActionLogService {

    @Resource
    private MessageSource messageSource;

    @Resource
    private ActionLogBiz actionLogBiz;


    @Override
    public Pagination<ActionLogVO> findAndPage(ActionLogQuery queryParam, PageParam pageParam) {
        Page<ActionLogDTO> dtoPage = actionLogBiz.findAndPage(queryParam, pageParam);
        Page<ActionLogVO> voPage = new Page<>(dtoPage.getTotalCount(), dtoPage.getPageSize());
        List<ActionLogVO> voList = Optional.ofNullable(dtoPage.getList())
                .map(rows -> rows.stream() //构建流
                        .map(row -> ActionLogVO.readFromDTO(row, this.getEnumTextConverter())) //model -> dto
                        .collect(Collectors.toList())) // 归集到集合
                .orElse(Collections.emptyList()); //原集合为null怎返回空list
        voPage.setList(voList);
        return new Pagination<>(pageParam.getPageNo(), voPage);

    }

    /**
     * 适用于：代码中写的是枚举，但是在视图中要把枚举常量转换成文本。
     * 枚举类必须实现{@link Localeable}接口，提供国际化的key。
     *
     * @return {@link Function}对象，接受Localeable对象，返回对象的国际化文本
     */
    protected Function<Localeable, String> getEnumTextConverter() {
        //国际化converter
        return localeable -> messageSource.getMessage(localeable.i18nKey(), null,
                "", LocaleContextHolder.getLocale());
    }
}
