package com.hikvision.hae.common.util;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.vo.KeyValue;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {

    public static List<KeyValue> transferMultipartFile2KeyValue(MultipartFile... files) {
        List<KeyValue> fileList = new ArrayList<>();
        if (files == null || files.length <= 0) {
            throw new HAERuntimeException(CommonResultCode.AT_LEAST_ONE_FILE_FOR_CONFIGMAP_NEED);
        }
        try {
            for (MultipartFile f : files) {
                if (f == null) {
                    continue;
                }
                String originFilename = f.getOriginalFilename();
                if (originFilename.contains("\\")) {
                    //低版本的IE会上传文件的完整路径
                    originFilename = originFilename.substring(originFilename.lastIndexOf('\\') + 1);
                }
                fileList.add(new KeyValue(originFilename, new String(f.getBytes(), StandardCharsets.UTF_8)));
            }
        } catch (IOException e) {
            throw new HAERuntimeException(CommonResultCode.FILE_UPSTREAM_RESOLVE_FAIL);
        }
        return fileList;
    }

}
