package com.hikvision.hae.resource.service;

import com.hikvision.hae.resource.vo.NamespaceDetailVO;
import com.hikvision.hae.resource.vo.NamespaceReadVO;
import com.hikvision.hae.resource.vo.NamespaceWriteVO;

import java.util.List;

/**
 * 命名空间Service层
 * Created by zhanjiejun on 2017/11/10.
 */
public interface NamespaceService {

	List<NamespaceReadVO> getNamespaces(boolean calculateQuota);

	NamespaceReadVO getNamespace(String name);

	NamespaceDetailVO getNamespaceDetail(String name);

	NamespaceReadVO createNamespace(NamespaceWriteVO namespaceWriteVO);

	NamespaceReadVO modifyNamespace(NamespaceWriteVO namespaceWriteVO);

	void deleteNamespace(String name);

	boolean isNameExist(String name);

}
