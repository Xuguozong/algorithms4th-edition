package com.hikvision.hae.image.job;

import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.listener.StatusEvent;
import com.hikvision.hae.image.listener.StatusListener;
import com.hikvision.hae.image.service.UploadRecordService;
import com.hikvision.hae.image.service.UploadStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;


/**
 * 定时清理推送失败的上传记录
 * @author qiuzhihao
 *
 */
@Configuration
@ConditionalOnProperty(prefix = "image", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ChangePushImageStatusJob implements StatusListener {
	
	private static final Logger logger = LoggerFactory.getLogger(ChangePushImageStatusJob.class);
	
	private ConcurrentMap<String, UploadStatus> taskMap = new ConcurrentHashMap<>();
	
	private List<String> candidateCleanList = new CopyOnWriteArrayList<>();
	
	@Resource
	private UploadRecordService uploadRecordSvc;
	
	@Resource
	private UploadStatusService statusService;

	/**
	 * 处理镜像上传事件，区分出开始、结束事件
	 * 定时清理任务根据当前任务列表来判断是否可用执行清理操作
	 */
	@Override
	public void process(StatusEvent event) {
		push(event);
		pop(event);
	}
	
	/**
	 * 只关心镜像推送阶段的状态
	 * UploadStatus.PUSHING和UploadStatus.UPLOADED都表示开始推送镜像
	 * @param event
	 */
	private void push(StatusEvent event) {
		if(event.getStatus() == UploadStatus.PUSHING || UploadStatus.WAITING_PUSH == event.getStatus()) {
			taskMap.putIfAbsent(event.getFileId(), event.getStatus());
		}
	}
	/**
	 * 只关心镜像推送阶段的状态
	 * UploadStatus.PUSHED和UploadStatus.PUSH_ERROR表示推送任务结束
	 * @param event
	 */
	private void pop(StatusEvent event) {
		if(event.getStatus() == UploadStatus.PUSHED || event.getStatus() == UploadStatus.PUSH_ERROR) {
			taskMap.remove(event.getFileId());
		}
	}
	
	/**
	 * 更新处于推送中断状态的记录
	 * 采用两次筛选为了避免第一次筛选出现临界状态的情况
	 */
	@Scheduled(fixedRateString = "${job.config.cleanPushFailInterval:60000}")
	public void cleanImagePush() {
		try {
			// 拷贝上次筛选队列
			List<String> todoList = new ArrayList<>(candidateCleanList);
			candidateCleanList.clear();
			
			List<UploadFile> pushingList = uploadRecordSvc.pushImageMiddleStatusList();
			if(pushingList != null) {
				pushingList.forEach(file -> {
					// 第一次筛选
					// 如果当前上传文件的推送任务不存在了，文件进入候选删除队列
					if(!taskMap.containsKey(file.getFileId())) {
						logger.info("推送镜像{}进入中断候选队列", file.toString());
						candidateCleanList.add(file.getFileId());
						
						// 经过两次筛选都判定要更改状态
						if(todoList.contains(file.getFileId())) {
							statusService.updateToPushError(file.getFileId(), "镜像推送中断");
							logger.info("修改推送镜像{}状态成推送失败", file.toString());
						}
					}
					
				});
			}
		} catch (Exception e) {
			logger.warn("清理推送失败的上传记录任务出错", e);
		}
	}

}
