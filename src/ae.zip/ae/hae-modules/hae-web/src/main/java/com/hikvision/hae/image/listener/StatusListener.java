package com.hikvision.hae.image.listener;

public interface StatusListener extends EventListener<StatusEvent> {

}
