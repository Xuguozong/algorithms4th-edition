package com.hikvision.hae.image.vo;

public class UploadFileVO {

	/**
	 * 每次上传唯一id
	 */
	private String id;

	/**
	 * 当前第几块
	 */
	private int trunk;
	/**
	 * 总块数
	 */
	private int trunks;
	/**
	 * 上传文件名
	 */
	private String fileName;

	/**
	 * 本地文件目录
	 */
	private String nativePath;
	/**
	 * 当前块MD5校验值
	 */
	private String md5Checksum;
	/**
	 * 文件大小 
	 */
	private long totalSize;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getTrunk() {
		return trunk;
	}

	public void setTrunk(int trunk) {
		this.trunk = trunk;
	}

	public int getTrunks() {
		return trunks;
	}

	public void setTrunks(int trunks) {
		this.trunks = trunks;
	}

	public String getNativePath() {
		return nativePath;
	}

	public void setNativePath(String nativePath) {
		this.nativePath = nativePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getMd5Checksum() {
		return md5Checksum;
	}

	public void setMd5Checksum(String md5Checksum) {
		this.md5Checksum = md5Checksum;
	}

	public long getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}

	@Override
	public String toString() {
		return "UploadFileVO [id=" + id + ", trunk=" + trunk + ", trunks=" + trunks + ", nativePath=" + nativePath+
				", fileName=" + fileName + ", md5Checksum=" + md5Checksum + ", totalSize=" + totalSize + "]";
	}
	
}
