package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.job.JobBiz;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.service.JobService;
import com.hikvision.hae.resource.vo.JobDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import io.fabric8.kubernetes.api.model.Job;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
@Service
public class JobServiceImpl implements JobService {
    private static final Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

    @Resource
    private JobBiz jobBiz;

    @Resource
    private PodBiz podBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PodControllerItemVO> findAndPage(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<Job> jobPage = jobBiz.findAndPage(filterQuery, pageParam);
        if (jobPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }
        Function<Job, PodInfo> podInfoFunc = (Job job) ->
                podBiz.getPodInfo(job.getSpec().getSelector(), namespace, job.getStatus().getActive(), job.getSpec().getCompletions(), null);
        Function<Collection<Job>, Collection<PodControllerItemVO>> rowsConverter =
                (Collection<Job> dtoList) -> dtoList.stream()
                        .map(job -> ResourceVOBuilder.buildPodControllerItemVO(job, podInfoFunc)).collect(Collectors.toList());
        return new Pagination<>(jobPage, rowsConverter);
    }

    @Override
    public JobDetailVO getDetail(String namespace, String name) {
        //Job属性信息
        Job job = jobBiz.getByName(namespace, name);
        if (job == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Job[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.JOB_NOT_EXIST);
        }

        JobDetailVO vo = new JobDetailVO();
        vo.setNamespace(job.getMetadata().getNamespace());
        vo.setName(job.getMetadata().getName());
        vo.setLabels(job.getMetadata().getLabels());
        vo.setAnnotations(job.getMetadata().getAnnotations());
        vo.setImages(ResourceVOBuilder.getContainerImages(job.getSpec().getTemplate()));
        vo.setCompletions(job.getSpec().getCompletions());
        vo.setParallelism(job.getSpec().getParallelism());
        vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(job.getMetadata().getCreationTimestamp().getTime()));
        PodInfo podInfo = podBiz.getPodInfo(job.getSpec().getSelector(), namespace,
                job.getStatus().getActive(), job.getSpec().getCompletions(), null);
        vo.setPodInfo(ResourceVOBuilder.buildPodInfoVO(podInfo));
        return vo;
    }

    @Override
    public void delete(String namespace, String name) {
        jobBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.JOB, PrincipalCategory.JOB, namespace, name, "删除任务（Job）");
    }
}
