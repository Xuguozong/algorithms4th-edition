package com.hikvision.hae.foundation.service;


import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import com.hikvision.hae.foundation.vo.ActionLogVO;

/**
 * 操作（行为、行为）日志视图层逻辑接口
 * 
 * @author jianghaiyang5 2017年6月9日
 *
 */
public interface ActionLogService {
	
	/**
	 * 
	 * @param queryParam 查询的条件
	 * @param pageParam 分页参数
	 * @return 操作日志分页数据
	 */
	Pagination<ActionLogVO> findAndPage(ActionLogQuery queryParam, PageParam pageParam);

}
