package com.hikvision.hae.image.listener;

/**
 * 镜像推送
 * 
 * @author qiuzhihao
 *
 */
public interface PushListener extends EventListener<PushFileEvent> {

}
