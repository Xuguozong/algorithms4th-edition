package com.hikvision.hae.metrics.service;

import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.vo.MetricsQueryVO;
import com.hikvision.hae.common.vo.MetricsTrendVO;

import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public interface MetricsService {

	/**
	 * 获取节点资源使用率趋势图
	 *
	 * @param nodeId       节点ID
	 * @param metricsQuery 查询条件
	 * @return
	 */
	MetricsTrendVO getNodeMetricsTrend(int nodeId, MetricsQueryVO metricsQuery);

	/**
	 * 获取节点GPU使用率
	 *
	 * @param nodeId 节点ID
	 * @return key -> GPU卡序号 value -> 使用率百分比
	 */
	Map<String, String> getNodeGpuUsage(int nodeId);

	/**
	 * 获取节点GPU趋势图
	 *
	 * @param nodeId       节点ID
	 * @param gpuIndex     GPU卡序号
	 * @param metricsQuery 查询条件
	 * @return
	 */
	MetricsTrendVO getNodeGpuMetricsTrend(int nodeId, String gpuIndex, MetricsQueryVO metricsQuery);

	/**
	 * 获取节点GPU基本信息
	 *
	 * @param nodeId   节点ID
	 * @param gpuIndex GPU卡序号
	 * @return
	 */
	GpuBaseInfo getNodeGpuBaseInfo(int nodeId, String gpuIndex);

	/**
	 * 获取命名空间资源使用率趋势图
	 *
	 * @param namespace    命名空间
	 * @param metricsQuery 查询条件
	 * @return
	 */
	MetricsTrendVO getNamespaceMetricsTrend(String namespace, MetricsQueryVO metricsQuery);

	/**
	 * 获取POD资源使用率趋势图
	 *
	 * @param namespace    命名空间
	 * @param podName      POD名称
	 * @param metricsQuery 查询条件
	 * @return
	 */
	MetricsTrendVO getPodMetricsTrend(String namespace, String podName, MetricsQueryVO metricsQuery);

}
