package com.hikvision.hae.foundation.web.assist;

import com.google.code.kaptcha.servlet.KaptchaExtend;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author jinshi
 * @date 2016/12/2
 */
public abstract class CaptchaUtils {

	private static final String KAPTCHA_SESSION_KEY = "KAPTCHA_SESSION_KEY";
	private static KaptchaExtend kaptchaExtend = new KaptchaExtend();

	public static void captcha(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		kaptchaExtend.captcha(req, resp);
	}

	public static String getGeneratedKey(HttpServletRequest req) {
		return kaptchaExtend.getGeneratedKey(req);
	}

	public static boolean checkCaptcha(String captcha, HttpServletRequest req) {
		return captcha != null && captcha.equals(getGeneratedKey(req));
	}

	public static boolean checkCaptcha(String captcha, HttpSession session) {
		String key = (String) session.getAttribute(KAPTCHA_SESSION_KEY);
		return captcha != null && captcha.equals(key);
	}

}
