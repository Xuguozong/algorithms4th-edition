package com.hikvision.hae.foundation.service;

import com.hikvision.hae.foundation.service.impl.assist.navi.MenuResourceQuery;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import com.hikvision.hae.foundation.vo.SimpleMenuResourceVO;

import java.util.List;

/**
 * 页面导航数据接口
 * <p>
 * Created by zhouziwei on 2017/11/3.
 */
public interface NavigationService {

	/**
	 * 获取的核心菜单数据
	 *
	 * @param menuResourceQuery 菜单资源查询条件参数
	 * @return 菜单树的根节点的子孙节点树
	 */
	List<MenuResourceVO> getMainMenu(MenuResourceQuery menuResourceQuery);

	/**
	 * 根据菜单资源编码查询菜单
	 *
	 * @param sysResourceCode 菜单资源编码
	 * @return
	 */
	SimpleMenuResourceVO getSimpleMenuByCode(String sysResourceCode);

}
