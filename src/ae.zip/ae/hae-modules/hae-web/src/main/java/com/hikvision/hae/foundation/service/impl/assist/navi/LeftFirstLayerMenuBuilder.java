package com.hikvision.hae.foundation.service.impl.assist.navi;

import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 左侧首页菜单构建
 * <p>
 * Created by zhouziwei on 2017/11/8.
 */
@Component
public class LeftFirstLayerMenuBuilder extends AbstractMenuBuilder {

	@Resource
	private SysResourceBiz sysResourceBiz;

	/**
	 * 构建左侧首层菜单
	 *
	 * @param userId 用户ID
	 * @return
	 */
	public MenuResourceVO build(String userId) {
		SysResourceDTO sysResourceDTO = sysResourceBiz.getResourceTree(SysResourceLayout.LEFT_LV1, null);
		return MenuResourceVO.readFromDTO(sysResourceDTO);
	}

}
