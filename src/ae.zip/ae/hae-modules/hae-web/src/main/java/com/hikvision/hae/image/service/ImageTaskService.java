package com.hikvision.hae.image.service;

import com.hikvision.hae.image.vo.ImageEntityVO;
import com.hikvision.hae.image.vo.ImageTaskVO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 14:10 2018/3/16
 * @Description :  镜像任务service层 接口定义
 */
public interface ImageTaskService {

	/**
	 * @param file     上传的程序文件
	 * @param id       镜像任务ID
	 * @param fileName 程序文件名称
	 * @return 镜像任务ID
	 */
	Integer uploadProgram(MultipartFile file, Integer id, String fileName);

	/**
	 * @param id            镜像任务ID
	 * @param imageEntityVO 镜像实体
	 */
	void submitTask(Integer id, ImageEntityVO imageEntityVO);

	/**
	 * 预览镜像任务
	 *
	 * @param imageEntityVO
	 * @return
	 */
	ImageTaskVO scanTask(ImageEntityVO imageEntityVO);

	/**
	 * 获取所有的镜像任务
	 *
	 * @return 任务列表
	 * @description 后期数据较多的话  可以做分页处理
	 */
	List<ImageTaskVO> getAllTask();

	void clearTask(int id);
}
