package com.hikvision.hae.image.job;

import com.hikvision.hae.img.biz.ImageTaskBiz;
import com.hikvision.hae.img.dto.ImageTaskDTO;
import com.hikvision.hae.img.dto.TaskStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.CollectionUtils;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

/**
 * @Author :  lijiazheng
 * @Date :  Created in 17:01 2018/4/11
 * @Description :  清理只上传程序包的镜像任务
 */
@Configuration
@ConditionalOnProperty(prefix = "image", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ClearImageTaskJob {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClearImageTaskJob.class);

	@Autowired
	private ImageTaskBiz imageTaskBiz;

	/**
	 * 每天凌晨执行任务
	 */
	@Scheduled(cron = "0 0 0 ? * *")
	public void clearTask() {
		List<ImageTaskDTO> imageTaskDTOS = imageTaskBiz.findImageTaskByStatus(TaskStatus.PACKAGE);
		if (!CollectionUtils.isEmpty(imageTaskDTOS)) {
			imageTaskDTOS.forEach(dto -> {
				//1.删除超过三十分钟的作废程序包
				Date createTime = dto.getCreateTime();
				LocalDateTime start = LocalDateTime.ofInstant(createTime.toInstant(), ZoneId.systemDefault());
				Duration duration = Duration.between(start, LocalDateTime.now());
				if (duration.toMinutes() > 30) {
					LOGGER.info("开始删除作废程序包{}", dto.getProgramName());
					imageTaskBiz.removeImageDIR(dto.getProgramPath());
					imageTaskBiz.deleteTaskById(dto.getId());
					LOGGER.info("删除作废程序包{}完成", dto.getProgramName());
				}
			});
		}

	}

	/**
	 * 每天凌晨1点清理失败任务的文件
	 */
	@Scheduled(cron = "0 0 1 ? * *")
	public void clearFailureTask() {
		List<ImageTaskDTO> imageTaskDTOS = imageTaskBiz.findImageTaskByStatus(TaskStatus.FAIlURE);
		if (!CollectionUtils.isEmpty(imageTaskDTOS)) {
			imageTaskDTOS.forEach(dto -> {
				LOGGER.info("开始删除失败镜像任务{}的垃圾文件夹{}", dto.getTaskName(), dto.getProgramPath());
				imageTaskBiz.removeImageDIR(dto.getProgramPath());
				LOGGER.info("完成删除失败镜像任务{}的垃圾文件夹{}", dto.getTaskName(), dto.getProgramPath());
			});
		}
	}
}
