package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.ReplicaSetDetailVO;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
public interface ReplicaSetService {

    /**
     * 分页查询ReplicaSet
     *
     * @param namespace 命名空间
     * @param name      ReplicaSet名称
     * @param labels    标签字符串 形如：k1;k2:v2
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodControllerItemVO> findAndPage(String namespace, String name, String labels, PageParam pageParam);

    /**
     * 查询deployment的新副本集。因前台按列表显示，所以返回List
     *
     * @param namespace 命名空间
     * @param deploymentName deployment名称
     * @return 新副本集列表
     */
    List<PodControllerItemVO> findNewReplicaSet(String namespace, String deploymentName);

    /**
     * 按deployment查询历史ReplicaSet
     *
     * @param namespace      命名空间
     * @param deploymentName deployment名称
     * @param pageParam      分页参数
     * @return 旧副本集列表
     */
    Pagination<PodControllerItemVO> findAndPageOldReplciaSet(String namespace, String deploymentName, PageParam pageParam);

    /**
     * 查看ReplicaSet详情
     *
     * @param namespace 命名空间
     * @param name      ReplicaSet名称
     * @return ReplicaSet详情
     */
    ReplicaSetDetailVO getDetail(String namespace, String name);

    /**
     * 删除ReplicaSet
     *
     * @param namespace 命名空间
     * @param name      ReplicaSet名称
     */
    void delete(String namespace, String name);
}
