package com.hikvision.hae.resource.assist;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.ObjectMapperSingleton;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.file.dto.ResourceFileDTO;
import io.fabric8.kubernetes.api.model.ObjectMeta;
import io.fabric8.kubernetes.client.utils.Serialization;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.yaml.snakeyaml.Yaml;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 一个资源文件中可能同时定义了多个资源，解析资源文件的内容，分离出不同的资源文档，并得到不同文档的资源标识
 *
 * @author jianghaiyang5 on 2017/11/24.
 */
public class ResourceDefineResolver {

    private static Logger logger = LoggerFactory.getLogger(ResourceDefineResolver.class);

    private static Yaml yaml = new Yaml();

    public static Map<ResourceMetaInfo, String> resolve(ResourceFileDTO resourceFile) {
        String content = resourceFile.getContent();
        if (!StringUtils.hasText(content)) {
            return new HashMap<>();
        }
        //一个文件中可能同时定义了多个资源，不同资源定义之间用单行"---"隔开
        List<String> resDefines = Arrays.asList(content.split("[\\r\\n]*\\s*[\\r\\n][\\-]{3}[\\r\\n]+\\s*"));
        String fileName = resourceFile.getFileName().toLowerCase();
        Map<ResourceMetaInfo, String> resourceMap = new HashMap<>();
        resDefines.forEach(resourceDefinition -> {
            String resourceJson = resolve2Json(fileName, resourceDefinition);
            resourceMap.put(resolve(resourceJson, ResourceMetaInfo.class), resourceJson);
        });
        return resourceMap;
    }

    public static <T> T resolve(String fileName, String resourceDefinition, Class<T> classType) {
        String resourceJson = resolve2Json(fileName, resourceDefinition);
        T metaInfo;
        try {
            metaInfo = ObjectMapperSingleton.getJSONMapperInstance().readValue(resourceJson, classType);
        } catch (Exception e) {
            logger.error("JSON格式错误：\n" + resourceJson);
            throw new HAERuntimeException(ResourceResultCode.MALFORMED_KUBE_DOCUMENT, e);
        }
        return metaInfo;
    }

    public static String resolve2Json(String fileName, String resourceDefinition) {
        String resourceJson = resourceDefinition;
        if (fileName.endsWith(".yaml") || fileName.endsWith(".yml")) {
            try {
                resourceJson = Serialization.asJson(yaml.load(resourceJson)); //yaml to json
            } catch (Exception e) {
                logger.error("YAML格式错误：\n" + resourceJson);
                throw new HAERuntimeException(ResourceResultCode.MALFORMED_KUBE_DOCUMENT, e);
            }
        }
        return resourceJson;
    }

    public static <T> T resolve(String resourceJson, Class<T> classType) {
        T metaInfo;
        try {
            metaInfo = ObjectMapperSingleton.getJSONMapperInstance().readValue(resourceJson, classType);
        } catch (Exception e) {
            logger.error("JSON格式错误：\n" + resourceJson);
            throw new HAERuntimeException(ResourceResultCode.MALFORMED_KUBE_DOCUMENT, e);
        }
        return metaInfo;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ResourceMetaInfo {
        private String apiVersion;
        private String kind;
        private ObjectMeta metadata;

        public String getApiVersion() {
            return apiVersion;
        }

        public void setApiVersion(String apiVersion) {
            this.apiVersion = apiVersion;
        }

        public String getKind() {
            return kind;
        }

        public void setKind(String kind) {
            this.kind = kind;
        }

        public ObjectMeta getMetadata() {
            return metadata;
        }

        public void setMetadata(ObjectMeta metadata) {
            this.metadata = metadata;
        }
    }
}
