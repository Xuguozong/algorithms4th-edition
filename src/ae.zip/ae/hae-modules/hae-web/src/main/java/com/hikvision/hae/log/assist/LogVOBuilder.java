package com.hikvision.hae.log.assist;

import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.log.dto.LogDTO;
import com.hikvision.hae.log.vo.LogVO;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
public class LogVOBuilder {

	public static LogVO buildLogVO(LogDTO logDTO) {
		LogVO logVO = new LogVO();
		logVO.setMessage(logDTO.getMessage());
		logVO.setFields(logDTO.getFields());
		logVO.setKubernetes(logDTO.getKubernetes());
		logVO.setTimestamp(UTCDateUtil.parseUTCTimeNanoToStandardDate(logDTO.getTimestamp()));
		logVO.setSource(logDTO.getSource());
		return logVO;
	}

}
