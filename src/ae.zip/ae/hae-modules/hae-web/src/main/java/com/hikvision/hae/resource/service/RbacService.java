package com.hikvision.hae.resource.service;

/**
 * FIXME: 写此类是为了以Restful API方式验证RBAC的Biz层实现（懒得写单元测试）
 * FIXME: 因为Restful和Service是和视图逻辑紧密相关的，目前无相关视图逻辑，所以就先全部注释掉
 * FIXME: 假如增加了视图逻辑，不允许直接返回k8s对象，必须转成对应的VO对象
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
public interface RbacService {
    /**
     * 分页查询满足条件的所有 RbacRole
     *
     * @param pageParam 分页条件
     * @return RbacRole 对象列表
     */
//    Pagination<Role> findAndPageRole(String namespace, String name, PageParam pageParam);

    /**
     * 查询指定name的 RbacRole
     *
     * @param namespace RbacRole 所在的namespace
     * @param name      RbacRole 的名称
     * @return null或者 RbacRole 对象
     */
//    Role getRoleByName(String namespace, String name);

    /**
     * 删除指定namespace和name的 RbacRole
     *
     * @param namespace RbacRole 所在的namespace
     * @param name      RbacRole 的名称
     */
//    void deleteRole(String namespace, String name);

    /**
     * 分页查询满足条件的所有 RbacClusterRole
     *
     * @param pageParam 分页条件
     * @return RbacClusterRole 对象列表
     */
//    Pagination<ClusterRole> findAndPageClusterRole(String name, PageParam pageParam);

    /**
     * 查询指定name的 RbacClusterRole
     *
     * @param name RbacClusterRole 的名称
     * @return null或者 RbacClusterRole 对象
     */
//    ClusterRole getClusterRoleByName(String name);

    /**
     * 删除指定namespace和name的 RbacClusterRole
     *
     * @param name RbacClusterRole 的名称
     */
//    void deleteClusterRole(String name);

    /**
     * 分页查询满足条件的所有 RoleBinding
     *
     * @param pageParam 分页条件
     * @return RoleBinding 对象列表
     */
//    Pagination<RoleBinding> findAndPageRoleBinding(String namespace, String name, PageParam pageParam);

    /**
     * 查询指定name的 RoleBinding
     *
     * @param namespace RoleBinding 所在的namespace
     * @param name      RoleBinding 的名称
     * @return null或者 RoleBinding 对象
     */
//    RoleBinding getRoleBindingByName(String namespace, String name);

    /**
     * 删除指定namespace和name的 RoleBinding
     *
     * @param namespace RoleBinding 所在的namespace
     * @param name      RoleBinding 的名称
     */
//    void deleteRoleBinding(String namespace, String name);

    /**
     * 分页查询满足条件的所有 RbacClusterRoleBinding
     *
     * @param pageParam 分页条件
     * @return RbacClusterRoleBinding 对象列表
     */
//    Pagination<ClusterRoleBinding> findAndPageClusterRoleBinding(String name, PageParam pageParam);

    /**
     * 查询指定name的 RbacClusterRoleBinding
     *
     * @param name RbacClusterRoleBinding 的名称
     * @return null或者 RbacClusterRoleBinding 对象
     */
//    ClusterRoleBinding getClusterRoleBindingByName(String name);

    /**
     * 删除指定namespace和name的 RbacClusterRoleBinding
     *
     * @param name RbacClusterRoleBinding 的名称
     */
//    void deleteClusterRoleBinding(String name);
}
