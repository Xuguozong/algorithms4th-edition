package com.hikvision.hae.foundation.vo;

/**
 * 登录结果
 *
 * @author zhanjiejun
 */
public class LoginResultVO {

	/**
	 * 下次登录是否需要输入验证码
	 */
	private boolean showCaptcha;

	/**
	 * 是否需要强制修改密码
	 */
	private boolean forceModifyPwd;

	public boolean isShowCaptcha() {
		return showCaptcha;
	}

	public void setShowCaptcha(boolean showCaptcha) {
		this.showCaptcha = showCaptcha;
	}

	public boolean isForceModifyPwd() {
		return forceModifyPwd;
	}

	public void setForceModifyPwd(boolean forceModifyPwd) {
		this.forceModifyPwd = forceModifyPwd;
	}

}
