package com.hikvision.hae.resource.service;

import com.hikvision.hae.resource.vo.HPAItemVO;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/27.
 */
public interface HorizontalPodAutoscalerService {

    /**
     * 查询HPA
     *
     * @param namespace 命名空间
     * @param ownerKind Event关联方的类型
     * @param ownerName Event关联方名称
     * @return 列表记录
     */
    List<HPAItemVO> find(String namespace, String ownerKind, String ownerName);

    /**
     * 删除HPA
     *
     * @param namespace 命名空间
     * @param name      HPA名称
     */
    void delete(String namespace, String name);
}
