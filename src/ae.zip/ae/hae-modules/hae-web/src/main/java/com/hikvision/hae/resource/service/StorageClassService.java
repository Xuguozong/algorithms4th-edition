package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.StorageClassVO;

/**
 * @author jianghaiyang5 on 2017/11/24.
 */
public interface StorageClassService {

    /**
     * 分页查询StorageClass
     *
     * @param name      StorageClass名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<StorageClassVO> findAndPage(String name, PageParam pageParam);


    /**
     * 删除StorageClass
     *
     * @param name StorageClass名称
     */
    void delete(String name);
}
