package com.hikvision.hae.image.service;

import java.io.InputStream;

public interface ImageService extends ImageRepositoryService {

	InputStream downloadImage(String imageFullName);
	
}
