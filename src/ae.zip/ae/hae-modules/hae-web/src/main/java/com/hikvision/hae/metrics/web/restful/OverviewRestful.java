package com.hikvision.hae.metrics.web.restful;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.service.OverviewService;
import com.hikvision.hae.metrics.vo.ClusterInfoVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by zhanjiejun on 2017/11/21.
 */
@RestController
@RequestMapping("/api/overview/v1")
public class OverviewRestful {

	@Autowired
	private OverviewService overviewService;

	@GetMapping("/cluster/baseInfo")
	public AjaxResult<ClusterInfoVO> getClusterInfo() {
		AjaxResult<ClusterInfoVO> result = AjaxResult.buildSuccess();
		result.setData(overviewService.getClusterInfo());
		return result;
	}

	@GetMapping("/cluster/trend")
	public AjaxResult<MetricsTrendVO> getClusterInfo(@RequestParam MetricsType metricsType) {
		AjaxResult<MetricsTrendVO> result = AjaxResult.buildSuccess();
		result.setData(overviewService.metricsClusterTrend(metricsType));
		return result;
	}

}
