package com.hikvision.hae.image.vo;


/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 10:20 2018/3/19
 * @Description :  字段和dockerfile相关
 */
public class ImageEntityVO {

    private String taskName;

    private String programName;

    /**
     * 镜像仓库
     */
    private String repository;

    /**
     * 镜像标签
     */
    private String tag;

    /**
     * 镜像工作目录
     */
    private String workDir;

    /**
     * 基础镜像
     */
    private String baseImage;

    /**
     * 程序运行shell脚本
     */
    private String programSH;

    /**
     * 镜像初始化脚本
     */
    private String imageSH;

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getWorkDir() {
        return workDir;
    }

    public void setWorkDir(String workDir) {
        this.workDir = workDir;
    }

    public String getBaseImage() {
        return baseImage;
    }

    public void setBaseImage(String baseImage) {
        this.baseImage = baseImage;
    }

    public String getProgramSH() {
        return programSH;
    }

    public void setProgramSH(String programSH) {
        this.programSH = programSH;
    }

    public String getImageSH() {
        return imageSH;
    }

    public void setImageSH(String imageSH) {
        this.imageSH = imageSH;
    }
}
