package com.hikvision.hae.log.service.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Select2VO;
import com.hikvision.hae.log.assist.LogVOBuilder;
import com.hikvision.hae.log.biz.LogBiz;
import com.hikvision.hae.log.dto.LogDTO;
import com.hikvision.hae.log.dto.LogQueryDTO;
import com.hikvision.hae.log.service.LogService;
import com.hikvision.hae.log.vo.LogQueryVO;
import com.hikvision.hae.log.vo.LogVO;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.namespace.biz.NamespaceBiz;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import io.fabric8.kubernetes.api.model.Pod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
@Service
public class LogServiceImpl implements LogService {

	private static final Logger logger = LoggerFactory.getLogger(LogServiceImpl.class);

	@Autowired
	private LogBiz logBiz;

	@Autowired
	private NamespaceBiz namespaceBiz;

	@Autowired
	private PodBiz podBiz;

	@Override
	public List<LogVO> searchLogs(LogQueryVO query, PageParam pageParam) {
		LogQueryDTO logQueryDTO = query.toQueryDTO();
		logQueryDTO.setPageParam(pageParam.getPageSize(), pageParam.getPageNo());
		List<LogDTO> logs = logBiz.searchLogs(logQueryDTO);
		return logs.stream().map(log -> LogVOBuilder.buildLogVO(log)).collect(Collectors.toList());
	}

	@Override
	public List<String> downloadLogs(LogQueryVO logQuery) {
		return logBiz.downloadLogs(logQuery.toQueryDTO());
	}

	@Override
	public List<Select2VO> getPodsByNamespace(String namespace) {
		FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, null, null);
		List<Pod> podList = podBiz.find(filterQuery);
		List<Select2VO> selects = Optional.of(podList).map(pods -> {
			return pods.stream() // 构建流
					.map(pod -> {
						return new Select2VO(pod.getMetadata().getName(), "");
					}).collect(Collectors.toList()); // 归集到List
		}).orElse(new ArrayList<>());
		return selects;
	}

	@Override
	public List<Select2VO> getContainersByNamespaceAndPod(String namespace, String podName) {
		FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, podName, null);
		List<Pod> podList = podBiz.find(filterQuery);
		List<Select2VO> selects = new ArrayList<>();
		podList.forEach(pod -> {
			pod.getSpec().getContainers().forEach(container -> {
				selects.add(new Select2VO(container.getName(), ""));
			});
		});
		return selects;
	}

}
