package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.IngressDetailVO;
import com.hikvision.hae.resource.vo.IngressItemVO;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
public interface IngressService {

    /**
     * 分页查询Ingress
     *
     * @param namespace 命名空间
     * @param name      Ingress名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<IngressItemVO> findAndPage(String namespace, String name, PageParam pageParam);

    /**
     * 查看Ingress详情
     *
     * @param namespace 命名空间
     * @param name      Ingress名称
     * @return Ingress详情
     */
    IngressDetailVO getDetail(String namespace, String name);

    /**
     * 删除Ingress
     *
     * @param namespace 命名空间
     * @param name      Ingress名称
     */
    void delete(String namespace, String name);
}
