package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ConfigMapDetailVO;
import com.hikvision.hae.resource.vo.ConfigMapItemVO;

import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/23.
 */
public interface ConfigMapService {

	Pagination<ConfigMapItemVO> findAndPage(String namespace, String name, PageParam pageParam);

	ConfigMapDetailVO getDetail(String namespace, String name);

	void delete(String namespace, String name);

	void create(String namespace, String name, List<KeyValue> data);

	boolean isNameExist(String namespace, String name);

}
