package com.hikvision.hae.foundation.vo;

import com.hikvision.hae.foundation.web.assist.LoginUser;

/**
 * Created by zhanjiejun on 2017/11/13.
 */
public class UserReadVO {

	private String id;

	private String userName;

	private String realName;

	private String email;

	private String phone;

	private int pwdStrength;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getPwdStrength() {
		return pwdStrength;
	}

	public void setPwdStrength(int pwdStrength) {
		this.pwdStrength = pwdStrength;
	}
}
