package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.EventItemVO;

/**
 * @author jianghaiyang5 on 2017/11/27.
 */
public interface EventService {
    /**
     * 分页查询Event
     *
     * @param namespace 命名空间
     * @param ownerKind Event关联方的类型
     * @param ownerName Event关联方名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<EventItemVO> findAndPage(String namespace, String ownerKind, String ownerName, PageParam pageParam);
}
