package com.hikvision.hae.log.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Select2VO;
import com.hikvision.hae.log.vo.LogQueryVO;
import com.hikvision.hae.log.vo.LogVO;

import java.util.List;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
public interface LogService {

	List<LogVO> searchLogs(LogQueryVO query, PageParam pageParam);

	List<String> downloadLogs(LogQueryVO logQuery);

	/**
	 * 根据命名空间查询Pod列表
	 * @param namespace
	 * @return
	 */
	List<Select2VO> getPodsByNamespace(String namespace);

	/**
	 * 根据命名空间和pod名查询container列表
	 * @param namespace
	 * @param podName
	 * @return
	 */
	List<Select2VO> getContainersByNamespaceAndPod(String namespace, String podName);

}
