package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.DeploymentDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public interface DeploymentService {

    /**
     * 分页查询Deployment
     *
     * @param namespace 命名空间
     * @param name      Deployment名称
     * @param labels    标签字符串 形如：k1;k2:v2
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodControllerItemVO> findAndPage(String namespace, String name, String labels, PageParam pageParam);

    /**
     * 查看Deployment详情
     *
     * @param namespace 命名空间
     * @param name      Deployment名称
     * @return Deployment详情
     */
    DeploymentDetailVO getDetail(String namespace, String name);

    /**
     * 伸缩Pod数量
     *
     * @param namespace   命名空间
     * @param name        Deployment名称
     * @param newReplicas 新Pod数量
     */
    void scale(String namespace, String name, int newReplicas);

    /**
     * 删除Deployment
     *
     * @param namespace 命名空间
     * @param name      Deployment名称
     */
    void delete(String namespace, String name);


}
