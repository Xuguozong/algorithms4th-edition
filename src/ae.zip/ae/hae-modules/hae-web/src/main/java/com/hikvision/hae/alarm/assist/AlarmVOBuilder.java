package com.hikvision.hae.alarm.assist;

import com.hikvision.hae.alarm.event.model.EventAlarm;
import com.hikvision.hae.alarm.vo.EventAlarmVO;
import io.fabric8.kubernetes.api.model.ObjectReference;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public class AlarmVOBuilder {

	public static EventAlarmVO fromEventAlarm(EventAlarm eventAlarm) {
		if (eventAlarm == null) {
			return null;
		}
		EventAlarmVO eventAlarmVO = new EventAlarmVO();
		eventAlarmVO.setId(eventAlarm.getId());
		eventAlarmVO.setCount(eventAlarm.getCount());
		eventAlarmVO.setFirstSeenTime(eventAlarm.getFirstSeenTime());
		eventAlarmVO.setLastSeenTime(eventAlarm.getLastSeenTime());
		eventAlarmVO.setMessage(eventAlarm.getMessage());
		eventAlarmVO.setName(eventAlarm.getName());
		eventAlarmVO.setNamespace(eventAlarm.getNamespace());
		ObjectReference involvedObject = eventAlarm.getInvolvedObject();
		if (involvedObject != null) {
			EventAlarmVO.InvolvedObjectVO involvedObjectVO = new EventAlarmVO.InvolvedObjectVO();
			involvedObjectVO.setKind(involvedObject.getKind());
			involvedObjectVO.setName(involvedObject.getName());
			involvedObjectVO.setNamespace(involvedObject.getNamespace());
			eventAlarmVO.setInvolvedObject(involvedObjectVO);
		}
		return eventAlarmVO;
	}

}
