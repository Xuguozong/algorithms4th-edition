package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.SecretDetailVO;
import com.hikvision.hae.resource.vo.SecretItemVO;

/**
 * Created by zhanjiejun on 2017/11/22.
 */
public interface SecretService {

	Pagination<SecretItemVO> findAndPage(String namespace, String name, PageParam pageParam);

	SecretDetailVO getDetail(String namespace, String name);

	void delete(String namespace, String name);

}
