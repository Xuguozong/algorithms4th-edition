package com.hikvision.hae.alarm.service;

import com.hikvision.hae.alarm.event.dto.EventAlarmQuery;
import com.hikvision.hae.alarm.vo.EventAlarmVO;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;

/**
 * Created by zhanjiejun on 2018/3/22.
 */
public interface EventAlarmService {

	Pagination<EventAlarmVO> findAndPage(PageParam pageParam, EventAlarmQuery query);

	long count(EventAlarmQuery query);

}
