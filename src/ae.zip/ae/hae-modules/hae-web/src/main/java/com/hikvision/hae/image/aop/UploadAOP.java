package com.hikvision.hae.image.aop;

import javax.annotation.Resource;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.service.UploadStatusService;
import com.hikvision.hae.image.vo.UploadFileVO;

@Service
@Aspect
public class UploadAOP {

	@Resource
	private UploadFileBiz uploadBiz;

	@Resource
	private UploadStatusService statusService;

	@Pointcut("execution(* com.hikvision.hae.image.service.impl.UploadServiceImpl.* (..))")
	public void uploadProgress() {
	}

	@AfterThrowing(value = "uploadProgress()")
	public void changeUploadStatus(JoinPoint joinPoint) {
		Object[] args = joinPoint.getArgs();
		if (args != null && args.length == 2) {
			UploadFileVO uploadInfo = (UploadFileVO) args[1];
			String currentId = uploadInfo.getId();
			UploadFile file = uploadBiz.getById(currentId, true);
			// 只捕获上传中发生的异常，把状态设置成中断
			if (file != null && file.getStatus() == UploadStatus.UPLOADING) {
				statusService.updateToUploadBreak(currentId);
			}
		}
	}
}
