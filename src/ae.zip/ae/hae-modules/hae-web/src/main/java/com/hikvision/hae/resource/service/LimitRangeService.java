package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.LimitRangeDetailVO;
import com.hikvision.hae.resource.vo.LimitRangeItemVO;

/**
 * @author by zhouzhigang6 on 2018/1/23.
 */
public interface LimitRangeService {

    Pagination<LimitRangeItemVO> findAndPage(String namespace, String name, PageParam pageParam);

    LimitRangeDetailVO getDetail(String namespace, String name);

    void delete(String namespace, String name);
}
