package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ResourceQuotaDetailVO;
import com.hikvision.hae.resource.vo.ResourceQuotaItemVO;

/**
 * @author by zhouzhigang6 on 2018/1/22.
 */
public interface ResourceQuotaService {
    Pagination<ResourceQuotaItemVO> findAndPage(String namespace, String name, PageParam pageParam);

    ResourceQuotaDetailVO getDetail(String namespace, String name);

    void delete(String namespace, String name);
}
