package com.hikvision.hae.log.web.restful;

import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Select2VO;
import com.hikvision.hae.log.service.LogService;
import com.hikvision.hae.log.vo.LogQueryVO;
import com.hikvision.hae.log.vo.LogVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
@RestController
@RequestMapping("/api/log/v1")
public class LogRestful {

	@Autowired
	private LogService logService;

	@GetMapping("/logs")
	public AjaxResult<List<LogVO>> searchLogs(LogQueryVO logQuery, PageParam pageParam) {
		AjaxResult<List<LogVO>> result = AjaxResult.buildSuccess();
		result.setData(logService.searchLogs(logQuery, pageParam));
		return result;
	}

	@GetMapping("/namespaces/{namespace}/pods")
	public AjaxResult<List<Select2VO>> getPodsByNamespace(@PathVariable String namespace) {
		AjaxResult<List<Select2VO>> result = AjaxResult.buildSuccess();
		List<Select2VO> podList = logService.getPodsByNamespace(namespace);
		result.setData(podList);
		return result;
	}

	@GetMapping("/namespaces/{namespace}/pods/{pod}/containers")
	public AjaxResult<List<Select2VO>> getContainerByNamespaceAndPod(@PathVariable String namespace, @PathVariable String pod) {
		AjaxResult<List<Select2VO>> result = AjaxResult.buildSuccess();
		List<Select2VO> containerList = logService.getContainersByNamespaceAndPod(namespace, pod);
		result.setData(containerList);
		return result;
	}

}
