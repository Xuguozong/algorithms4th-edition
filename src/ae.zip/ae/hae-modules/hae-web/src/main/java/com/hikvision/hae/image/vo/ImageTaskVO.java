package com.hikvision.hae.image.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.collect.Lists;
import com.hikvision.hae.img.dto.ImageTaskDTO;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:44 2018/3/16
 * @Description :  镜像任务 提供web调用的数据封装
 */
@JsonPropertyOrder({"id", "programName", "status", "content",
                    "reason", "modifyTime", "createTime"})
public class ImageTaskVO {

    private Integer         id;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String          taskName;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String          programName;

    private String          repository;

    private String          tag;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String          content;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String          status;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String          statusName;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String          reason;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date            createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date            modifyTime;

    public static ImageTaskVO fromDTO(ImageTaskDTO imageTaskDTO){
        ImageTaskVO imageTaskVO = new ImageTaskVO();
        imageTaskVO.setContent(imageTaskDTO.getContent());
        imageTaskVO.setCreateTime(imageTaskDTO.getCreateTime());
        imageTaskVO.setId(imageTaskDTO.getId());
        imageTaskVO.setModifyTime(imageTaskDTO.getModifyTime());
        imageTaskVO.setProgramName(imageTaskDTO.getProgramName());
        imageTaskVO.setReason(imageTaskDTO.getFailedReason());
        imageTaskVO.setStatus(imageTaskDTO.getTaskStatus().name());
        imageTaskVO.setStatusName(imageTaskDTO.getTaskStatus().getContent());
        imageTaskVO.setTaskName(imageTaskDTO.getTaskName());
        imageTaskVO.setRepository(imageTaskDTO.getRepository());
        imageTaskVO.setTag(imageTaskDTO.getTag());
        return imageTaskVO;
    }

    public static List<ImageTaskVO> convertToList(List<ImageTaskDTO> imageTaskDTOS){
        if (CollectionUtils.isEmpty(imageTaskDTOS)){
            return null;
        }
        List<ImageTaskVO> imageTaskVOS = Lists.newArrayList();
        imageTaskDTOS.forEach(imageTaskDTO -> {
            imageTaskVOS.add(fromDTO(imageTaskDTO));
        });
        return imageTaskVOS;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
