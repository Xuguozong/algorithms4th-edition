package com.hikvision.hae.image.listener;
/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 11:14 2018/3/20
 * @Description :  定义镜像任务监听器接口
 */
public interface ImageTaskListener extends EventListener<ImageTaskEvent> {
}
