package com.hikvision.hae.resource.assist;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/28.
 */
@Component
public class NodeLabelChecker {

	@Value("${node.default.label.prefix:}")
	private String nodeDefaultLabelPrefix;

	private List<String> defaultPrefixs;

	@PostConstruct
	public void init() {
		defaultPrefixs = Arrays.asList(nodeDefaultLabelPrefix.split(","));
	}

	/**
	 * 校验标签
	 * @param labelKey
	 * @return
	 */
	public boolean isSystemDefault(String labelKey) {
		for (String defLabelKey : defaultPrefixs) {
			if (labelKey.startsWith(defLabelKey + "/")) {
				return true;
			}
		}
		return false;
	}

}
