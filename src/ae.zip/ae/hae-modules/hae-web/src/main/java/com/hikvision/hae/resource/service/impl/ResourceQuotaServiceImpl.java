package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.resourcequota.biz.ResourceQuotaBiz;
import com.hikvision.hae.resource.service.ResourceQuotaService;
import com.hikvision.hae.resource.vo.ResourceQuotaDetailVO;
import com.hikvision.hae.resource.vo.ResourceQuotaItemVO;
import io.fabric8.kubernetes.api.model.ResourceQuota;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author by zhouzhigang6 on 2018/1/22.
 */
@Service
public class ResourceQuotaServiceImpl implements ResourceQuotaService {

    @Resource
    private ResourceQuotaBiz resourceQuotaBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<ResourceQuotaItemVO> findAndPage(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<ResourceQuota> resourceQuotaPage = resourceQuotaBiz.findAndPage(filterQuery, pageParam);
        // 无满足条件的数据
        if (resourceQuotaPage.getTotal() == 0) {
            return Pagination.build(pageParam);
        }
        Function<Collection<ResourceQuota>, Collection<ResourceQuotaItemVO>> rowsConverter =
                (Collection<ResourceQuota> dtoList) -> dtoList.stream().map(ResourceVOBuilder::buildResourceQuotaItemVO).collect(Collectors.toList());
        return new Pagination<>(resourceQuotaPage, rowsConverter);
    }

    @Override
    public ResourceQuotaDetailVO getDetail(String namespace, String name) {
        ResourceQuota resourceQuota = resourceQuotaBiz.getByName(namespace, name);
        if (resourceQuota == null) {
            throw new HAERuntimeException(ResourceResultCode.RESOURCE_QUOTA_NOT_EXIST);
        }
        return ResourceVOBuilder.buildResourceQuotaDetailVO(resourceQuota);
    }

    @Override
    public void delete(String namespace, String name) {
        resourceQuotaBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.RESOURCE_QUOTA, PrincipalCategory.RESOURCE_QUOTA, namespace, name, "删除资源限额（ResourceQuota）");
    }
}
