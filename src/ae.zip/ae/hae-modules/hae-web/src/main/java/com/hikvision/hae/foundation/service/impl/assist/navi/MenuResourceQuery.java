package com.hikvision.hae.foundation.service.impl.assist.navi;

import com.hikvision.hae.common.enums.Mode;

/**
 * 查询菜单l类别的系统资源的参数条件
 *
 * Created by zhouziwei on 2017/11/3.
 */
public class MenuResourceQuery {
    /**
     * 用户ID
     */
    private String userId;
   /**
    * 命名空间
    */
    private String namespace;
    /**
     * 模式
     */
    private Mode mode;

    public MenuResourceQuery(String userId, String namespace, Mode mode) {
        this.userId = userId;
        this.namespace = namespace;
        this.mode = mode == null ? Mode.SENIOR : mode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }
}
