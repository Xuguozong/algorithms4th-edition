package com.hikvision.hae.foundation.vo;

import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;

import java.io.Serializable;

/**
 * 顶部菜单
 *
 * Created by zhouziwei on 2017/11/3.
 */
public class SimpleMenuResourceVO implements Serializable{

    private static final long serialVersionUID = -6927862809135398482L;

    /**
     * 菜单名称
     */
    private String name;

    /**
     * 菜单图标的URL
     */
    private String iconUrl;

    /**
     * 菜单的URL
     */
    private String url;

    public SimpleMenuResourceVO(String name, String iconUrl, String url) {
        this.name = name;
        this.iconUrl = iconUrl;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public static SimpleMenuResourceVO readFromDTO(SysResourceDTO dto) {
        return new SimpleMenuResourceVO(dto.getName(), dto.getIconUrl(), dto.getUrl());
    }
}
