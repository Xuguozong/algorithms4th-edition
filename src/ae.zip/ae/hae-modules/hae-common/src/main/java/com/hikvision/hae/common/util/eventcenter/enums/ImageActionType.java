package com.hikvision.hae.common.util.eventcenter.enums;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Stream;

/**
 * 镜像
 *
 * Created by zhouziwei on 2017/11/6.
 */
public enum ImageActionType implements PrincipalActionType {
    /**
     * 新建
     */
    ADD,
    /**
     * 删除
     */
    DELETE,
    /**
     * 下载
     */
    DOWNLOAD,
    /**
     * 上传
     */
    UPLOAD,
    /**
     * 断点上传
     */
    BREAKPOINT_UPLOAD;

    private final String i18nPrefix = "EVENT_CENTER.ACTION_TYPE.IMAGE.";

    private static final Logger logger = LoggerFactory.getLogger(ImageActionType.class);

    public static ImageActionType parse(String name) {
        ImageActionType actionType = Stream.of(ImageActionType.values()).filter(c -> c.name().equals(name)).findFirst().orElse(null);
        if (actionType == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型VmwareActionType失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return actionType;
    }

    /**
     * 获取当前枚举常量在视图中的国际化文本的key
     *
     * @return
     */
    @Override
    public String i18nKey() {
        return i18nPrefix + this.name();
    }
}
