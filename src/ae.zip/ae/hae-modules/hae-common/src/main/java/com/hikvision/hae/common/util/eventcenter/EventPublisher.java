package com.hikvision.hae.common.util.eventcenter;

import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.Event;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.constraints.NotNull;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 事件发布者
 *
 */
@Component
public class EventPublisher {
	private static Logger logger = LoggerFactory.getLogger(EventPublisher.class);

	/**
	 * 发布事件。临时实现。仅当参数校验成功后才会真正的发布。
	 * 
	 * @param event
	 * @return
	 */
	public PublishResult publish(Event event) {
		String message = validate(event);
		if (!StringUtils.isBlank(message)) {
			return new PublishResult(false, message);
		}
		EventQueue.addEvent(event);
		return new PublishResult(true);
	}

	/**
	 * 验证被 {@link NotNull}标注的Event对象属性
	 * 
	 * @param event
	 *            待校验的event对象
	 * @return 校验成功返回空字符串，校验失败返回失败信息
	 */
	private String validate(Event event) {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		// 验证Bean参数，并返回验证结果信息
		Set<ConstraintViolation<Event>> validators = validator.validate(event);

		String message = validators.stream().map(cv -> cv.getMessage()).collect(Collectors.joining("\n"));
		if (!StringUtils.isBlank(message)) {
			DelayedLogger.info(logger, () -> "event validation failed: " + message);
		}
		return message;
	}

	/**
	 * 事件发布的结果
	 * 
	 * @author jianghaiyang5 2017年6月1日
	 *
	 */
	public static class PublishResult {
		// 发布成功与否
		private boolean success;

		// 发布失败时的错误消息
		private String message;

		public PublishResult(boolean success) {
			this.success = success;
		}

		public PublishResult(boolean success, String message) {
			this.success = success;
			this.message = message;
		}

		public boolean isSuccess() {
			return success;
		}

		public String getMessage() {
			return message;
		}
	}

}
