package com.hikvision.hae.common.vo;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.function.Function;

/**
 * 分页Response
 *
 * @param <T>
 * @author zhanjiejun
 */
public class Pagination<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	private int pageNo;

	private int perPage;

	private int lastPage;

	private long total;

	private Collection<T> rows;

	public Pagination() {
	}

	public Pagination(int pageNo, jef.common.wrapper.Page<T> page) {
		this.pageNo = pageNo;
		this.perPage = page.getPageSize();
		this.lastPage = page.getTotalPage();
		this.total = page.getTotalCount();
		this.rows = page.getList();
	}

	public <U> Pagination(Pagination<U> page, Function<Collection<U>, Collection<T>> dataMapper) {
		this.pageNo = page.getPageNo();
		this.perPage = page.getPerPage();
		this.lastPage = page.getLastPage();
		this.total = page.getTotal();
		this.rows = dataMapper.apply(page.getRows());
	}

	public Pagination(PageParam pageParam) {
		this.pageNo = pageParam.getPageNo();
		this.perPage = pageParam.getPageSize();
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPerPage() {
		return perPage;
	}

	public void setPerPage(int perPage) {
		this.perPage = perPage;
	}

	public int getLastPage() {
		return lastPage;
	}

	public void setLastPage(int lastPage) {
		this.lastPage = lastPage;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public Collection<T> getRows() {
		return rows == null ? Collections.emptyList() : rows;
	}

	public void setRows(Collection<T> rows) {
		this.rows = rows;
	}

	public static <T> Pagination<T> build() {
		Pagination<T> pagination = new Pagination<>();
		pagination.setRows(Collections.emptyList());
		return pagination;
	}

	public static <T> Pagination<T> build(Collection<T> rows) {
		Pagination<T> pagination = new Pagination<>();
		pagination.setRows(rows);
		pagination.setTotal(rows.size());
		return pagination;
	}

	public static <T> Pagination<T> build(PageParam pageParam) {
		Pagination<T> pagination = build();
		pagination.setPageNo(pageParam.getPageNo());
		pagination.setPerPage(pageParam.getPageSize());
		return pagination;
	}

	public void copyIgnoreRows(Pagination<?> resPage) {
		this.pageNo = resPage.getPageNo();
		this.perPage = resPage.getPerPage();
		this.lastPage = resPage.getLastPage();
		this.total = resPage.getTotal();
	}

}
