package com.hikvision.hae.common.vo;

public class ExistCheckVO {

	private boolean isExist;

	public ExistCheckVO(boolean isExist) {
		this.isExist = isExist;
	}

	public boolean getIsExist() {
		return isExist;
	}

	public void setIsExist(boolean isExist) {
		this.isExist = isExist;
	}
}
