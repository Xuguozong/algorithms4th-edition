package com.hikvision.hae.common.domain;

/**
 * Created by zhanjiejun on 2018/4/9.
 */
public class PodResourceCount {

	double cpuRequest;

	double cpuLimit;

	double memoryRequest;

	double memoryLimit;

	int gpuRequest;

	int gpuLimit;

	public double getCpuRequest() {
		return cpuRequest;
	}

	public void setCpuRequest(double cpuRequest) {
		this.cpuRequest = cpuRequest;
	}

	public double getCpuLimit() {
		return cpuLimit;
	}

	public void setCpuLimit(double cpuLimit) {
		this.cpuLimit = cpuLimit;
	}

	public double getMemoryRequest() {
		return memoryRequest;
	}

	public void setMemoryRequest(double memoryRequest) {
		this.memoryRequest = memoryRequest;
	}

	public double getMemoryLimit() {
		return memoryLimit;
	}

	public void setMemoryLimit(double memoryLimit) {
		this.memoryLimit = memoryLimit;
	}

	public int getGpuRequest() {
		return gpuRequest;
	}

	public void setGpuRequest(int gpuRequest) {
		this.gpuRequest = gpuRequest;
	}

	public int getGpuLimit() {
		return gpuLimit;
	}

	public void setGpuLimit(int gpuLimit) {
		this.gpuLimit = gpuLimit;
	}
}
