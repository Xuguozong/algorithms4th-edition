package com.hikvision.hae.common.util.eventcenter.enums;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 解析PrincipalActionType字符串为枚举对象
 *
 * @author jianghaiyang5 on 2017/6/26.
 */
public class PrincipalActionTypeParser {
    private static Logger logger = LoggerFactory.getLogger(PrincipalActionTypeParser.class);

    /**
     * 根据PrincipalCategory和PrincipalActionType的name返回实际的PrincipalActionType对象
     *
     * @param category
     * @param name
     * @return
     */
    public static PrincipalActionType parse(PrincipalCategory category, String name) {
        if (category == null) {
            DelayedLogger.error(logger, () -> "Input category is null");
            throw new HAERuntimeException(CommonResultCode.INVALID_RESTYPE_FOR_EVENT);
        }
        PrincipalActionType actionType;
        switch (category) {
            case USER:
                actionType = UserActionType.parse(name);
                break;
            case IMAGE:
                actionType = ImageActionType.parse(name);
                break;
            case NODE:
                actionType = NodeActionType.parse(name);
                break;
            case LOG:
                actionType = LogActionType.parse(name);
                break;
            case NAMESPACE:
                actionType = NamespaceActionType.parse(name);
                break;
            case CONFIG_MAP:
            case DAEMON_SET:
            case DEPLOYMENT:
            case INGRESS:
            case JOB:
            case PERSISTENT_VOLUME_CLAIM:
            case PERSISTENT_VOLUME:
            case POD:
            case REPLICA_SET:
            case REPLICATION_CONTROLLER:
            case SECRET:
            case SERVICE:
            case STATEFUL_SET:
            case STORAGE_CLASS:
            case HORIZONTAL_POD_AUTOSCALER:
            case ROLE:
            case CLUSTER_ROLE:
            case ROLE_BINDING:
            case CLUSTER_ROLE_BINDING:
            case SERVICE_ACCOUNT:
                actionType = KubeResourceActionType.parse(name);
                break;
            case RESOURCE_FILE:
                actionType = ResourceFileActionType.parse(name);
                break;
            default:
                DelayedLogger.error(logger, () -> "Fail to parse string to enum object. Input category is {}", category.name());
                throw new HAERuntimeException(CommonResultCode.INVALID_RESTYPE_FOR_EVENT);
        }
        return actionType;
    }
}
