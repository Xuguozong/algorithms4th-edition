package com.hikvision.hae.common.domain;

import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/21.
 */
public class GpuBaseInfo {

	/**
	 * 驱动版本号
	 */
	private String driverVersion;

	/**
	 * 产品名称
	 */
	private String productName;

	/**
	 * 持续模式
	 */
	private String persistenceMode;

	/**
	 * 显示激活
	 */
	private String accountingMode;

	/**
	 * 计算模式
	 */
	private String computeMode;

	/**
	 * 性能状态
	 */
	private String performanceState;

	/**
	 * 进程列表
	 */
	private List<Process> processes;

	public static class Process {

		private long pid;

		private String name;

		private String type;

		/**
		 * 单位MiB
		 */
		private long gpuMemory;

		public long getPid() {
			return pid;
		}

		public void setPid(long pid) {
			this.pid = pid;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public long getGpuMemory() {
			return gpuMemory;
		}

		public void setGpuMemory(long gpuMemory) {
			this.gpuMemory = gpuMemory;
		}
	}

	public String getDriverVersion() {
		return driverVersion;
	}

	public void setDriverVersion(String driverVersion) {
		this.driverVersion = driverVersion;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPersistenceMode() {
		return persistenceMode;
	}

	public void setPersistenceMode(String persistenceMode) {
		this.persistenceMode = persistenceMode;
	}

	public String getAccountingMode() {
		return accountingMode;
	}

	public void setAccountingMode(String accountingMode) {
		this.accountingMode = accountingMode;
	}

	public String getComputeMode() {
		return computeMode;
	}

	public void setComputeMode(String computeMode) {
		this.computeMode = computeMode;
	}

	public String getPerformanceState() {
		return performanceState;
	}

	public void setPerformanceState(String performanceState) {
		this.performanceState = performanceState;
	}

	public List<Process> getProcesses() {
		return processes;
	}

	public void setProcesses(List<Process> processes) {
		this.processes = processes;
	}
}
