package com.hikvision.hae.common.enums;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public enum MetricsType {

	/**
	 * 内存使用率
	 */
	MEMORY_USAGE("memory/usage", "GiB"),

	/**
	 * CPU使用率
	 */
	CPU_USAGE_RATE("cpu/usage_rate", "Cores"),

	/**
	 * GPU风扇转速
	 */
	GPU_FAN_SPEED("fan_speed", "转"),

	/**
	 * GPU显存
	 */
	GPU_MEMORY_USED("memory_used", "MiB"),

	/**
	 * GPU能耗
	 */
	GPU_POWER_DRAW("power_draw", "W"),

	/**
	 * GPU温度
	 */
	GPU_TEMPERATURE("temperature", "℃"),

	/**
	 * GPU使用率
	 */
	GPU_USAGE("gpu_util", "%"),

	/**
	 * 实际不存在该指标，用于前端使用
	 */
	NETWORK_RATE("network", "KB/s"),

	/**
	 * 网络流出速率
	 */
	NETWORK_TX_RATE("network/tx_rate", "KB/s"),

	/**
	 * 网络流入速率
	 */
	NETWORK_RX_RATE("network/rx_rate", "KB/s");

	MetricsType(String type, String unit) {
		this.type = type;
		this.unit = unit;
	}

	private String type;

	private String unit;

	public String getType() {
		return type;
	}

	public String getUnit() {
		return unit;
	}

}
