package com.hikvision.hae.common.exception;

/**
 * 异常基类
 *
 * @author zhanjiejun
 */
public class HAERuntimeException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private int resultCode;

    private Object[] messageParam;

    public HAERuntimeException() {
        super();
    }

    public HAERuntimeException(int resultCode) {
        super();
        this.resultCode = resultCode;
    }

    public HAERuntimeException(int resultCode, Throwable cause) {
        super(cause);
        this.resultCode = resultCode;
    }

    public HAERuntimeException(int resultCode, Object[] messageParam) {
        super();
        this.resultCode = resultCode;
        this.messageParam = messageParam;
    }

    public HAERuntimeException(int resultCode, Object[] messageParam, Throwable cause) {
        super(cause);
        this.resultCode = resultCode;
        this.messageParam = messageParam;
    }

    public HAERuntimeException(int resultCode, String message) {
        super(message);
        this.resultCode = resultCode;
    }

    public HAERuntimeException(int resultCode, String message, Throwable cause) {
        super(message, cause);
        this.resultCode = resultCode;
    }


    protected HAERuntimeException(int resultCode, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.resultCode = resultCode;
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public Object[] getMessageParam() {
        return messageParam;
    }

    public void setMessageParam(Object[] messageParam) {
        this.messageParam = messageParam;
    }

}
