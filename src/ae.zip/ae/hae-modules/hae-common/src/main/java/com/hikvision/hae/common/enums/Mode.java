package com.hikvision.hae.common.enums;

/**
 * 平台模式
 * Created by zhanjiejun on 2018/4/13.
 */
public enum Mode {

	/**
	 * 简单模式
	 */
	EASY,

	/**
	 * 高级模式
	 */
	SENIOR,

	/**
	 * 所有模式
	 */
	ALL

}
