package com.hikvision.hae.common.util.eventcenter;

import com.hikvision.hae.common.util.eventcenter.event.Event;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;

/**
 * 事件监听器的统一接口
 *
 * Created by zhouziwei on 2017/11/1.
 */
public interface EventListener {
    /**
     * 处理事件
     *
     * @param event
     */
    void process(Event event);

    /**
     * 事件监听器是否支持处理当前类别的Event
     *
     * @param event
     * @return
     */
    boolean support(Event event);

    /**
     * 事件分发器通过该方法判断事件监听器是否对指定的事件感兴趣
     *
     * @param category
     *            事件的主体类别
     * @param actionType
     *            事件主体的行为类别
     * @return
     */
    boolean interest(PrincipalCategory category, PrincipalActionType actionType);
}
