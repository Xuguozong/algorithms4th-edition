package com.hikvision.hae.common.vo;

import java.io.Serializable;

/**
 * 前端组件Select2 VO
 * 
 * @author zhanjiejun
 *
 */
public class Select2VO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * select选项的键
	 */
	private String id;

	/**
	 * select选项的名称
	 */
	private String text;

	public Select2VO() {}

	public Select2VO(String id, String text) {
		this.id = id;
		this.text = text;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "Select2VO [id=" + id + ", text=" + text + "]";
	}

}
