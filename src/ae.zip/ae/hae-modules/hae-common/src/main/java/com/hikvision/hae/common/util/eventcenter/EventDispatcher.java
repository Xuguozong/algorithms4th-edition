package com.hikvision.hae.common.util.eventcenter;

import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * 事件分发器：根据事件的类别，以及事件监听器的注册信息，将事件派发到对应的事件监听器
 *
 */
@Component
public class EventDispatcher {
    private static Logger logger = LoggerFactory.getLogger(EventDispatcher.class);

    // 所有已注册的事件监听器
    private List<EventListener> eventListeners;

    //默认的listener：将事件输出到标准输出
    private DefaultEventListener defaultListener;

    //是否开启事件派发
    @Value("${eventCenter.dispatch.enable:true}")
    private boolean enableDispatch;

    @PostConstruct
    public void init() {
        eventListeners = new ArrayList<>();
        defaultListener = new DefaultEventListener();
        fetchEventAndDispatch();
    }

    /**
     * 注册事件监听器
     *
     * @param eventListener
     */
    public void register(EventListener eventListener) {
        this.eventListeners.add(eventListener);
    }

    /**
     * 从事件队列中获取消息并派发到相应的事件处理器
     */
    public void fetchEventAndDispatch() {
        // 单独的后台线程从事件队列中取事件
        CompletableFuture.runAsync(() -> {
            Event event;
            while (true) {
                try {
                    event = EventQueue.fetchEvent();
                    if (event != null) {
                        dispatchEvent(event);
                    }
                } catch (Exception e) {
                    DelayedLogger.error(logger, ()->"Fetch and Dispatch event异常。", e);
                }
            }
        });
    }

    /**
     * 派发事件。遍历监听器，将事件派发给有当前类别事件的处理能力且对当前事件感兴趣的事件监听器
     *
     * @param event
     */
    private void dispatchEvent(Event event) {
        defaultListener.process(event); //使用默认Listener输出日志
        if (!enableDispatch) {
            return;
        }
        //仅当开启日志派发时才派发任务
        for (EventListener listener : eventListeners) {
            if (listener.support(event) && listener.interest(event.getPrincipalCategory(), event.getActionType())) {
                // 异步调用监听器的事件处理方法process
                CompletableFuture.runAsync(() -> {
                    try {
                        listener.process(event);
                    } catch (Exception e) {
                        DelayedLogger.error(logger, ()->"事件[Code: "+ event.getIndexCode() +"]处理异常。", e);
                    }
                });
            }
        }
    }
}
