package com.hikvision.hae.common.util.eventcenter.event;

import com.alibaba.fastjson.JSON;

import java.util.HashMap;
import java.util.Map;

/**
 * 用户对系统任意主体的写操作执行后需要发布该事件
 */
public class UserOperationEvent extends Event {
	private static final long serialVersionUID = -3557509431762988127L;

	// 操作人（行为者）ID
//	@NotNull(message = "field actorId is required")
	private String actorId;

	// 操作人（行为者）IP
	private String actorIp;

	// 主体对象名称
	private String principalName;

	// 主体标识，比如ID
//	@NotNull(message = "field principalIndexCode is required")
	private String principalIndexCode;

	// 当前状态：对主体的写操作（新增/删除/修改）时需要指定本次写操作后主体的状态
	private String currentStatus;

	// 是否终态：当前的主体状态是否是最终的状态，适用于涉及主体状态的事件。
	private boolean isFinal;

	// 当前状态是正常分支的状态还是异常分支的状态。注意和isException区别，为true时表示远程调用明确返回error。
	private boolean isError;

	//是否由超时触发
	private boolean isTimeout;

	//是否由系统异常触发，注意和isError的区别，为true时表示事件发布时HCM本身发生异常
	private boolean isException;

	// 当前写操作使用的规格参数。事件表示删除操作时可为空
	private Map<String, Object> specification;

	// 事件的备注（描述）文本
	private String remark;

	/**
	 * 无参构造：自动生成事件唯一标识
	 */
	public UserOperationEvent() {
		super();
	}

	/**
	 * 使用给定的事件唯一标识创建事件对象
	 *
	 * @param indexCode 事件唯一标识
	 */
	public UserOperationEvent(String indexCode) {
		super(indexCode);
	}

	public String getActorId() {
		return actorId;
	}

	public void setActorId(String actorId) {
		this.actorId = actorId;
	}

	public String getActorIp() {
		return actorIp;
	}

	public void setActorIp(String actorIp) {
		this.actorIp = actorIp;
	}

	public String getPrincipalName() {
		return principalName;
	}

	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}

	public String getPrincipalIndexCode() {
		return principalIndexCode;
	}

	public void setPrincipalIndexCode(String principalIndexCode) {
		this.principalIndexCode = principalIndexCode;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public boolean isFinal() {
		return isFinal;
	}

	public void setFinal(boolean isFinal) {
		this.isFinal = isFinal;
	}

	public boolean isError() {
		return isError;
	}

	public void setError(boolean isError) {
		this.isError = isError;
	}

	public boolean isTimeout() {
		return isTimeout;
	}

	public void setTimeout(boolean timeout) {
		isTimeout = timeout;
	}

	public boolean isException() {
		return isException;
	}

	public void setException(boolean exception) {
		isException = exception;
	}

	public Map<String, Object> getSpecification() {
		return specification;
	}

	public void setSpecification(Map<String, Object> specification) {
		this.specification = specification;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSpecificationAsJsonString() {
		return this.specification != null ? JSON.toJSONString(this.specification) : null;
	}

	public static EventBuilder builder() {
		return new EventBuilder();
	}

	public static class EventBuilder {
		private UserOperationEvent event;

		protected EventBuilder() {
			event = new UserOperationEvent();
		}

		public EventBuilder actorId(String actorId) {
			this.event.setActorId(actorId);
			return this;
		}

		public EventBuilder actorIp(String actorIp) {
			this.event.setActorIp(actorIp);
			return this;
		}

		public EventBuilder principalName(String principalName) {
			this.event.setPrincipalName(principalName);
			return this;
		}

		public EventBuilder principalIndexCode(String principalIndexCode) {
			this.event.setPrincipalIndexCode(principalIndexCode);
			return this;
		}

		public EventBuilder currentStatus(String currentStatus) {
			this.event.setCurrentStatus(currentStatus);
			return this;
		}

		public EventBuilder isFinal(boolean isFinal) {
			this.event.setFinal(isFinal);
			return this;
		}

		public EventBuilder isError(boolean isError) {
			this.event.setError(isError);
			return this;
		}

		public EventBuilder isTimeout(boolean isTimeout) {
			this.event.setTimeout(isTimeout);
			return this;
		}

		public EventBuilder isException(boolean isException) {
			this.event.setException(isException);
			return this;
		}

		public EventBuilder specification(String key, Object value) {
			if (this.event.getSpecification() == null) {
				this.event.setSpecification(new HashMap<>());
			}
			this.event.getSpecification().put(key, value);
			return this;
		}

		public EventBuilder remark(String remark) {
			this.event.setRemark(remark);
			return this;
		}

		public EventBuilder source(String source) {
			this.event.setSource(source);
			return this;
		}

		public EventBuilder indexCode(String indexCode) {
			this.event.setIndexCode(indexCode);
			return this;
		}

		public EventBuilder principalCategory(PrincipalCategory principalCategory) {
			this.event.setPrincipalCategory(principalCategory);
			return this;
		}

		public EventBuilder actionType(PrincipalActionType actionType) {
			this.event.setActionType(actionType);
			return this;
		}

		public UserOperationEvent build() {
			return this.event;
		}
	}
}
