package com.hikvision.hae.common.domain;

import java.util.Map;

/**
 * Created by zhanjiejun on 2018/4/2.
 */
public class KubernetesData {

	private Map<String, Object> labels;

	private String namespace;

	private Map<String, String> node;

	private Map<String, String> pod;

	private Map<String, String> container;

	public Map<String, Object> getLabels() {
		return labels;
	}

	public void setLabels(Map<String, Object> labels) {
		this.labels = labels;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public Map<String, String> getNode() {
		return node;
	}

	public void setNode(Map<String, String> node) {
		this.node = node;
	}

	public Map<String, String> getPod() {
		return pod;
	}

	public void setPod(Map<String, String> pod) {
		this.pod = pod;
	}

	public Map<String, String> getContainer() {
		return container;
	}

	public void setContainer(Map<String, String> container) {
		this.container = container;
	}

}
