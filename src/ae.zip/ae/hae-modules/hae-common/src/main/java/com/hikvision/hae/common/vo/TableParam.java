package com.hikvision.hae.common.vo;

/**
 * 列表参数<br>
 * 继承分页参数
 *
 * @author zhanjiejun
 */
public class TableParam extends PageParam {

	private static final long serialVersionUID = 1L;

	public TableParam(int pageNo, int pageSize, String fuzzyQuery) {
		super(pageNo, pageSize);
		this.fuzzyQuery = fuzzyQuery;
	}

	/**
	 * 模糊查询字段
	 */
	private String fuzzyQuery;

	public String getFuzzyQuery() {
		return fuzzyQuery;
	}

	public void setFuzzyQuery(String fuzzyQuery) {
		this.fuzzyQuery = fuzzyQuery;
	}
}
