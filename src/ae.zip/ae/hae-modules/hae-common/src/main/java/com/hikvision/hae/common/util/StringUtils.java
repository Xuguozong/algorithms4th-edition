package com.hikvision.hae.common.util;

import java.text.DecimalFormat;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/**
 * String相关工具类
 */
public class StringUtils extends org.apache.commons.lang.StringUtils {

	private static Pattern escapeCharPattern = Pattern.compile("\t|\r|\n");

	/**
	 * 无横线的UUID
	 *
	 * @return
	 */
	public static String uuid() {
		return UUID.randomUUID().toString().replace("-", "");
	}

    /**
     * 拼接URL
     * @param parts
     * @return
     */
    public static String joinURL(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            sb.append(parts[i]);
            if (i < parts.length - 1) {
                sb.append("/");
            }
        }
        String joined = sb.toString();

        // And normalize it...
        return joined
                .replaceAll("/+", "/")
                .replaceAll("/\\?", "?")
                .replaceAll("/#", "#")
                .replaceAll(":/", "://");

    }

	/**
	 * 生成随机字符串
	 * 随机参数池：abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%
	 *
	 * @param length
	 * @return
	 */
	public static String getRandomStr(int length) {
		return getRandomStr(length, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%");
	}

	/**
	 * 生成随机字符串
	 * 随机参数池：abcdefghijklmnopqrstuvwxyz0123456789
	 *
	 * @param length
	 * @return
	 */
	public static String getRandomStrWithLowerCaseAndNumber(int length) {
		return getRandomStr(length, "abcdefghijklmnopqrstuvwxyz0123456789");
	}

	private static String getRandomStr(int length, String base) {
		Random random = new Random();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(base.length());
			sb.append(base.charAt(number));
		}
		return sb.toString();
	}

	/**
	 * 分割字符串（分隔符中包含 特殊字符时请使用"\\"转义）
	 *
	 * @param string
	 * @param symbol
	 * @return
	 */
	public static String[] splitStringBySymbol(String string, String symbol) {
		if (string.endsWith(symbol)) {
			return null;
		}
		String[] splitedList = string.split(symbol);
		return splitedList;

	}

	/**
	 * null和空字符串都认为是空字符串
	 *
	 * @param s
	 * @return
	 */
	public static boolean isEmpty(String s) {
		if (s == null || s.length() == 0) {
			return true;
		}
		return false;
	}

	/**
	 * 构建SQL模糊查询字段
	 *
	 * @param query
	 * @return
	 */
	public static String buildSQLFuzzyQueryString(String query) {
		return "%" + query.replace("%", "\\%").replace("_", "\\_") + "%";
	}

	/**
	 * 下划线转驼峰法<br>
	 *
	 * @param line       源字符串
	 * @param smallCamel 大小驼峰,是否为小驼峰
	 * @return
	 */
	public static String underline2Camel(String line, boolean smallCamel) {
		if (line == null || "".equals(line)) {
			return "";
		}
		StringBuffer sb = new StringBuffer();
		Pattern pattern = Pattern.compile("([A-Za-z\\d]+)(_)?");
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			String word = matcher.group();
			sb.append(smallCamel && matcher.start() == 0 ? Character.toLowerCase(word.charAt(0)) : Character.toUpperCase(word.charAt(0)));
			int index = word.lastIndexOf('_');
			if (index > 0) {
				sb.append(word.substring(1, index).toLowerCase());
			} else {
				sb.append(word.substring(1).toLowerCase());
			}
		}
		return sb.toString();
	}

	/**
	 * 驼峰法转下划线<br>
	 *
	 * @param line 源字符串
	 * @return 转换后的字符串
	 * @see <a href=
	 * "http://www.cnblogs.com/javasharp/p/4622413.html">下划线与驼峰命名转换</a>
	 */
	public static String camel2Underline(String line) {
		if (line == null || "".equals(line)) {
			return "";
		}
		line = String.valueOf(line.charAt(0)).toUpperCase().concat(line.substring(1));
		StringBuffer sb = new StringBuffer();
		Pattern pattern = Pattern.compile("[A-Z]([a-z\\d]+)?");
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			String word = matcher.group();
			sb.append(word.toUpperCase());
			sb.append(matcher.end() == line.length() ? "" : "_");
		}
		return sb.toString();
	}

	/**
	 * 无冒号:的mac地址
	 *
	 * @return
	 */
	public static String mac(String macAdd) {
		return macAdd.replace(":", " ");
	}

	/**
	 * 替换回车、换行符、制表符
	 *
	 * @param str
	 * @return
	 */
	public static String replaceSepcialChar(String str) {
		Matcher matcher = escapeCharPattern.matcher(str);
		return matcher.replaceAll("");
	}

	/**
	 * 将浮点数保留多位小数
	 *
	 * @param data
	 * @return
	 */
	public static float remainADecimal(double data, int number) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("0.");
		for (int i = 0; i < number; i++) {
			buffer.append("#");
		}
		DecimalFormat format = new DecimalFormat(buffer.toString());
		return Float.parseFloat(format.format(data));
	}

	/**
	 * 浮点数转成小数，小数位不为0就进1
	 *
	 * @param data
	 * @return
	 */
	public static int floatToInt(float data) {
		int newData = (int) data;
		float mulData = data * 10;
		int reData = (int) mulData % 10;
		if (reData > 0) {
			newData = newData + 1;
		}
		return newData;
	}

	public static String uuidForString(String s) {
		return UUID.nameUUIDFromBytes(s.getBytes()).toString();
	}

	/**
	 * 字符串摘要
	 * @param s
	 * @return 同一个字符串得到的结果相同，不同字符串得到的结果不同
	 */
	public static String digest(String s, int length) {
		CRC32 crc32 = new CRC32();
		crc32.update(s.getBytes());
		long crc32Res = crc32.getValue();
		return Long.toHexString(crc32Res).substring(0, length);
	}

}
