package com.hikvision.hae.common.util.eventcenter.event;

import javax.validation.constraints.NotNull;

/**
 * 用户登录或登出时发布的事件
 *
 */
public class UserLoginEvent extends Event {
	private static final long serialVersionUID = 409209059882165454L;

	// 用户ID
	@NotNull(message = "field userId is required")
	private String userId;
	
	//用户名/登录账户
	@NotNull(message = "field userName is required")
	private String userName;

	// 用户IP
	private String userIp;

	// 事件的备注（描述）文本
	private String remark;

	/**
	 * 无参构造：自动生成事件唯一标识
	 */
	public UserLoginEvent() {
		super.setPrincipalCategory(PrincipalCategory.USER);
	}

	/**
	 * 使用给定的事件唯一标识创建事件对象
	 * 
	 * @param indexCode
	 *            事件唯一标识
	 */
	public UserLoginEvent(String indexCode) {
		super(indexCode);
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserIp() {
		return userIp;
	}

	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
