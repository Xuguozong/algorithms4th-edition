package com.hikvision.hae.common.util;

import jef.tools.DateFormats;
import jef.tools.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public class UTCDateUtil extends DateFormats {
    private static final Logger logger = LoggerFactory.getLogger(UTCDateUtil.class);

    /**
     * 将UTC时间格式字符串转换成java.util.Date对象
     *
     * @param utcTime UTC时间格式字符串
     * @return java.util.Date对象
     */
    public static Date parseUTCTimeToStandardDate(String utcTime) {
        try {
            return DateUtils.parse(utcTime, UTCDateFormat.DATE_TIME_CS_UTC);
        } catch (ParseException e) {
            DelayedLogger.error(logger, () -> "将时间字符串" + utcTime + "转换成Date类型失败");
            return null;
        }
    }

    public static Date parseUTCTimeNanoToStandardDate(String utcTime) {
        try {
            return DateUtils.parse(utcTime, UTCDateFormat.DATE_TIME_NANOSECOND_UTC);
        } catch (ParseException e) {
            DelayedLogger.error(logger, () -> "将时间字符串" + utcTime + "转换成Date类型失败");
            return null;
        }
    }

    public static Date parseUTCTimeToStandardDate(String utcTime, Date defaultVal) {
        if(StringUtils.isBlank(utcTime)){
            return defaultVal;
        }
        return parseUTCTimeToStandardDate(utcTime);
    }

    public static String formatDateToUTCTime(Date date) {
        return DateUtils.format(date, UTCDateFormat.DATE_TIME_CS_UTC);
    }

    public static class UTCDateFormat extends DateFormats {
        /**
         * UTC时间字符串
         */
        public static final ThreadLocal<DateFormat> DATE_TIME_CS_UTC = ThreadLocal.withInitial(() -> {
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
            format.setTimeZone(TimeZone.getTimeZone("UTC"));
            return format;
        });

        public static final ThreadLocal<DateFormat> DATE_TIME_NANOSECOND_UTC = ThreadLocal.withInitial(() -> {
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'Z'");
            format.setTimeZone(TimeZone.getTimeZone("UTC"));
            return format;
        });
    }

}
